-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 26, 2015 at 03:12 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mflcar`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_advertise`
--

CREATE TABLE IF NOT EXISTS `tbl_advertise` (
  `AID` int(11) NOT NULL AUTO_INCREMENT,
  `CarID` varchar(20) NOT NULL,
  `AdminID` varchar(20) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `Price` int(11) NOT NULL,
  `AStatus` varchar(20) NOT NULL,
  `Status` varchar(20) NOT NULL,
  PRIMARY KEY (`AID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_advertise`
--

INSERT INTO `tbl_advertise` (`AID`, `CarID`, `AdminID`, `StartDate`, `EndDate`, `Price`, `AStatus`, `Status`) VALUES
(17, 'Car-000001', '1', '1970-01-01', '1970-01-01', 10000, 'Premium', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE IF NOT EXISTS `tbl_brand` (
  `BrandID` int(11) NOT NULL AUTO_INCREMENT,
  `BrandName` varchar(500) NOT NULL,
  `UserID` varchar(2) NOT NULL,
  PRIMARY KEY (`BrandID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`BrandID`, `BrandName`, `UserID`) VALUES
(1, 'Toyota', ''),
(2, 'Honda', 'Us'),
(3, 'Nissan', 'Us');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_car`
--

CREATE TABLE IF NOT EXISTS `tbl_car` (
  `CarID` varchar(30) NOT NULL,
  `CarNo` varchar(30) NOT NULL,
  `Brand` varchar(50) NOT NULL,
  `CarName` varchar(70) NOT NULL,
  `Model` varchar(70) NOT NULL,
  `Kilo` varchar(60) NOT NULL,
  `Gear` varchar(50) NOT NULL,
  `Fuel` varchar(50) NOT NULL,
  `CarType` varchar(60) NOT NULL,
  `Description` varchar(5000) NOT NULL,
  `ContactPerson` varchar(300) NOT NULL,
  `ContactNumber` varchar(40) NOT NULL,
  `TownshipID` varchar(40) NOT NULL,
  `Price` int(11) NOT NULL,
  `EnginePower` varchar(50) NOT NULL,
  `UserID` varchar(40) NOT NULL,
  `CarView` int(11) NOT NULL,
  `CarLike` int(11) NOT NULL,
  `CarStatus` varchar(50) NOT NULL,
  `Status` varchar(40) NOT NULL,
  `PublishDate` date NOT NULL,
  `PublishTime` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_car`
--

INSERT INTO `tbl_car` (`CarID`, `CarNo`, `Brand`, `CarName`, `Model`, `Kilo`, `Gear`, `Fuel`, `CarType`, `Description`, `ContactPerson`, `ContactNumber`, `TownshipID`, `Price`, `EnginePower`, `UserID`, `CarView`, `CarLike`, `CarStatus`, `Status`, `PublishDate`, `PublishTime`) VALUES
('Car-000001', '1', '1', '1', '1', '1', 'Auto', 'Petrol', 'Sedan', '1', '1', '1', 'TB-000002', 100, '1', 'Usr-000001', 32, 0, '0', '0', '0000-00-00', 'Active'),
('Car-000002', 'b', '1', 'b', 'b', 'b', 'Auto', 'Petrol', 'Bus', 'b', 'b', 'b', 'TB-000002', 1, 'b', 'Usr-000001', 6, 0, 'Used', 'Active', '0000-00-00', '11:45:47');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_carphoto`
--

CREATE TABLE IF NOT EXISTS `tbl_carphoto` (
  `PhotoID` int(11) NOT NULL AUTO_INCREMENT,
  `CarID` varchar(20) NOT NULL,
  `PhotoMini` varchar(5000) NOT NULL,
  `PhotoLarge` varchar(5000) NOT NULL,
  PRIMARY KEY (`PhotoID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_carphoto`
--

INSERT INTO `tbl_carphoto` (`PhotoID`, `CarID`, `PhotoMini`, `PhotoLarge`) VALUES
(1, 'Car-000001', 'thumb757823270100x100.jpg', 'a.jpg'),
(2, 'Car-000001', 'thumb1065052065100x100.jpg', 'b.jpg'),
(3, 'Car-000001', 'thumb1809721472100x100.jpg', 'c.jpg'),
(4, 'Car-000001', 'thumb1467426737100x100.jpg', 'j.jpg'),
(15, 'Car-000002', 'thumb1038075071100x100.jpg', '1423805193_1316248445.png'),
(14, 'Car-000002', 'thumb463634678100x100.jpg', '1423805040_245195295.png'),
(11, 'Car-000002', 'thumb2045359146100x100.jpg', '1423804547_1127654692.png'),
(16, 'Car-000002', 'thumb235192095100x100.jpg', '1423805225_346878010.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_city`
--

CREATE TABLE IF NOT EXISTS `tbl_city` (
  `CityID` varchar(20) NOT NULL,
  `CityName` varchar(255) NOT NULL,
  PRIMARY KEY (`CityID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_city`
--

INSERT INTO `tbl_city` (`CityID`, `CityName`) VALUES
('Ct-000001', 'Yangon');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_news`
--

CREATE TABLE IF NOT EXISTS `tbl_news` (
  `NewsID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` text NOT NULL,
  `Description` text NOT NULL,
  `NewsDate` varchar(20) NOT NULL,
  `NewsTime` varchar(20) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `UserID` varchar(20) NOT NULL,
  PRIMARY KEY (`NewsID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_news`
--

INSERT INTO `tbl_news` (`NewsID`, `Title`, `Description`, `NewsDate`, `NewsTime`, `Status`, `UserID`) VALUES
(1, 'Testing', 'Hello', '2014-Dec-05', '01:43:27', 'Active', 'Usr-000001');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_photo`
--

CREATE TABLE IF NOT EXISTS `tbl_photo` (
  `CarID` varchar(20) NOT NULL,
  `PhotoID` varchar(20) NOT NULL,
  `Path` varchar(5000) NOT NULL,
  `Description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_photo`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_township`
--

CREATE TABLE IF NOT EXISTS `tbl_township` (
  `TownshipID` varchar(10) NOT NULL,
  `CityID` varchar(50) DEFAULT NULL,
  `TownshipName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`TownshipID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_township`
--

INSERT INTO `tbl_township` (`TownshipID`, `CityID`, `TownshipName`) VALUES
('TB-000002', 'Ct-000001', 'Sanchaung'),
('TB-000001', 'Ct-000001', 'a'),
('TB-000003', 'Ct-000001', 'Dagon'),
('TB-000004', 'Ct-000001', 'Tamwe');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `UserID` varchar(20) NOT NULL,
  `FullName` varchar(255) NOT NULL,
  `DOB` varchar(50) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Phone` varchar(135) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `UserName` varchar(135) NOT NULL,
  `Password` varchar(135) NOT NULL,
  `Role` varchar(20) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`UserID`, `FullName`, `DOB`, `Gender`, `Phone`, `Email`, `UserName`, `Password`, `Role`, `Status`) VALUES
('Usr-000001', 'Pyay Phyo Kyaw', '1/1/2000', 'Male', '199', 'ppk@gmail.com', 'ppk', '3bb3f4dbc050a34d9c401067d396db13', 'Admin', 'Active');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
