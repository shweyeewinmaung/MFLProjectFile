<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_news.php");

$ret=GetAllNewsDataASC($NewsID);
$num=mysql_num_rows($ret);

$ret1=GetAllNewsDataASC($NewsID);
$num1=mysql_num_rows($ret1);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<link rel="stylesheet" type="text/css" href="css/tab.css"/>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/organic.js"></script>
</head>
<body>
   <?php include("template/headernews.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar" style="padding-top:10px;">
   

        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px; ">
         <div id="example-one">
			
    <ul class="nav">
                <li class="nav-one"><a href="#featured" class="current">Most Visited News</a></li>
                <li class="nav-two"><a href="#core">Latest News</a></li>
                
    </ul>
	
    <div class="list-wrap">
	
		<ul id="featured">
        		   <?php
         			  while($row=mysql_fetch_array($ret))
				
					{	
								?>
			<li>
            <table>
                 		<tr height="40">	
                        	<td>
                            	<h2 style="color:#2c4c09; text-transform:uppercase;"><?php echo $row['Title']; ?></h2>
                            
                            </td>
                        
                        </tr>
                        <tr>	
                        	<td>
                            	<p><?php echo $row['Description']; ?></p>
                            </td>
                        
                        </tr>
                         <tr>	
                        	<td>
                            	

                                <a href="ReadMore.php?NewsID=<?php echo $row['NewsID']; ?>" target="_blank" style="color:#000; text-decoration:none; width:80px;  padding-left:15px; padding-top:5px;" class="readmore">Read More</a> &nbsp; &nbsp;&nbsp; &nbsp;
                            	<a href="EditNews.php?NewsID=<?php echo $row['NewsID']; ?>"  target="_blank"style="color:#000; text-decoration:none; width:80px;  padding-left:15px; padding-top:5px;" class="readmore">Edit</a> &nbsp; &nbsp;&nbsp; &nbsp;
                                <a href="DeleteNews.php?NewsID=<?php echo $row['NewsID']; ?>"  target="_blank"style="color:#000; text-decoration:none; width:80px;  padding-left:15px; padding-top:5px;" class="readmore">Delete</a>
                                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                                  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                                  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                                  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                                  &nbsp; &nbsp; &nbsp; &nbsp; 

                            </td>
                        
                        </tr>
                        
                         
                 
                 </table>
            </li>
            <p style="border-bottom:1px solid#888e82;"></p>
           <?php } ?>
		</ul>
		 
		
        
        
        
        
        <ul id="core" class="hide">
			 <?php
         			  while($row1=mysql_fetch_array($ret1))
				
					{	
								?>
			<li>
           		 <table>
                 		<tr height="40">	
                        	<td>
                            	<h2 style="color:#2c4c09; text-transform:uppercase;"><?php echo $row1['Title']; ?></h2>
                            </td>
                        
                        </tr>
                        <tr>	
                        	<td>
                            	<p><?php echo $row1['Description']; ?></p>
                            </td>
                        
                        </tr>
                         <tr>	
                        	<td>
                            	
                                <a href="ReadMore.php?NewsID=<?php echo $row1['NewsID']; ?>" target="_blank" style="color:#000; text-decoration:none; width:80px;  padding-left:15px; padding-top:5px;" class="readmore">Read More</a> &nbsp; &nbsp;&nbsp; &nbsp;
                            	<a href="EditNews.php?NewsID=<?php echo $row1['NewsID']; ?>"  target="_blank"style="color:#000; text-decoration:none; width:80px;  padding-left:15px; padding-top:5px;" class="readmore">Edit</a> &nbsp; &nbsp;&nbsp; &nbsp;
                                <a href="DeleteNews.php?NewsID=<?php echo $row1['NewsID']; ?>"  target="_blank"style="color:#000; text-decoration:none; width:80px;  padding-left:15px; padding-top:5px;" class="readmore">Delete</a>
                                 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                                  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                                  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                                  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                                  &nbsp; &nbsp; &nbsp; &nbsp; 

                            </td>
                        
                        </tr>
                        
                         
                 
                 </table>
                  <p style="border-bottom:1px solid#888e82;"></p>
         </li>
           <?php } ?>
		 </ul>
		 
		
		 
    </div> <!-- END List Wrap -->
 
 </div> <!-- END Organic Tabs (Example One) -->
        


         
         
         
         
         
         
         
         </div><!---------Form End----------->

	</div><!---mainbar End----->
      <?php include("template/sidebarnews.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>