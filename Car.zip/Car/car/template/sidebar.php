<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_news.php");

$ret=GetAllNewsData3($NewsID);
$num=mysql_num_rows($ret);

?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<style>
a{}
a:hover{ color:#3F0; text-decoration:underline;}
</style>

<div class="sidebar" >
        <div class="gadget">
          <h2 class="star"><span>Sidebar</span> Menu</h2>
          <div class="clr"></div>
          <ul class="sb_menu">
            <li><a href="#">Home</a></li>
            <li><a href="#">TemplateInfo</a></li>
            <li><a href="#">Style Demo</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Archives</a></li>
            <li><a href="#">Web Templates</a></li>
          </ul>
        </div>
        <div class="gadget">
          <h2 class="star"><span>News</span></h2>
          <div class="clr"></div>
          <ul class="ex_menu">
         <?php while($row=mysql_fetch_array($ret)){ ?> 
           <li>
            <font style="font-size:18px; color:#690; font-weight:bold;text-transform:uppercase;""><?php echo $row['Title']; ?></font><br />
         <?php echo $row['Description']; ?>
          <a href="ReadMore.php?NewsID=<?php echo $row['NewsID']; ?>" target="_blank" style="color:#666; text-decoration:none; float:right;" >Read More>></a><br />
         
            </li>
            
           
            <?php } ?>
          </ul>
        </div>
      </div>