
<title>Car</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/cufon-yanone.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>


<div class="main">
  <div class="header">
    <div class="header_resize">
      <div class="logo">
        <h1><a href="index.php"><!--<small>Company Slogan Here</small>--> <span>Investmentspro</span></a></h1>
        
      </div>
      <div class="clr"></div>
      <div style="float:right; color:#fff;">
        <?php
		if(!isset($_SESSION['SESS']['User']))
		{
			?>
            	<a href="LogIn.php" style="text-decoration:none; font-size:12px; font-weight:bold; color:white; margin-right:7px; float:right;">LogIn</a> <label  style="text-decoration:none; font-size:12px; font-weight:bold; color:white; margin-right:7px; float:right;">
                <b>|</b></label> <a href="Signup.php" style="text-decoration:none; font-size:12px; font-weight:bold; color:white; margin-right:7px; float:right;">Signup</a>
            <?php
		}
		else
		{
			if(isset($_SESSION['SESS']['User']) && $_SESSION['SESS']['User']['Role']=="Admin")
			{
				?>
                    <a href="Admin.php" style="text-decoration:none; font-size:12px; font-weight:bold; color:white; margin-right:7px; float:right;">My Cars</a> <label  style="text-decoration:none; font-size:12px; font-weight:bold; color:white; margin-right:7px; float:right;"><b>|</b></label> <a href="LogOut.php" style="text-decoration:none; font-size:12px; font-weight:bold; color:white; margin-right:7px; float:right;">Admin</a>
                <?php
			}
			?>
				<a href="MyCar.php" style="text-decoration:none; font-size:12px; font-weight:bold; color:white; margin-right:7px; float:right;">My Cars</a> <label  style="text-decoration:none; font-size:12px; font-weight:bold; color:white; margin-right:7px; float:right;"><b>|</b></label> <a href="LogOut.php" style="text-decoration:none; font-size:12px; font-weight:bold; color:white; margin-right:7px; float:right;">Log Out</a>
            <?php
		}
	?>
      <!-----------Login Username Appear Start---------------->
      <div style="width:auto; overflow:hidden;  float:right; margin-top:40px; margin-right:-100px; color:#0F0;">
       <?php
		if(!isset($_SESSION['SESS']['User']))
		{
			?>
            	<form action="loginval.php" method="POST">
                    <input type="text" name="txtname" placeholder="UserName" style="color:#000;" required />
                    <input type="text" name="txtpassword" placeholder="Password" style="color:#000;" required />
                    <input type="submit" value="Login" style="color:#000; background-color:#daf2bf; border:2px solid#daf2bf;">
                </form>
            <?php
		}
		else
		{
			echo "Welcome : ".$_SESSION['SESS']['User']['FullName'];
		}
	?>
      </div>
      <!-------------Login Username Appear End--------------->
      
      </div>
      <!--<div class="searchform">
        <form id="formsearch" name="formsearch" method="post" action="#">
          <span>
          <input name="editbox_search" class="editbox_search" id="editbox_search" maxlength="80" value="Search our ste:" type="text" />
          </span>
          <input name="button_search" src="images/search.gif" class="button_search" type="image" />
        </form>
      </div>-->
      <div class="menu_nav">
        <ul>
        
        
        
        <li><a href="index.php">Home</a></li>
            <?php
				if(isset($_SESSION['SESS']['User']) && $_SESSION['SESS']['User']!="Admin")
				{
					?>
                    	<li><a href="AddCar.php">Upload Car</a></li>
                        <li><a href="MyCar.php">My Car</a></li>
                    <?php
				}
				elseif(isset($_SESSION['SESS']['User']) && $_SESSION['SESS']['User']=="Admin")
				{
					?>
	                    <li><a href="Admin/index.php">Admin</a></li>
                        <li><a href="MyCar.php">My Car</a></li>
                    <?php
				}
				/*elseif(!isset($_SESSION['SESS']['User']))
				{
					?>
	                    <li><a href="#">Sign Up</a></li>
                    <?php
				}*/
			?>
            <li><a href="Search.php">Search</a></li>
            <li><a href="News.php">News</a></li>
			<li><a href="Contact.php">Contact Us</a></li>
            <li><a href="Help.php">Help</a></li>
         <!-- <li class="active"><a href="index.php"><span>Home Page</span></a></li>
          <li><a href="support.html"><span>Support</span></a></li>
          <li><a href="about.html"><span>About Us</span></a></li>
          <li><a href="blog.html"><span>Blog</span></a></li>
          <li><a href="contact.html"><span>Contact Us</span></a></li>-->
        </ul>
      </div>
      <div class="clr"></div>
      <div class="slider">
        <div id="coin-slider" style="border:2px solid#98aa83;" > <a href="#"><img src="images/2.jpg" width="960" height="320" alt="" />
        <!--<span><big>Sed condimentum justo sit amet urna ornare euismod.</big><br />
          Tusce nec iaculis risus hasellus nec sem sed tellus malesuada porttitor. Mauris scelerisque feugiat ante in vulputate. Nam sit amet ullamcorper tortor. Phasellus posuere facilisis cursus. Nunc est lorem, dictum at scelerisque sit amet, faucibus et est. Proin mattis ipsum quis arcu aliquam molestie.</span>--></a> <a href="#"><img src="images/3.jpg" width="960" height="320" alt="" /><!--<span><big>Amet urna ornare euismodSed condimentum.</big><br />
          Tusce nec iaculis risus hasellus nec sem sed tellus malesuada porttitor. Mauris scelerisque feugiat ante in vulputate. Nam sit amet ullamcorper tortor. Phasellus posuere facilisis cursus. Nunc est lorem, dictum at scelerisque sit amet, faucibus et est. Proin mattis ipsum quis arcu aliquam molestie.</span>--></a> <a href="#"><img src="images/2.jpg" width="960" height="320" alt="" /><!--<span><big>Sed condimentum justo sit amet urna ornare euismod.</big><br />
          Tusce nec iaculis risus hasellus nec sem sed tellus malesuada porttitor. Mauris scelerisque feugiat ante in vulputate. Nam sit amet ullamcorper tortor. Phasellus posuere facilisis cursus. Nunc est lorem, dictum at scelerisque sit amet, faucibus et est. Proin mattis ipsum quis arcu aliquam molestie.</span>--></a> </div>
        <div class="clr"></div>
        
      </div>
      <div class="clr"></div>
    </div>
  </div>
  </div>
  
   
		
	