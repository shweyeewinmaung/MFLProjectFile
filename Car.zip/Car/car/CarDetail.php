<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_car.php");
require_once("dal/dal_brand.php");
require_once("dal/dal_city.php");
require_once("dal/dal_township.php");
require_once("library/function.php");
require_once("library/globalfunction.php");

if(isset($_GET['CarID']) && $_GET['CarID']!="")
{	
	$CarID=$_GET['CarID'];
	IncreaseView($CarID);
	$ret=GetCarDataByCarID($CarID);
	$num=mysql_num_rows($ret);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>
<style>
#DisplayCar{
	position:fixed;
	border:4px solid white;
	left:40%;
	top:15%;
	margin:-75px 0 0 -135px;
	background: none repeat scroll 0 0 #F0F0F0;
	background-color:blue;
	overflow: hidden;
	visibility:hidden;
}
</style>


<script>
function DC(imgSrc)
{
	//alert(imgSrc);
	var newImg = new Image();
	newImg.src = "carphoto/h.jpg";
	
    var oh = newImg.height;
    var ow = newImg.width;
	
	
	var rw=(oh/ow).toFixed(2);
	var rh=(ow/ow).toFixed(2);
	
	var sw, sh;
	if(rw*700<=700 && rh*700<=700)
	{
		sw=rh*700;
		sh=rw*700;
	}
	
	else if(rw*600<=700 && rh*600<=700)
	{
		sw=rh*600;
		sh=rw*600;
	}
	else if(rw*500<=700 && rh*500<=700)
	{
		sw=rh*500;
		sh=rw*500;
	}
	else if(rw*400<=700 && rh*400<=700)
	{
		sw=rh*400;
		sh=rw*400;
	}
	else if(rw*300<=700 && rh*300<=700)
	{
		sw=rh*300;
		sh=rw*300;
	}
	else if(rw*200<=700 && rh*200<=700)
	{
		sw=rh*200;
		sh=rw*200;
	}
	else if(rw*100<=700 && rh*100<=700)
	{
		sw=rh*100;
		sh=rw*100;
	}
	else if(rw*50<=800 && rh*50<=800)
	{
		sw=rh*50;
		sh=rw*50;
	}
	else if(rw*25<=800 && rh*25<=800)
	{
		sw=rh*25;
		sh=rw*25;
	}
	
	
	document.getElementById('DisplayCar').setAttribute("style","width:" + sw);
	document.getElementById('DisplayCar').style.width=sw +'px';
	
	document.getElementById('DisplayCar').setAttribute("style","height:auto");
	document.getElementById('DisplayCar').style.height='auto';
	
	document.getElementById("DisplayCar").style.visibility = 'visible';
	document.getElementById("DisplayCar").innerHTML="";
	var data="<img src=carphoto/" + imgSrc + " width='100%' height='auto;'>";
	
	document.getElementById("DisplayCar").innerHTML="<img src=carphoto/" + imgSrc + " width='100%' height='auto;'>";
}
function FC()
{
	document.getElementById("DisplayCar").style.visibility = 'hidden';
}
</script>

</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
      
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
          
         <div id="DisplayCar">
</div>
         <div style="width:600px; height:auto; overflow:hidden; margin:10px auto; border-radius:10px;">
        <span style="margin-left:300px; font-size:24px; color:#2c4c09; font-weight:bold; ">Car Detail</span><br /><br />
    	<?php
			if($num>0)
			{
				$row=mysql_fetch_array($ret);
				$retp=GetCarPhotoByCarID($row['CarID']);
				$rowp=mysql_fetch_array($retp);
				?>
                	<div style="width:100%; height:10%; float:left; margin-bottom:2%;">
                    	<div style="width:50%; height:100%; float:left; font-size:21px;">
                        	<b style="margin-left:10px;"><?php echo $row['Brand']; ?> <?php echo $row['CarName']; ?> <?php echo $row['Model']; ?></b>
                        </div>
                        <div style="width:45%; height:100%; margin-left:5%; float:left; font-size:21px;">
                        	<b style="margin-left:10px;"><?php echo $row['Price']; ?></b>
                        </div>
                    </div>                    
                	<div style="margin-left:1%; width:50%; height:100%; float:left;">
                    	<img src="carphoto/Mini/<?php echo $rowp['PhotoMini']; ?>" onMouseOver="DC('<?php echo $rowp['PhotoLarge']; ?>')" onMouseOut="FC()" width="100%" height="100%" style="border:2px solid#666;" />
                        <br />
                        <br />
                        <?php
							$retpa=GetCarPhotoAllByCarID($row['CarID']);
							while($rowpa=mysql_fetch_array($retpa))
							{
								?>
								<img src="carphoto/Mini/<?php echo $rowpa['PhotoMini']; ?>" onMouseOver="DC('<?php echo $rowpa['PhotoLarge']; ?>')" onMouseOut="FC()" style="width:100px; height:90px;"/>
                                <?php
							}
						?>
                        
                    </div>
                    
                    <div style="margin-left:4%; width:45%; height:100%; float:left; font-size:16px;">
                    	<table>
                        	<th colspan="4" style="color:#fff; background-color:#2c4c09; height:30px; border-radius:5px;"><b >Contact Info</b></th>
                            
                            <tr>
                            	<td>City</td>
                                <td> : </td>
                                <td><?php 
									$retTownship=GetTownshipDataBy_TownshipID($row['TownshipID']);
									$rowTownship=mysql_fetch_array($retTownship);
									
									$retCity=GetCityDataBy_CityID($rowTownship['CityID']);
									$rowCity=mysql_fetch_array($retCity);
									echo $rowCity[1];
								?></td>
                            </tr>
                            
                            <tr>
                            	<td>Township</td>
                                <td> : </td>
                                <td><?php 
									//$retTownship=GetTownshipDataBy_TownshipID($row['TownshipID']);
									//$rowTownship=mysql_fetch_array($retTownship);
									echo $rowTownship['TownshipName']; 
								?></td>
                            </tr>
                            
                            <tr>
                            	<td>Name</td>
                                <td> : </td>
                                <td><?php echo $row['ContactPerson']; ?></td>
                            </tr>
                            
                            <tr>
                            	<td>Phone No </td>
                                <td> : </td>
                                <td><?php echo $row['ContactNumber']; ?></td>
                            </tr>
                            
                            <tr>
                            	<td>Published:<td>
                                <td> : </td>
                                <td><font style="color:#003;"><?php echo $row['PublishDate'] . " / " .  $row['PublishTime']; ?></font></td>
                            </tr>
                        </table>
                        <br />
                        <table>
                        	<th colspan="4" style="color:#fff; background-color:#2c4c09; height:30px; border-radius:5px; width:390px;"><center><b><?php echo $row['Brand']; ?> <?php echo $row['CarName']; ?> <?php echo $row['Model']; ?> Detail</b></center></th>
                            
                            <tr>
                            	<td>Kilo</td>
                                <td> : </td>
                                <td><?php echo $row['Kilo']; ?></td>
                            </tr>
                            
                            <tr>
                            	<td>Gear</td>
                                <td> : </td>
                                <td><?php echo $row['Gear']; ?></td>
                            </tr>
                            
                            <tr>
                            	<td>Fuel</td>
                                <td> : </td>
                                <td><?php echo $row['Fuel']; ?></td>
                            </tr>
                            
                            <tr>
                            	<td>Car Type</td>
                                <td> : </td>
                                <td><?php echo $row['CarType']; ?></td>
                            </tr>
                            
                            <tr>
                            	<td>Enginee</td>
                                <td> : </td>
                                <td><?php echo $row['EnginePower']; ?></td>
                            </tr>
                            
                            <tr>
                            	<td>Price :</td>
                                <td> : </td>
                                <td><?php echo $row['Price']; ?></td>
                            </tr>
                            
                            <tr>
                            	<td>Viewed :</td>
                                <td> : </td>
                                <td><?php echo $row['CarView']; ?></td>
                            </tr>
                        </table>
                    </div>
                    <br />
                    <table>
                        <tr>
                            <td style="font-size:18px; color:#2c4c09;">Description :</td>
                        </tr>
                        <tr>
                            <td><font style="font-size:14px;"><?php echo $row['Description']; ?>alsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfjalsdfjlasjfdl;asjfl;asjdflk;asjfdlk;ajsfdl;asjdflk;sajfkl;sajfdl;ksajdflk;asdfj</font></td>
                        </tr>
                    </table>
                    
                <?php
			}
			else
			{
				?>
                	<center><h1 style="color:#2c4c09;">No result found!</h1></center>
                <?php
			}
		?>
	</div>


         
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>