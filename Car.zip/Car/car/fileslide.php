<script src="javascript/jquery-1.6.2.min.js" type="text/javascript" charset="utf-8"></script>
<script src="javascript/jquery.jcarousel.min.js" type="text/javascript" charset="utf-8"></script>
<script src="javascript/functions.js" type="text/javascript" charset="utf-8"></script>
<fieldset>
    		<legend style="color:#4a5a38;font-weight:bold;">Premium Car</legend>
            <div id="showc">
                <?php
                    $sqla="SELECT a.*, c.* FROM tbl_advertise a, tbl_car c WHERE a.CarID=c.CarID AND a.Status='Active'";
                    $reta=mysql_query($sqla);
                    $numa=mysql_num_rows($reta);
                    
                    if($numa>0)
                    {
						?>
                        	<div id="main" class="shell">
                                <!-- Begin Content -->
                                <!-- Begin Products Slider -->
                                <div id="product-slider">
                                    <ul>
                                    <?php
										while($rowa=mysql_fetch_array($reta))
										{
											$retpa=GetCarPhotoByCarID($rowa['CarID']);
											$rowpa=mysql_fetch_array($retpa);
											?>
                                            	<li>
                                                    <a href="CarDetail.php?CarID=<?php echo $rowa['CarID']; ?>">
                                                    <img src="carphoto/Mini/<?php echo $rowpa['PhotoMini']; ?>" alt="Product Image" style="Width:100px;Height:90px; border:2px solid#30312f;"/>
                                                   <font style="margin-left:10px;"> <?php echo $rowa['Brand']; ?> <?php echo $rowa['CarName']; ?><br />
                                                    <?php echo $rowa['Model']; ?> - <?php echo $rowa['Price']; ?></font>
                                                    </a>
                                                </li>
                                            <?php
										}
									?>
                                    </ul>
                                </div>
                                <!-- End Products Slider -->
                            </div>
                        <?php
                    }
                ?>
            </div>
        </fieldset>