<?php

require_once("library/db.php");

$sql="SELECT * FROM tbl_car ORDER BY CarID DESC";
$ret=mysql_query($sql);
$num=mysql_num_rows($ret);

/*
$array=array();

for($i=0;$i<$num;$i++)
{
	$row=mysql_fetch_array($ret);
	$array[]=$row['Photo'];
}

$length = count($array);
for ($i = 0; $i < $length; $i++) {
  echo $array[$i] . "<br />";
}
*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Testing</title>

</head>

<body onload="Start();">
<div style="width:500px; height:auto; overflow:hidden; border:1px solid blue; margin-left:50px; margin-top:20px;" id="P">
	<?php
		for($i=0;$i<$num;$i++)
		{
			$row=mysql_fetch_array($ret);
			echo $row['Photo'] . "<br />";
		}
	?>
</div>
</body>
</html>