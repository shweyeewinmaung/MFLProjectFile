<?php
require_once("library/db.php");
require_once("library/globalfunction.php");
require_once("dal/dal_car.php");

header('Content-Type: text/xml; charset=utf-8');


$Number = Clean($_GET["Number"]);

if($Number){
	$ret=Premium_Number($Number);
}

if(!$ret){
	echo "<p>Something went wrong: " . mysql_error(); + "</p>";
}

$noOfRows = mysql_num_rows($ret);

if ($noOfRows == 0) {
	die ("<p>No such entry</p>");
}
else {

	$doc = new DOMDocument(); 
	$doc->formatOutput = true; 

	$root = $doc->createElement('All_Data');
	$doc->appendChild($root);

	for ($i = 0; $i < $noOfRows; $i++) 
	{
		$row = mysql_fetch_array ($ret);

		$node = $doc->createElement("Cars"); 
		$CarID = $doc->createElement("CarID"); 	  					
		$Brand = $doc->createElement("Brand"); 
		$CarName = $doc->createElement("CarName");
		$Model = $doc->createElement("Model");
		$Photo = $doc->createElement("Photo"); 	  					
		$Price=$doc->createElement("Price"); 

		$CarID->appendChild($doc->createTextNode($row["CarID"]));
		$Brand->appendChild($doc->createTextNode($row["Brand"]));
		$CarName->appendChild($doc->createTextNode($row["CarName"]));
		$Model->appendChild($doc->createTextNode($row["Model"]));
		$Photo->appendChild($doc->createTextNode($row["Photo"]));
		$Price->appendChild($doc->createTextNode($row["Price"])); 
		  
		$node->appendChild($CarID);
		$node->appendChild($Brand);
		$node->appendChild($CarName);
		$node->appendChild($Model);
		$node->appendChild($Photo);
		$node->appendChild($Price); 	  
		$root->appendChild($node);
	}

	echo $doc->saveXML();
}
?>
