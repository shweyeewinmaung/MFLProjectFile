<?php

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Slider</title>
</head>
<script>
var count=0;
var maxi=14;

function Start()
{
	setInterval(function(){
      OnLoad()
    },5000);
}

function OnLoad()
{
	
	if(count==0)
	{
		
		document.getElementById('Premium').innerHTML="";
		
		DisplayPremium(0);
		DisplayPremium(1);
		DisplayPremium(2);
		DisplayPremium(3);
		DisplayPremium(4);
		DisplayPremium(5);
	}
	
	else if(count>0 && count<maxi)
	{
		document.getElementById('Premium').innerHTML="";
		
		DisplayPremium((count*6)+0);
		DisplayPremium((count*6)+1);
		DisplayPremium((count*6)+2);
		DisplayPremium((count*6)+3);
		DisplayPremium((count*6)+4);
		DisplayPremium((count*6)+5);
	}
	count +=1;
	
	
	if(maxi<=((count*6)+5))
	{
		document.getElementById('1').innerHTML=((count*6)+0) + " " + ((count*6)+1) + " " + ((count*6)+2) + " " + ((count*6)+3) + " " + ((count*6)+4) + " " + ((count*6)+5);
		count=0;
	}
	
}


function DisplayPremium(No)
{

	url="xml_Data.php?Number=" + No;
	
	// Usual code for creating an XMLHttpRequest object goes here.
	if (window.XMLHttpRequest)
	{
		// Code for modern browsers
		request=new XMLHttpRequest();
	}
	else 
	{
		// code for older versions of Internet Explorer
		request = new ActiveXObject("Microsoft.XMLHTTP");	 	 
	}
  	
	request.onreadystatechange=function() 
	{
		if (request.readyState==4 && request.status==200) 
		{     
			if (request.responseXML) 
			{	
				xml=request.responseXML;
				
				var ci, b, cn, mo, po, p;
				
				var elements = xml.documentElement.getElementsByTagName("Cars");
				
				CarID=elements[0].getElementsByTagName("CarID");
				Brand=elements[0].getElementsByTagName("Brand");
				CarName=elements[0].getElementsByTagName("CarName");
				Model= elements[0].getElementsByTagName("Model");
				Photo= elements[0].getElementsByTagName("Photo");
				Price=elements[0].getElementsByTagName("Price");
				
				ci=CarID[0].firstChild.nodeValue;
				b=Brand[0].firstChild.nodeValue;
				cn=CarName[0].firstChild.nodeValue;
				mo=Model[0].firstChild.nodeValue;
				po=Photo[0].firstChild.nodeValue;
				p=Price[0].firstChild.nodeValue;
				
				var data="";
				data="<div class='mini' align='center'>";
				data=data + "<a href='aaa.php?CarID=" + ci +"'>";
				data=data + "<img src='carphoto/" + po + "' width='100px;' height='90px;' /><br />";
				data=data + "<b>" + b + " " + cn + "</b><br />";
				data=data + mo + "<br />";
				data=data + p + "";
				data=data + "</a>";
				data=data + "</div>";
				
				var div = document.getElementById('Premium');
				div.innerHTML = div.innerHTML + data;
			}
		}
	}            	  
	request.open("GET", url, true);
	request.send();
	
	/*
	request.open ("GET", url, false);			
	request.send(); 
	var serverResponse = request.responseText;
	alert(serverResponse);
	*/			
}
</script>
<body onload="Start()">
<form>
	<div id="1" style="width:700px; height:auto; margin:0 auto;">
    	
    </div>
</form>
</body>
</html>