var OX_8ffa4dfb = '';
OX_8ffa4dfb += "<"+"a href=\'http://ads.rebbiz.com/www/delivery/ck.php?oaparams=2__bannerid=69__zoneid=20__cb=a1d29d529d__oadest=http%3A%2F%2Fwww.jimex.co.jp%2Fmy%2F\' target=\'_blank\'><"+"img src=\'http://ads.rebbiz.com/images/6e2a45b0a44b3965c70a14f200a02e9a.jpg\' width=\'300\' height=\'250\' alt=\'Jimex Banner\' title=\'Jimex Banner\' border=\'0\' /><"+"/a><"+"div id=\'beacon_a1d29d529d\' style=\'position: absolute; left: 0px; top: 0px; visibility: hidden;\'><"+"img src=\'http://ads.rebbiz.com/www/delivery/lg.php?bannerid=69&amp;campaignid=48&amp;zoneid=20&amp;loc=http%3A%2F%2Fwww.myanmarcarsdb.com%2F&amp;cb=a1d29d529d\' width=\'0\' height=\'0\' alt=\'\' style=\'width: 0px; height: 0px;\' /><"+"/div><"+"script type=\'text/javascript\'>document.context=\'Yjo2OXw=\'; <"+"/script>\n";
document.write(OX_8ffa4dfb);

if (document.OA_used) document.OA__used += 'bannerid:69,';

if (document.MAX_used) document.MAX_used += 'bannerid:69,';

if (document.phpAds_used) document.phpAds_used += 'bannerid:69,';
