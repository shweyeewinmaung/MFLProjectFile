var OX_65354b73 = '';
OX_65354b73 += "<"+"a href=\'http://ads.rebbiz.com/www/delivery/ck.php?oaparams=2__bannerid=64__zoneid=20__cb=ccbfa3aa2a__oadest=http%3A%2F%2Fwww.rixsmyanmar.com\' target=\'_blank\'><"+"img src=\'http://ads.rebbiz.com/images/c076a6edaa2422ce4618c58cd0f8a288.jpg\' width=\'300\' height=\'250\' alt=\'Rixs Myanmar International\' title=\'Rixs Myanmar International\' border=\'0\' /><"+"/a><"+"div id=\'beacon_ccbfa3aa2a\' style=\'position: absolute; left: 0px; top: 0px; visibility: hidden;\'><"+"img src=\'http://ads.rebbiz.com/www/delivery/lg.php?bannerid=64&amp;campaignid=43&amp;zoneid=20&amp;loc=http%3A%2F%2Fwww.myanmarcarsdb.com%2F&amp;cb=ccbfa3aa2a\' width=\'0\' height=\'0\' alt=\'\' style=\'width: 0px; height: 0px;\' /><"+"/div><"+"script type=\'text/javascript\'>document.context=\'Yjo2OSNiOjY0fA==\'; <"+"/script>\n";
document.write(OX_65354b73);

if (document.OA_used) document.OA__used += 'bannerid:64,';

if (document.MAX_used) document.MAX_used += 'bannerid:64,';

if (document.phpAds_used) document.phpAds_used += 'bannerid:64,';
