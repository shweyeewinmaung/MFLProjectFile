var OX_5f606547 = '';
OX_5f606547 += "<"+"img src=\'http://ads.rebbiz.com/images/6e7da07f658ea6e2fb5d27de94b50d27.jpg\' width=\'300\' height=\'250\' alt=\'Autocar Buyers&#039; Guide Journal\' title=\'Autocar Buyers&#039; Guide Journal\' border=\'0\' /><"+"div id=\'beacon_c0bddaa3b8\' style=\'position: absolute; left: 0px; top: 0px; visibility: hidden;\'><"+"img src=\'http://ads.rebbiz.com/www/delivery/lg.php?bannerid=65&amp;campaignid=44&amp;zoneid=20&amp;loc=http%3A%2F%2Fwww.myanmarcarsdb.com%2F&amp;cb=c0bddaa3b8\' width=\'0\' height=\'0\' alt=\'\' style=\'width: 0px; height: 0px;\' /><"+"/div><"+"script type=\'text/javascript\'>document.context=\'Yjo2OSNiOjY0I2I6NjV8\'; <"+"/script>\n";
document.write(OX_5f606547);

if (document.OA_used) document.OA__used += 'bannerid:65,';

if (document.MAX_used) document.MAX_used += 'bannerid:65,';

if (document.phpAds_used) document.phpAds_used += 'bannerid:65,';
