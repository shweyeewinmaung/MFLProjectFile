<?php
session_start();
include("library/db.php");
include("library/globalfunction.php");
require_once("dal/dal_user.php");


if(isset($_SESSION['SESS']['User']['UserID']))
{
	header("Location:Profile.php");
}

$UserName=Clean($_POST['txtname']);
$Password=Clean($_POST['txtpassword']);

$ret=GetLogInData($UserName, $Password);
$num=mysql_num_rows($ret);

if($num>0)
{
	$row=mysql_fetch_array($ret);
	$_SESSION['SESS']['User']['UserID']=$row['UserID'];
	$_SESSION['SESS']['User']['FullName']=$row['FullName'];
	$_SESSION['SESS']['User']['Role']=$row['Role'];
	$_SESSION['SESS']['User']['Status']=$row['Status'];
	header("location:index.php");
}
else
{
	$_SESSION['LogIn']="Fail";
	header("location:LogIn.php");
}
?>