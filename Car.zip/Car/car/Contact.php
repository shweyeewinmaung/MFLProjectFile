<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>
<link rel="stylesheet" type="text/css" href="css/tab.css"/>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/organic.js"></script>
</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar" >
   

        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px; ">
       
         <div class="span8" id="divMain">

    <h1 style="color:#2c4c09; text-align:center;">Contact Us</h1>
    
    <hr>
    <!--Start Contact form -->		                                                
    <form>
    	<table style="font-size:14px;">	
        		<tr style="border-bottom:2px solid#333;" height="40">
                	<td width="20%" style=" padding-left:50px;">Name : </td>
                    <td><input type="text" name="name" value=""   placeholder="Name" style="width:500px; height:25px;" /></td>
                </tr>
                <tr style="border-bottom:2px solid#333;" height="40">
                	<td width="20%" style=" padding-left:50px;">Email : </td>
                    <td><input type="text" name="name" value=""   placeholder="Email" style="width:500px; height:25px;" /></td>
                </tr>
                <tr style="border-bottom:2px solid#333;" height="100px;">
                	<td width="20%" style=" padding-left:50px;">Comment : </td>
                    <td><textarea name="comment" rows="5" cols="74" placeholder="Comment"></textarea></td>
                </tr>
    			<tr>
                	 <td></td>	
               		 <td><input type="submit" value="Send" class="btnstyle" name="btnSend"/>
                    	 <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle" ><br><br>
                     </td>
                </tr>
    
   		</table>
  
	
    </form>  				 
    <!--End Contact form -->											 
</div>
         
         
         
         </div><!---------Form End----------->

	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>