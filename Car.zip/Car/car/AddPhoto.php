<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_car.php");
require_once("dal/dal_brand.php");
require_once("dal/dal_township.php");
require_once("library/function.php");
require_once("library/globalfunction.php");

include("Permission.php");

if(isset($_POST['CarID']) && $_POST['CarID']!="")
{	
	$CarID=Clean($_POST['CarID']);
	
	$Mini="";
	$Large="";
	
	
	$filecheck1 = basename($_FILES['Photo']['name']);
	$ext1 = strtolower(substr($filecheck1, strrpos($filecheck1, '.') + 1));
	$path = 'carphoto/mini/';
	

	if (($ext1 == "jpg" || $ext1 == "gif" || $ext1 == "png") && (($_FILES["Photo"]["type"] == "image/jpeg") || ($_FILES["Photo"]["type"] == "image/gif") || ($_FILES["Photo"]["type"] == "image/png")) && 
    (($_FILES["Photo"]["size"] < 16960000) && ($_FILES["Photo"]["size"] > 0))){ 


		$fileName1 = $_FILES['Photo']['name'];
		$Large = $fileName1;
		$tmpName  = $_FILES['Photo']['tmp_name'];
		$fileSize = $_FILES['Photo']['size'];
		$fileType = $_FILES['Photo']['type'];
		
		$thumb_img = 'thumb_'.mt_rand().$fileName1;
		
		$tmp = $_FILES['Photo']['tmp_name'];
		if(move_uploaded_file($tmp, $path.time().$fileName1))
		//echo $path.time().$fileName1 . "<br />";
		$Photo = time().$fileName1;
		$pic_type = strtolower(strrchr($fileName1,"."));
 
		$thumb = 'thumb'.mt_rand().'100x100'.$pic_type;
		$Mini = $thumb;

		if (true !== ($pic_error = @image_resize($path.time().$fileName1, $path.$thumb, 300, 300, 1))) {
			//echo $pic_error;
			
			unlink($pic_name);
		}
		//rename($path.$thumb, 'carphoto/'.$thumb_img);
		
		
		//$PhotoLarge = $_FILES['Photo']['name'];		
		$Folder = "carphoto/"; 
		$FileName="-";
		
		if(isset($_FILES['Photo']['name'])) 
		{ 
		  $FileName = time() . "_" . mt_rand() . ".png";
	
		  $copied = copy($path.time().$fileName1, $Folder . $FileName); 
		  //rename("carphoto/" . $_FILES['Photo']['name'], "carphoto/" . $FileName);
		  if (!$copied) 
		  { 			  
			exit("Problem occured. Cannot Upload Item Photo.");
		  }
		}
	}
	
	
	
	//InsertCar($CarID, $CarNo, $BrandID, $CarName, $Model, $Kilo, $Gear, $Fuel, $CarType, $Description, $ContactPerson, $ContactNumber, $TownshipID, $Price, $EnginePower, $Mini, $Large, $UserID, $View, $Like,
	
	
	//InsertCar($CarID, $CarNo, $BrandID, $CarName, $Model, $Kilo, $Gear, $Fuel, $CarType, $Description, $ContactPerson, $ContactNumber, $TownshipID, $Price, $EnginePower, $Mini, $Large, $UserID, $View, $Like, $CarStatus, $Status, $PublishDate, $PublishTime);
	
	//header("Location:AddPhoto.php?CarID=$CarID");
	
	InsertCarPhoto($CarID, $Mini, $FileName);
	
}

if($_GET['CarID'] && $_GET['CarID']!="")
{
	$CarID=Clean($_GET['CarID']);
	$ret=GetCarDataByCarID($CarID);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
	else
	{
		header("Location:MyCar.php");
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>

</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         
         <div style="width:400px; margin:10px auto;font-size:16px;border-radius:10px;">
		<form method="POST" enctype="multipart/form-data">
            <table style="margin:0 auto;">
            <tr>
                    <td colspan="2"><h1 style="color:#2c4c09; margin-left:150px;">Add Photo</h1></td>
                    
                </tr>
            	<tr>
                    <td style="float:right; height:25px;">CarID : </td>
                    <td><?php echo $row['CarID'] ?><input type="hidden" name="CarID" value="<?php echo $row['CarID'] ?>" /></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">Car No  : </td>
                    <td><?php echo $row['CarNo'] ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">Car Brand  : </td>
                    <td><?php echo GetBrandNameByBrandID($row['Brand']) ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">Car Name  : </td>
                    <td><?php echo $row['CarName'] ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">Model  : </td>
                    <td><?php echo $row['Model'] ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">Kilo  : </td>
                    <td><?php echo $row['Kilo'] ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">Gear  : </td>
                    <td><?php echo $row['Gear'] ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">Fuel  : </td>
                    <td><?php echo $row['Fuel'] ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">CarType  : </td>
                    <td><?php echo $row['CarType'] ?></td>
                </tr>
                <tr>
                    <td valign="top" style="float:right; height:25px;">Description  : </td>
                    <td><?php echo $row['Description'] ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">ContactPerson  : </td>
                    <td><?php echo $row['ContactPerson'] ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">ContactNumber  : </td>
                    <td><?php echo $row['ContactNumber'] ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">Township  : </td>
                    <td><?php echo GetTownshipNameByTownshipID($row['TownshipID']) ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">Price  : </td>
                    <td><?php echo $row['Price'] ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">EnginePower  : </td>
                    <td><?php echo $row['EnginePower'] ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">Status  : </td>
                    <td><?php echo $row['CarStatus'] ?></td>
                </tr>
                <tr>
                    <td style="float:right; height:25px;">Photo  : </td>
                    <td><input type="file" name="Photo" required/></td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                    <input type="submit" value="Add Photo" class="btnstyle"/>
                    <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle" ><br><br>
                    </td>
                </tr>
            </table>
            <br /><br />
            <div style="width:100%; height:auto; overflow:hidden; margin:0 auto;">
            <center>
            <?php
				$retp=GetCarPhotoAllByCarID($row['CarID']);
				while($rowp=mysql_fetch_array($retp))
				{
					?>
                    	<img src="carphoto/Mini/<?php echo $rowp['PhotoMini']; ?>" style="width:90px; height:80px;" />
                    <?php
				}
			?>
            </center>
            </div>
        </form>
	</div>
         
         
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>