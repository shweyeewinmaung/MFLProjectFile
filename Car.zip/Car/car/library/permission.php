<?php
if($_SESSION['SESS']['User']['Role']!="Admin")
{
	header("Location:../index.php");
}
?>