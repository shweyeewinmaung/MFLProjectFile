<?php
require_once("../library/db.php");
require_once("../dal/dal_user.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");

if (isset($_POST['FullName']) && isset($_POST['DOB']) && isset($_POST['Phone']) && isset($_POST['Email']))
{	
	$UserID=AutoID('tbl_user','UserID','Usr-',6);
	$FullName=Clean($_POST['FullName']);
	$DOB=Clean($_POST['DOB']);
	$Gender=Clean($_POST['Gender']);
	$Phone=Clean($_POST['Phone']);
	$Email=Clean($_POST['Email']);
	$UserName=Clean($_POST['UserName']);
	$Password=Clean($_POST['Password']);
	$Role=Clean($_POST['Role']);
	$Status=Clean($_POST['Status']);
	
	
	InsertUser($UserID, $FullName, $DOB, $Gender, $Phone, $Email, $UserName, $Password, $Role, $Status);
	$msg="Successfully Save User";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="../css/tablestyle.css"/>

</head>
<body>
   <?php include("../template/headeradmin.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         <form method="POST" enctype="multipart/form-data">
	<table style="margin:0 auto; color:#000; font-size:16px;">
		<tr><td colspan="2"><h1 style="color:#2c4c09; margin-left:100px;">Register Here!!!</h1></td></tr>
          <tr><td colspan="2">
       <font style="color:red; font-size:18px; line-height:50px;"><?php echo $msg; ?> </font></td></tr>
			<tr>
					<td class="fontstyle" style="float:right;">Full Name : </td>
					<td><input type="text" name="FullName" required class="textboxstyle"/></td>
				</tr>
				<tr>
					<td class="fontstyle" style="float:right;">Date Of Birth : </td>
					<td><input type="text" name="DOB" required class="textboxstyle"></td>
				</tr>
				<tr>
					<td class="fontstyle" style="float:right;">Gender : </td>
					<td><input type="text" name="Gender"  required class="textboxstyle"></td>
				</tr>
				<tr>
					<td class="fontstyle" style="float:right;">Phone : </td>
					<td><input type="text" name="Phone" required class="textboxstyle"/></td>
				</tr>
				<tr>
					<td class="fontstyle" style="float:right;">Email : </td>
					<td><input type="text" name="Email" required class="textboxstyle"/></td>
				</tr>
				<tr>
					<td class="fontstyle" style="float:right;">UserName : </td>
					<td><input type="text" name="UserName" required class="textboxstyle"/></td>
				</tr>
				<tr>
					<td class="fontstyle" style="float:right;">Password : </td>
					<td><input type="text" name="Password" required class="textboxstyle"/></td>
				</tr>
				<tr>
					<td class="fontstyle" style="float:right;">Role : </td>
					<td><select name="Role" style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                    	<option>Member</option>
                        <option>Admin</option>
                    </select></td>
				</tr>
				<tr>
					<td class="fontstyle" style="float:right;">Status : </td>
					<td><select name="Status" style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                    	<option>Active</option>
                        <option>Inactive</option>
                    </select></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="Register" class="btnstyle"/> 
                    <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle" ><br><br></td>
				</tr>
			</table>
		</form>
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("../template/sidebaradmin.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("../template/footeradmin.php"); ?>
   </body>
</html>

