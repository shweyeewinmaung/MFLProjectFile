<?php
session_start();

require_once("../library/db.php");
require_once("../dal/dal_car.php");
require_once("../dal/dal_brand.php");
require_once("../dal/dal_township.php");
require_once("../library/function.php");
require_once("../library/pager_car.php");
require_once("../library/globalfunction.php");

$pageSize=10;



if(isset($_GET['page']))
{
	$currentPageIndex=Clean($_GET['page']);
}
else
{
	$currentPageIndex=1;
}
$objPager=new pager($pageSize,$currentPageIndex);

$sql=$objPager->SearchData_GetAllCar();
$ret=$objPager->Search_Data($sql);
$num=mysql_num_rows($ret);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="../css/tablestyle.css"/>
<style>
.linkstyle{ color:#2c4c09; text-decoration:underline;}
.linkstyle:hover{color:#0F0; text-decoration:underline;}
</style>
</head>
<body>
   <?php include("../template/headeradmin.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         <div style="width:600px; margin:10px auto;  border-radius:10px; font-size:16px;">
		<form method="POST" enctype="multipart/form-data">
            
                <center><h1 style="color:#2c4c09; margin-left:150px; padding-bottom:20px;">All View Car</h1></center>
                <?php
					if($num>0)
					{
						?>
                        	
                        <?php
						for($i=0;$i<$num;$i++)
						{
							$row=mysql_fetch_array($ret);
						?>
                        <table style="margin:0 auto; <?php if($i>0){ echo " margin-top:10px;"; } ?>">
                            <tr>
                                <td rowspan="3" width="10%"><img src="../carphoto/<?php echo $row['Photo']; ?>" width="100px;" height="100px;" style="border:2px solid#666;" /></td>
                                <td >Brand : <?php echo GetBrandNameByBrandID($row['2']); ?></td>
                                <td>Name : <?php echo $row['CarName']; ?></td>
                                <td>Model : <?php echo $row['Model']; ?></td>
                                <td rowspan="3"  colspan="2"><a href="EditCar.php?CarID=<?php echo $row['CarID']; ?>"><font class="linkstyle">Edit</font></a>
                               <br /><a href="Advertise.php?CarID=<?php echo $row['CarID']; ?>"><font class="linkstyle">Advertise</font></a></td>
                            </tr>
                            <tr>
                                <td>Engine : <?php echo $row['EnginePower']; ?></td>
                                <td>Brand : <?php echo GetBrandNameByBrandID($row['2']); ?></td>
                                <td>Price : <?php echo $row['Price']; ?></td>
                            </tr>
                            <tr>
                                <td>Owner : <?php echo $row['ContactPerson']; ?></td>
                                <td>Owner No :<?php echo $row['ContactNumber']; ?></td>
                                <td>Car Status : <?php echo $row['CarStatus']; ?></td>
                            </tr> 
                            <tr><td colspan="5" style="color:#2c4c09;">------------------------------------------------------------------------------------------------------------------------</td></tr> 
						</table>
                        <?php
						}
						
					}
					else
					{
						?>
                        	<center>Not available!</center>
                        <?php
					}
				?>
                
            
            <br />
            <?php
                	$objPager->Generate_Pager($str);
                ?>
        </form>
	</div>
         
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("../template/sidebaradmin.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("../template/footeradmin.php"); ?>
   </body>
</html>