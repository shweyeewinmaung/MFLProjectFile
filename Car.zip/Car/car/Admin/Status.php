<?php
session_start();

require_once("../library/db.php");
require_once("../dal/dal_car.php");
require_once("../dal/dal_advertise.php");
require_once("../dal/dal_brand.php");
require_once("../dal/dal_township.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");


if(isset($_GET['AID']) && $_GET['AID']!="" && isset($_GET['CarID']) && $_GET['CarID']!="" && isset($_GET['Status']) && ($_GET['Status']=="Inactive" || $_GET['Status']=="Active"))
{
	$AID=Clean($_GET['AID']);
	$CarID=Clean($_GET['CarID']);
	$Status=Clean($_GET['Status']);
	
	UpdateA_Status($Status, $AID);
	header("Location:Status.php?CarID=$CarID");
}


if (isset($_GET['CarID']) && $_GET['CarID']!="")
{	
	$CarID=Clean($_GET['CarID']);
	$ret=GetCarDataByCarID($CarID);
	$num=mysql_num_rows($ret);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="../css/tablestyle.css"/>
<link href="../javascript/DatePicker/datepicker.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../javascript/DatePicker/datepicker.js"></script>
<style>
.linkstyle{ color:#2c4c09; text-decoration:underline;}
.linkstyle:hover{color:#2c4c09; text-decoration:underline;}
</style>

</head>
<body>
   <?php include("../template/headeradmin.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         
         


<div style="width:620px; margin:10px auto;border-radius:10px; font-size:16px;">
		<?php
			if($num>0)
			{
				$retA=GetA_CarDataByCarID($CarID);
				$numA=mysql_num_rows($retA);
				
				$row=mysql_fetch_array($ret);
				
				if($numA>0)
				{
					$rowA=mysql_fetch_array($retA);
				}
				?>
                	<form method="POST">
	                    <input type="hidden" name="CarID" value="<?php echo $row['CarID']; ?>" readonly />
                        <?php
							if($numA>0)
							{
								?>
                                	<input type="hidden" name="AID" value="<?php echo $rowA['AID']; ?>" readonly />
                                <?php
							}
						?>
                        
                        <div style="width:600px; margin:60px auto; padding:20px; border:1px solid black; background-color:#d2f7a9; border-radius:10px;">
                            <table width="100%">
                                <tr>
                                    <td rowspan="3" width="10%"><img src="../carphoto/<?php echo $row['Photo']; ?>" width="100px;" height="100px;" style="border:2px solid#666;" /></td>
                                    <td width="30%">Brand : <?php echo GetBrandNameByBrandID($row['2']); ?></td>
                                    <td width="30%">Name : <?php echo $row['CarName']; ?></td>
                                    <td width="25%">Model : <?php echo $row['Model']; ?></td>
                                    <td rowspan="3" width="10%"><center><label style="color:#2c4c09;"><b>Current</b></label><br /><label style="color:brown;"><b>
                                    <?php
										if($numA>0)
										{
											echo $rowA['AStatus'];
										}
										else
										{
											echo "Free";
										}
									?>
                                    </b></label><br />
                                    And
                                    <label style="color:brown;"><b><?php echo $rowA['Status']; ?></b></label>
                                    </center></td>
                                    <td rowspan="3" width="10%">
                                    <?php
										if($rowA['Status']=="Inactive")
										{
											?>
                                            	<a href="Status.php?AID=<?php echo $rowA['AID']; ?>&CarID=<?php echo $rowA['CarID']; ?>&Status=Active"><font class="linkstyle">Active</font></a>
                                            <?php
										}
										else
										{
											?>
                                            	<a href="Status.php?AID=<?php echo $rowA['AID']; ?>&CarID=<?php echo $rowA['CarID']; ?>&Status=Inactive"><font class="linkstyle">Inactive</font></a>
                                            <?php
										}
									?>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Engine : <?php echo $row['EnginePower']; ?></td>
                                    <td>Brand :<?php echo GetBrandNameByBrandID($row['2']); ?></td>
                                    <td>Price : <?php echo $row['Price']; ?></td>
                                </tr>
                                <tr>
                                    <td>Owner : <?php echo $row['ContactPerson']; ?></td>
                                    <td>Owner No :<?php echo $row['ContactNumber']; ?></td>
                                    <td>Car Status : <?php echo $row['CarStatus']; ?></td>
                                </tr>
                            </table><br /><br />
                        </div>
                    </form>
                <?php
			}
			else
			{
				?>
                	<center><h2>No available!</h2></center>
                <?php
			}
		?>
	</div>
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("../template/sidebaradmin.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("../template/footeradmin.php"); ?>
   </body>
</html>