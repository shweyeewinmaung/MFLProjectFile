<?php
session_start();

require_once("../library/db.php");
require_once("../dal/dal_car.php");
require_once("../dal/dal_brand.php");
require_once("../dal/dal_township.php");
require_once("../library/function.php");
require_once("../library/pager_car.php");
require_once("../library/globalfunction.php");




if(isset($_POST['CarID']) && isset($_POST['btnCarID']))
{
	$CarID=Clean($_POST['CarID']);
	$ret=GetCarDataByCarID($CarID);
	$num=mysql_num_rows($ret);
}



elseif(isset($_POST['CarNo']) && isset($_POST['btnCarNo']))
{
	$CarNo=Clean($_POST['CarNo']);
	$ret=GetCarDataByCarNo($CarNo);
	$num=mysql_num_rows($ret);
}



elseif(isset($_POST['CarName']) && isset($_POST['btnCarName']))
{
	$CarName=Clean($_POST['CarName']);
	$ret=GetCarDataByCarName($CarName);
	$num=mysql_num_rows($ret);
}



elseif(isset($_POST['Contact']) && isset($_POST['btnContact']))
{
	$Contact=Clean($_POST['Contact']);
	$ret=GetCarDataByContact($Contact);
	$num=mysql_num_rows($ret);
}



elseif(isset($_POST['CarStatus']))
{
	$CarStatus=Clean($_POST['CarStatus']);
	$ret=GetCarDataByCarStatus($CarStatus);
	$num=mysql_num_rows($ret);
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="../css/tablestyle.css"/>
<style>
.linkstyle{ color:#2c4c09; text-decoration:underline;}
.linkstyle:hover{color:#2c4c09; text-decoration:underline;}
</style>
</head>
<body>
   <?php include("../template/headeradmin.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         <div style="width:600px; margin:10px auto; border-radius:10px; font-size:16px;">
		<form method="POST" enctype="multipart/form-data">
            <table width="600">
				<tr>
            	<td colspan="6" ><h1 style="color:#2c4c09; line-height:30px; text-align:center;">Search Car </h1></td>
            </tr>
               
               	<tr style="text-align:center; color:#2c4c09">
                	<td width="20%">CarID</td>
                    <td width="20%">Car No</td>
                    <td width="20%">Car Name</td>
                    <td width="20%">Contact Person / Number</td>
                    <td width="20%">Car Status</td>
                </tr>
                <tr>
                	<td><input type="text" name="CarID" style="width:90px; height:22px; border:2px solid#666;" /></td>
                    <td><input type="text" name="CarNo" style="width:90px; height:22px; border:2px solid#666;" /></td>
                    <td><input type="text" name="CarName" style="width:90px; height:22px; border:2px solid#666;" /></td>
                    <td><input type="text" name="Contact"  style="width:90px; height:22px; border:2px solid#666;"/></td>
                    <td><select name="CarStatus" style="width:90px; height:28px; border:2px solid#666;">
                    	<?php
                    		?>
                            	<option>Normal</option>
                                <option>Favourite</option>
                                <option>Popular</option>
                                <option>Premium</option>
                            <?php
						?>
					</select></td>
                </tr>
                <tr>
                	<td><input type="submit" name="btnCarID" value="Search"  class="btnstyle"/></td>
                    <td><input type="submit" name="btnCarNo" value="Search" class="btnstyle"/></td>
                    <td><input type="submit" name="btnCarName" value="Search" class="btnstyle"/></td>
                    <td><input type="submit" name="btnContact" value="Search" class="btnstyle"/></td>
                    <td><input type="submit" name="btnCarStatus" value="Search"  class="btnstyle"/></td>
                </tr>
            </table>
            <br /><br />
            <?php
				if($num>0)
				{
					for($i=0;$i<$num;$i++)
					{
					$row=mysql_fetch_array($ret);
					?>
                    	<div style="width:600px; margin:60px auto; padding:20px; border:1px solid black; background-color:#d2f7a9; border-radius:10px;     padding-right: 10px;
}">
                            <table>
                                <tr>
                                    <td rowspan="3" width="10%"><img src="../carphoto/<?php echo $row['Photo']; ?>" width="100px;" height="100px;"  style="border:2px solid#666;"/></td>
                                    <td width="30%">Brand - <?php echo $row['Brand']; ?></td>
                                    <td width="30%">Name - <?php echo $row['CarName']; ?></td>
                                    <td width="25%">Model - <?php echo $row['Model']; ?></td>
                                    <td rowspan="3" width="5%" colspan="2"><a href="EditCar.php?CarID=<?php echo $row['CarID']; ?>"><img src="../images/wrench-screwdriver.png" width="20" height="20" alt="" /></a>
                                    <br /><a href="Advertise.php?CarID=<?php echo $row['CarID']; ?>"><font class="linkstyle">Advertise</font></a></td>
                                </tr>
                                <tr>
                                    <td>Engine - <?php echo $row['EnginePower']; ?></td>
                                    <td>Brand - <?php echo $row['Brand']; ?></td>
                                    <td>Price - <?php echo $row['Price']; ?></td>
                                </tr>
                                <tr>
                                    <td>Owner - <?php echo $row['ContactPerson']; ?></td>
                                    <td>Owner No -<?php echo $row['ContactNumber']; ?></td>
                                    <td>Car Status - <?php echo $row['CarStatus']; ?></td>
                                </tr>
                            </table>
                        </div>
                    <?php
					}
				}
			?>
        </form>
	</div>
    
         
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("../template/sidebaradmin.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("../template/footeradmin.php"); ?>
   </body>
</html>
