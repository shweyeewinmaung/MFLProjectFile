<?php
	session_start();
	include("../library/db.php");
	include("../dal/dal_city.php");
	include("../dal/dal_township.php");
	include("../library/function.php");
	require_once("../library/globalfunction.php");

	if (isset($_POST['txtCityName']))
	{
		$CityID=Clean($_POST['txtCityID']);
		$CityName=Clean($_POST['txtCityName']);
		$ret=GetCityDataBy_CityName($CityName);
		
		$num=mysql_num_rows($ret);
		if($num>0)
		{
			$_SESSION['CityName']="Exist";
		}else{
			InsertCity($CityID,$CityName);
			$_SESSION['CityName']="Success";
		}
	}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="../css/tablestyle.css"/>

</head>
<body>
   <?php include("../template/headeradmin.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         <form method="post" >
    	<table style="margin:0 auto; font-size:16px; color:#000;" >
        <tr>
					<td colspan="2"><h1 style="color:#2c4c09; margin-left:100px;"> Add City</h1></td>
					
				</tr>
       <tr><td colspan="2">
       <font style="color:red; font-size:18px; line-height:50px;">
        <?php
		 	if($_SESSION['CityName']=="Success"){ echo "City is Added"; unset($_SESSION['CityName']);}
		 ?>
        <?php 
			if($_SESSION['CityName']=="Exist"){ echo "Already Exist!"; unset($_SESSION['CityName']);}
		?></font>
        </td></tr>
        	<tr style="line-height:30px;">
            	<td style="float:right;">City ID : </td>
				<td><input type="text" name="txtCityID" value="<?php echo AutoID('tbl_city','CityID','Ct-',6)?>" readonly="readonly" class="textboxstyle"></td>            
            </tr>
            <tr style="line-height:30px;">
                <td style="float:right;">City Name : </td>
                <td><input type="text" name="txtCityName" required class="textboxstyle"></td>
			</tr>
            <tr >
             	<td>
                	
                </td>
                <td>
                	<input type="submit" value="Add" class="btnstyle"/>
                    <input name="Reset" type="reset" id="button" value="Clear" class="btnstyle" ><br><br>
                </td>
            </tr>
        </table>
	</form>
        
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("../template/sidebaradmin.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("../template/footeradmin.php"); ?>
   </body>
</html>