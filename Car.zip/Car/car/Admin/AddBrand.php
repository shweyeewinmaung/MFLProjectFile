<?php
session_start();

require_once("../library/db.php");
require_once("../dal/dal_brand.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");

if (isset($_POST['BrandName']))
{	
	$BrandName=Clean($_POST['BrandName']);
	$UserID=$_SESSION['SESS']['User']['UserID'];
	
	$ret=GetBrandDataByBrandName($BrandName);
		
	$num=mysql_num_rows($ret);
	if($num>0)
	{
		$_SESSION['BrandName']="Exist";
	}else{
		InsertBrand($BrandName, $UserID);
		$_SESSION['BrandName']="Success";
	}
	
	
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="../css/tablestyle.css"/>

</head>
<body>
   <?php include("../template/headeradmin.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
        <form method="POST">
	<table style="margin:0 auto; font-size:16px; color:#000;">
    <tr>
					<td colspan="2"><h1 style="color:#2c4c09; margin-left:100px;"> Add Brand</h1></td>
					
				</tr>
		<tr><td colspan="2">
       <font style="color:red; font-size:18px; line-height:50px;"> <?php
		 	if($_SESSION['BrandName']=="Success"){ echo "Brand is Added"; unset($_SESSION['BrandName']);}
		 ?>
        <?php 
			if($_SESSION['BrandName']=="Exist"){ echo "Already Exist!"; unset($_SESSION['BrandName']);}
		?></font>
        </td></tr>
			<tr>
					<td style="float:right;">Car Brand : </td>
					<td><input type="text" name="BrandName" required class="textboxstyle" /></td>
				</tr>
				<tr>
					<td></td>
					<td>
                    <input type="submit" value="Add" class="btnstyle"/>
                    <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle" ><br><br>
                    </td>
				</tr>
			</table>
</form>
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("../template/sidebaradmin.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("../template/footeradmin.php"); ?>
   </body>
</html>
	

