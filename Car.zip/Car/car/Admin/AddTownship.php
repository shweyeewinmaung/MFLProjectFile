<?php
session_start();
include("../library/db.php");
include("../dal/dal_city.php");
include("../dal/dal_township.php");
include("../library/function.php");
require_once("../library/globalfunction.php");

if (isset($_POST['txtTownshipName']))
{
	$TownshipID=Clean($_POST['txtTownshipID']);
	$CityName=Clean($_POST['txtCityName']);
	$TownshipName=Clean($_POST['txtTownshipName']);
	$sql=GetCityDataBy_CityName($CityName);
	while ($row = mysql_fetch_array($sql)){
		$CityID=$row['CityID'];
	}
	$num=mysql_num_rows(GetTownshipData_byTownshipName($TownshipName));
	if($num>0)
	{
		$_SESSION['TownshipName']="Exist";
	}else{
		InsertTownship($TownshipID,$CityID,$TownshipName);
		$_SESSION['TownshipName']="Success";
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="../css/tablestyle.css"/>

</head>
<body>
   <?php include("../template/headeradmin.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
          <form method="post">
    	<table  style="margin:0 auto; font-size:16px; color:#000;">
        <tr>
					<td colspan="2"><h1 style="color:#2c4c09; margin-left:100px;"> Add township</h1></td>
					
				</tr>
       <tr><td colspan="2">
       <font style="color:red; font-size:18px; line-height:50px;">  <?php
		 	if($_SESSION['TownshipName']=="Success"){ echo "Township is Added"; unset($_SESSION['TownshipName']);}
		 ?>
        <?php 
			if($_SESSION['TownshipName']=="Exist"){ echo "Already Exist!"; unset($_SESSION['TownshipName']);}
		?></font>
        </td></tr>
        	<tr style="line-height:30px;">
            	<td style="float:right;">
                Township ID : 
                </td>
				<td>
	                 <input type="text" name="txtTownshipID" class="textboxstyle" value="<?php echo AutoID('tbl_township','TownshipID','TB-',6)?>" readonly="readonly">
                </td>            
             </tr>
             <tr style="line-height:30px;">
                	<td style="float:right;">
                    City Name : 
                    </td>
                    <td>
                    	<select name="txtCityName" class="inputbox" style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                        <?php $sql = mysql_query("SELECT Distinct CityName FROM tbl_city");
							while ($row = mysql_fetch_array($sql)){
						?>
                        <option><?php echo $row['CityName']; ?></option>
                        <?php
						}?>
                        </select>
                    </td>
                </tr>

             <tr style="line-height:30px;">
             	<td style="float:right;">
                Township Name : 
                </td>
                <td>
                   	<input type="text" name="txtTownshipName" class="textboxstyle" /require>
                </td>
             </tr>
             <tr>
             	<td>
                	
                </td>
                <td>
                	 <input type="submit" value="Add" class="btnstyle"/>
                    <input name="Reset" type="reset" id="button" value="Clear" class="btnstyle" ><br><br>
                </td>
             </tr>
        </table>
	</form>
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("../template/sidebaradmin.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("../template/footeradmin.php"); ?>
   </body>
</html>