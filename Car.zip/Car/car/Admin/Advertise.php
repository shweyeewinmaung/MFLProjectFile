<?php
session_start();

require_once("../library/db.php");
require_once("../dal/dal_car.php");
require_once("../dal/dal_advertise.php");
require_once("../dal/dal_brand.php");
require_once("../dal/dal_township.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");


if(isset($_POST['btnAdvertise']) && isset($_POST['CarID']) && !isset($_POST['AID']))
{
	$CarID=Clean($_POST['CarID']);
	$StartDate=Clean(date("Y-m-d",strtotime($_POST['StartDate'])));
	$EndDate=Clean(date("Y-m-d",strtotime($_POST['EndDate'])));
	$AdminID=1;
	$Price=Clean($_POST['Price']);
	$AStatus=Clean($_POST['Advertise']);
	$Status="Active";
	
	if($AStatus=="Popular")
	{
		
		$numPC=GetA_PopularCount();
		if($numPC>=1)
		{
			?>
            	<script>alert('Popular type advertise is not available!');</script>
            <?php
		}
		else
		{
			InsertAdvertise($CarID, $AdminID, $StartDate, $EndDate, $Price, $AStatus, $Status);
		}
	}
	
	else if($AStatus=="Favourite")
	{
		$numFC=GetA_FavouriteCount();
		if($numPC>=4)
		{
			?>
            	<script>alert('Favourite type advertise is not available!');</script>
            <?php
		}
		else
		{
			InsertAdvertise($CarID, $AdminID, $StartDate, $EndDate, $Price, $AStatus, $Status);
		}
	}
	
	else if($AStatus=="Premium")
	{
		InsertAdvertise($CarID, $AdminID, $StartDate, $EndDate, $Price, $AStatus, $Status);
	}
	else if($AStatus=="Normal")
	{
		InsertAdvertise($CarID, $AdminID, $StartDate, $EndDate, $Price, $AStatus, $Status);
	}
}

elseif(isset($_POST['btnAdvertise']) && isset($_POST['AID']))
{
	$AID=Clean($_POST['AID']);
	$StartDate=Clean(date("Y-m-d",strtotime($_POST['StartDate'])));
	$EndDate=Clean(date("Y-m-d",strtotime($_POST['EndDate'])));
	$AdminID=1;
	$Price=Clean($_POST['Price']);
	$AStatus=Clean($_POST['Advertise']);
	$Status="Active";
	
	
	if($AStatus=="Popular")
	{
		$numPC=GetA_PopularCount();
		if($numPC>=1)
		{
			?>
            	<script>alert('Popular type advertise is not available!');</script>
            <?php
		}
		else
		{
			UpdateAdvertise($AID, $AdminID, $StartDate, $EndDate, $Price, $AStatus, $Status);
		}
	}
	
	else if($AStatus=="Favourite")
	{
		$numFC=GetA_FavouriteCount();
		if($numPC>=4)
		{
			?>
            	<script>alert('Favourite type advertise is not available!');</script>
            <?php
		}
		else
		{
			UpdateAdvertise($AID, $AdminID, $StartDate, $EndDate, $Price, $AStatus, $Status);
		}
	}
	
	else if($AStatus=="Premium")
	{
		$numPC=GetA_PremiumCount();
		if($numPC>=7)
		{
			?>
            	<script>alert('Premium type advertise is not available!');</script>
            <?php
		}
		else
		{
			UpdateAdvertise($AID, $AdminID, $StartDate, $EndDate, $Price, $AStatus, $Status);
		}
	}
	else if($AStatus=="Normal")
	{
		UpdateAdvertise($AID, $AdminID, $StartDate, $EndDate, $Price, $AStatus, $Status);
	}
}



if (isset($_GET['CarID']) && $_GET['CarID']!="")
{	
	$CarID=Clean($_GET['CarID']);
	$ret=GetCarDataByCarID($CarID);
	$num=mysql_num_rows($ret);
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="../css/tablestyle.css"/>
<link href="../javascript/DatePicker/datepicker.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../javascript/DatePicker/datepicker.js"></script>
</head>
<body>
   <?php include("../template/headeradmin.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         
         <div style="width:600; margin:10px auto; border-radius:10px; font-size:16px;">
		<?php
			if($num>0)
			{
				$retA=GetA_CarDataByCarID($CarID);
				$numA=mysql_num_rows($retA);
				
				$row=mysql_fetch_array($ret);
				
				if($numA>0)
				{
					$rowA=mysql_fetch_array($retA);
				}
				?>
                	<form method="POST">
	                    <input type="hidden" name="CarID" value="<?php echo $row['CarID']; ?>" readonly />
                        <?php
							if($numA>0)
							{
								?>
                                	<input type="hidden" name="AID" value="<?php echo $rowA['AID']; ?>" readonly />
                                <?php
							}
						?>
                        
                        <div style="width:600px; margin:10px auto; border-radius:10px;">
                            <table style=" width:600px;">
                            <tr><td colspan="5"><h1 style="color:#2c4c09; margin-left:200px;"> Advertise</h1></td></tr>
                                <tr>
                                    <td rowspan="3" width="10%"><img src="../carphoto/<?php echo $row['Photo']; ?>" width="100px;" height="100px;" style="border:2px solid#666;" /></td>
                                    <td width="30%">Brand :  <?php echo GetBrandNameByBrandID($row['2']); ?></td>
                                    <td width="30%">Name : <?php echo $row['CarName']; ?></td>
                                    <td width="25%">Model : <?php echo $row['Model']; ?></td>
                                    <td rowspan="3" width="10%"><center><label style="color:#2c4c09;"><b>Current</b></label><br /><br /><label style="color:#2c4c09;"><b>
                                    <?php
										if($numA>0)
										{
											echo $rowA['AStatus'];
										}
										else
										{
											echo "Free";
										}
									?>
                                    </b></label></center></td>
                                    
                                </tr>
                                <tr>
                                    <td>Engine : <?php echo $row['EnginePower']; ?></td>
                                    <td>Brand :  <?php echo GetBrandNameByBrandID($row['2']); ?></td>
                                    <td>Price : <?php echo $row['Price']; ?></td>
                                </tr>
                                <tr>
                                    <td>Owner : <?php echo $row['ContactPerson']; ?></td>
                                    <td>Owner No :<?php echo $row['ContactNumber']; ?></td>
                                    <td>Car Status : <?php echo $row['CarStatus']; ?></td>
                                </tr>
                            </table><br /><br />
                            
                            <table width="100%">
                            	<tr style="color:#2c4c09; font-size:16px; text-align:center;">
                                	<td>Start Date</td>
                                    <td>End Date</td>
                                    <td>Price</td>
                                    <td>Advertise Type</td>
                                    <td></td>
                                </tr>
                            	<tr  style="text-align:center;">
                                	<td><input type="text" name="StartDate" <?php if($numA>0){ echo "value='" . date("d-M-Y",strtotime($rowA['StartDate'])) . "'"; } ?> placeholder="dd-mm-yyyy" onFocus="showCalender(calender,this)" readonly="readonly" style="width:100px; height:25px; margin-left:7px; border: 2px solid#605858;"/></td>
                                    <td><input type="text" name="EndDate" <?php if($numA>0){ echo "value='" . date("d-M-Y",strtotime($rowA['EndDate'])) . "'";} ?> placeholder="dd-mm-yyyy" onFocus="showCalender(calender,this)" readonly="readonly" style="width:100px; height:25px; margin-left:7px; border: 2px solid#605858;"/></td>
                                    <td><input type="text" name="Price" <?php if($numA>0){ echo "value='" . $rowA['Price'] . "'"; } ?> style="width:100px; height:25px; margin-left:7px; border: 2px solid#605858;" required /></td>
                                    <td><select name="Advertise" required style="width:100px; height:30px; margin-left:7px; border: 2px solid#605858;">
                                    	<?php
											if($numA>0)
											{
												if($rowA['AStatus']=="Favourite")
												{
													?>
														<option>Favourite</option>
														<option>Popular</option>
														<option>Premium</option>
														<option>Normal</option>
													<?php
												}
												else if($rowA['AStatus']=="Popular")
												{
													?>
														<option>Popular</option>
                                                        <option>Favourite</option>
														<option>Premium</option>
														<option>Normal</option>
													<?php
												}
												else if($rowA['AStatus']=="Premium")
												{
													?>
                                                    	<option>Premium</option>
                                                        <option>Favourite</option>
                                                        <option>Popular</option>
														<option>Normal</option>
													<?php
												}
												else
												{
													?>
                                                    	<option>Normal</option>
                                                        <option>Favourite</option>
														<option>Popular</option>
														<option>Premium</option>
                                                    <?php
												}
											}
											else
											{
												?>
                                                	<option value="">--- Select ---</option>
                                                    <option>Favourite</option>
                                                    <option>Popular</option>
                                                    <option>Premium</option>
                                                    <option>Normal</option>
                                                <?php
											}
										?>
                                    </select></td>
                                    <td><input type="submit" name="btnAdvertise" class="btnstyle" value="<?php if($numA>0){ echo "Update"; }else{ echo "Advertise"; } ?>" /></td>
                                </tr>
                            </table>
                        </div>
                    </form>
                <?php
			}
			else
			{
				?>
                	<center><h2>No available!</h2></center>
                <?php
			}
		?>
	</div>







         
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("../template/sidebaradmin.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("../template/footeradmin.php"); ?>
   </body>
</html>
