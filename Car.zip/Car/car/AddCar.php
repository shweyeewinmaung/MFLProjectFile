<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_car.php");
require_once("dal/dal_brand.php");
require_once("dal/dal_township.php");
require_once("library/function.php");
require_once("library/globalfunction.php");

include("Permission.php");

if (isset($_POST['CarNo']) && isset($_POST['CarName']) && isset($_POST['Fuel']) && isset($_POST['Model']))
{	
	$CarID=AutoID('tbl_car','CarID','Car-',6);
	$CarNo=Clean($_POST['CarNo']);
	$BrandName=Clean($_POST['BrandName']);
	
	$retB=GetBrandDataByBrandName($BrandName);
	$rowB=mysql_fetch_array($retB);
	
	$BrandID=$rowB[0];
	
	$CarName=Clean($_POST['CarName']);
	$Model=Clean($_POST['Model']);
	$Kilo=Clean($_POST['Kilo']);
	$Gear=Clean($_POST['Gear']);
	$Fuel=Clean($_POST['Fuel']);
	$CarType=Clean($_POST['CarType']);
	$Description=Clean($_POST['Description']);
	$ContactPerson=Clean($_POST['ContactPerson']);
	$ContactNumber=Clean($_POST['ContactNumber']);
	$TownshipName=Clean($_POST['TownshipName']);
	
	$retT=GetTownshipData_byTownshipName($TownshipName);
	$rowT=mysql_fetch_array($retT);
	
	$TownshipID=$rowT[0];
	
	$Price=Clean($_POST['Price']);
	$EnginePower=Clean($_POST['EnginePower']);
	$UserID=$_SESSION['SESS']['User']['UserID'];
	$View="0";
	$Like="0";
	$Status="Active";
	$CarStatus=Clean($_POST['CarStatus']);
	$PublishDate=GetCurrentDate();
	$PublishTime=GetCurrentTime();
	$Mini="";
	$Large="";
	
	
	$filecheck1 = basename($_FILES['Photo']['name']);
	$ext1 = strtolower(substr($filecheck1, strrpos($filecheck1, '.') + 1));
	$path = 'carphoto/mini/';
	

	if (($ext1 == "jpg" || $ext1 == "gif" || $ext1 == "png") && (($_FILES["Photo"]["type"] == "image/jpeg") || ($_FILES["Photo"]["type"] == "image/gif") || ($_FILES["Photo"]["type"] == "image/png")) && 
    (($_FILES["Photo"]["size"] < 16960000) && ($_FILES["Photo"]["size"] > 0))){ 


		$fileName1 = $_FILES['Photo']['name'];
		$Large = $fileName1;
		$tmpName  = $_FILES['Photo']['tmp_name'];
		$fileSize = $_FILES['Photo']['size'];
		$fileType = $_FILES['Photo']['type'];
		
		$thumb_img = 'thumb_'.mt_rand().$fileName1;
		
		$tmp = $_FILES['Photo']['tmp_name'];
		if(move_uploaded_file($tmp, $path.time().$fileName1))
		$Photo = time().$fileName1;
		$pic_type = strtolower(strrchr($fileName1,"."));
 
		$thumb = 'thumb'.mt_rand().'100x100'.$pic_type;
		$Mini = $thumb;

		if (true !== ($pic_error = @image_resize($path.time().$fileName1, $path.$thumb, 300, 300, 1))) {
			//echo $pic_error;
			
			unlink($pic_name);
		}
		//rename($path.$thumb, 'carphoto/'.$thumb_img);
		
		
		//$PhotoLarge = $_FILES['Photo']['name'];		
		$Folder = "carphoto/"; 
		$FileName="-";
		
		if(isset($_FILES['Photo']['name'])) 
		{ 
		  $FileName = time() . "_" . mt_rand() . ".png";
	
		  $copied = copy($path.time().$fileName1, "carphoto/" . $FileName); 
		  //rename("carphoto/" . $_FILES['Photo']['name'], "carphoto/" . $FileName);
		  if (!$copied) 
		  { 			  
			exit("Problem occured. Cannot Upload Item Photo.");
		  }
		}
	}
	
	
	
	//InsertCar($CarID, $CarNo, $BrandID, $CarName, $Model, $Kilo, $Gear, $Fuel, $CarType, $Description, $ContactPerson, $ContactNumber, $TownshipID, $Price, $EnginePower, $Mini, $Large, $UserID, $View, $Like,
	
	
	InsertCar($CarID, $CarNo, $BrandID, $CarName, $Model, $Kilo, $Gear, $Fuel, $CarType, $Description, $ContactPerson, $ContactNumber, $TownshipID, $Price, $EnginePower, $UserID, $View, $Like, $CarStatus, $Status, $PublishDate, $PublishTime);
	
	InsertCarPhoto($CarID, $Mini, $FileName);
	
	header("Location:AddPhoto.php?CarID=$CarID");
	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>

</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         
        
	<div style="width:400px; margin:10px auto; border-radius:10px; font-size:16px;">
		<form method="POST" enctype="multipart/form-data">
            <table style="margin:0 auto;">
            <tr>
                    <td colspan="2"><h1 style="color:#2c4c09; margin-left:150px;">Add Car</h1></td>
                    
                </tr>
               
                <tr>
                    <td style="float:right;">Car No :</td>
                    <td><input type="text" name="CarNo" required  class="textboxstyle"></td>
                </tr>
                <tr>
                    <td style="float:right;">Car Brand : </td>
                    <td><select name="BrandName" style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                        <?php
                            $ret=GetAllBrandData();
                            
                            while($row=mysql_fetch_array($ret))
                            {
                                echo "<option>" . $row['BrandName'] . "</option>";
                            }
                        ?>
                    </select></td>
                </tr>
                <tr>
                    <td style="float:right;">Car Name : </td>
                    <td><input type="text" name="CarName" required class="textboxstyle"></td>
                </tr>
                <tr>
                    <td style="float:right;">Model : </td>
                    <td><input type="text" name="Model"  required class="textboxstyle"></td>
                </tr>
                <tr>
                    <td style="float:right;">Kilo : </td>
                    <td><input type="text" name="Kilo" required class="textboxstyle"/></td>
                </tr>
                <tr>
                    <td style="float:right;">Gear : </td>
                    <td><select name="Gear" style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                        <option>Auto</option>
                        <option>Manual</option>
                    </select></td>
                </tr>
                <tr>
                    <td style="float:right;">Fuel : </td>
                    <td><select name="Fuel" style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                        <option>Petrol</option>
                        <option>Disel</option>
                        <option>CNG</option>
                    </select></td>
                </tr>
                <tr>
                    <td style="float:right;">CarType : </td>
                    <td><select name="CarType" style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                        <option>Sedan</option>
                        <option>Hatchback</option>
                        <option>Stationwagon</option>
                        <option>Sports</option>
                        <option>SUV</option>
                        <option>Truck</option>
                        <option>Bus</option>
                        <option>Others</option>
                        <option>MPV(Minivan)</option>
                    </select></td>
                </tr>
                <tr>
                    <td valign="top" style="float:right;">Description : </td>
                    <td><textarea name="Description" required  style="margin-left:7px;border: 2px solid#605858;width:200px;" rows="3" cols="2"></textarea></td>
                </tr>
                <tr>
                    <td style="float:right;">ContactPerson : </td>
                    <td><input type="text" name="ContactPerson" required class="textboxstyle"/></td>
                </tr>
                <tr>
                    <td style="float:right;">ContactNumber : </td>
                    <td><input type="text" name="ContactNumber" required class="textboxstyle"/></td>
                </tr>
                <tr>
                    <td style="float:right;">Township : </td>
                    <td><select name="TownshipName" style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                    <?php
                        $ret=getAllTownshipData();
                        
                        while($row=mysql_fetch_array($ret))
                        {
                            echo "<option>" . $row['TownshipName'] . "</option>";
                        }
                    ?>
                </select></td>
                </tr>
                <tr>
                    <td style="float:right;">Price : </td>
                    <td><input type="text" name="Price" required class="textboxstyle"/></td>
                </tr>
                <tr>
                    <td style="float:right;">EnginePower : </td>
                    <td><input type="text" name="EnginePower" required class="textboxstyle"/></td>
                </tr>
                <tr>
                    <td style="float:right;">Photo : </td>
                    <td><input type="file" name="Photo" required class="textboxstyle"/></td>
                </tr>
                <tr>
                    <td style="float:right;">Status : </td>
                    <td><select name="CarStatus" style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                    	<option>Used</option>
                        <option>Brand</option>
                    </select></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Add" class="btnstyle"/>
                    <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle" ><br><br>
                    </td>
                </tr>
            </table>
        </form>
	</div>

         
         
         
         
         
         
         
         </div><!---------Form End----------->

	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>