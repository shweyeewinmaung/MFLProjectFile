<?php
session_start();
require_once("library/db.php");
require_once("dal/dal_car.php");
require_once("dal/dal_brand.php");
require_once("dal/dal_township.php");
require_once("library/function.php");
require_once("library/globalfunction.php");


if(isset($_POST['btnUpdate']) && isset($_POST['CarID']))
{
	$CarID=Clean($_POST['CarID']);
	$CarNo=Clean($_POST['CarNo']);
	$BrandName=Clean($_POST['BrandName']);
	
	$retB=GetBrandDataByBrandName($BrandName);
	$rowB=mysql_fetch_array($retB);
	
	$Brand=$rowB[0];
	
	$CarName=Clean($_POST['CarName']);
	$Model=Clean($_POST['Model']);
	$Kilo=Clean($_POST['Kilo']);
	$Gear=Clean($_POST['Gear']);
	$Fuel=Clean($_POST['Fuel']);
	$CarType=Clean($_POST['CarType']);
	$Description=Clean($_POST['Description']);
	$ContactPerson=Clean($_POST['ContactPerson']);
	$ContactNumber=Clean($_POST['ContactNumber']);
	$TownshipName=Clean($_POST['TownshipName']);
	
	$retT=GetTownshipData_byTownshipName($TownshipName);
	$rowT=mysql_fetch_array($retT);
	
	$TownshipID=$rowT[0];
	
	$Price=Clean($_POST['Price']);
	$EnginePower=Clean($_POST['EnginePower']);
	
	UpdateCarUser($CarID, $CarNo, $Brand, $CarName, $Model, $Kilo, $Gear, $Fuel, $CarType, $Description, $ContactPerson, $ContactNumber, $TownshipID, $Price, $EnginePower);
	$msg= "Update Successsfully";
}



if (isset($_GET['CarID']) && $_GET['CarID']!="")
{	
	$CarID=Clean($_GET['CarID']);
	$ret=GetCarDataByCarID($CarID);
	$num=mysql_num_rows($ret);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>

</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
        <div style="width:600px; margin:10px auto; border-radius:10px; font-size:16px;">
		<?php
			if($num>0)
			{
				$row=mysql_fetch_array($ret);
				
				if($row['UserID']==$_SESSION['SESS']['User']['UserID'])
				{
					?>
                        <form method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="CarID" value="<?php echo $row['CarID']; ?>" readonly />
                            <table style="margin:0 auto; color:#000;">
                                
                               <tr>
                                    <td colspan="2"><h1 style="color:#2c4c09; margin-left:100px; padding-bottom:10px;">Edit Car</h1></td>
                                    
                                </tr>
                                 <tr>
                                    <td colspan="2"><font style="color:red;"><?php echo $msg;?></font> </td>
                                   
                                </tr>
                                <tr>
                                    <td style="float:right;">Car No : </td>
                                    <td><input type="text" name="CarNo" value="<?php echo $row['CarNo']; ?>" required class="textboxstyle"></td>
                                </tr>
                                <tr>
                                    <td style="float:right;">Car Brand : </td>
                                    <td><select name="BrandName" required style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                                        
                                        <?php
                                            $ret1=GetAllBrandData();
                                            
                                            while($row1=mysql_fetch_array($ret1))
                                            {
                                                echo "<option value='" . $row1['BrandName'] . "'>" . $row1['BrandName'] . "</option>";
                                            }
                                        ?>
                                    </select></td>
                                </tr>
                                <tr>
                                    <td style="float:right;">Car Name  : </td>
                                    <td><input type="text" name="CarName" value="<?php echo $row['CarName']; ?>" required class="textboxstyle"></td>
                                </tr>
                                <tr>
                                    <td style="float:right;">Model  : </td>
                                    <td><input type="text" name="Model" value="<?php echo $row['Model']; ?>" required class="textboxstyle"></td>
                                </tr>
                                <tr>
                                    <td style="float:right;">Kilo  : </td>
                                    <td><input type="text" name="Kilo" value="<?php echo $row['Kilo']; ?>" required class="textboxstyle"/></td>
                                </tr>
                                <tr>
                                    <td style="float:right;">Gear  : </td>
                                    <td><select name="Gear" required style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;" >
                                        <option><?php echo $row['Gear']; ?></option>
                                        <option value="Auto">Auto</option>
                                        <option value="Manual">Manual</option>
                                    </select></td>
                                </tr>
                                <tr>
                                    <td style="float:right;">Fuel  : </td>
                                    <td><select name="Fuel" required style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                                        <option><?php echo $row['Fuel']; ?></option>
                                        <option value="Petrol">Petrol</option>
                                        <option value="Disel">Disel</option>
                                        <option value="CNG">CNG</option>
                                    </select></td>
                                </tr>
                                <tr>
                                    <td style="float:right;">CarType  : </td>
                                    <td><select name="CarType" required style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                                     	<option><?php echo $row['CarType']; ?></option>
                                        <option>Sedan</option>
                                        <option>Hatchback</option>
                                        <option>Stationwagon</option>
                                        <option>Sports</option>
                                        <option>SUV</option>
                                        <option>Truck</option>
                                        <option>Bus</option>
                                        <option>Others</option>
                                        <option>MPV(Minivan)</option>
                                    </select></td>
                                </tr>
                                <tr>
                                    <td valign="top" style="float:right;">Description  : </td>
                                    <td><textarea name="Description" required style="margin-left:7px;border: 2px solid#605858;width:200px;" rows="3" cols="2"><?php echo $row['Description']; ?></textarea></td>
                                </tr>
                                <tr>
                                    <td style="float:right;">ContactPerson  : </td>
                                    <td><input type="text" name="ContactPerson" value="<?php echo $row['ContactPerson']; ?>" required class="textboxstyle"/></td>
                                </tr>
                                <tr>
                                    <td style="float:right;">ContactNumber  : </td>
                                    <td><input type="text" name="ContactNumber" value="<?php echo $row['ContactNumber']; ?>" required class="textboxstyle"/></td>
                                </tr>
                                <tr>
                                    <td style="float:right;">Township  : </td>
                                    <td><select name="TownshipName" required style="width:205px; height:30px; margin-left:7px; border: 2px solid#605858;">
                                      
                                    <?php
                                        $ret2=getAllTownshipData();
                                       
										
                                        while($row2=mysql_fetch_array($ret2))
                                        {
                                            echo "<option value='" . $row2['TownshipName'] . "'>" . $row2['TownshipName'] . "</option>";
                                        }
                                    ?>
                                   
                                       
                                    
                                </select></td>
                                </tr>
                                <tr>
                                    <td style="float:right;">Price  : </td>
                                    <td><input type="text" name="Price" value="<?php echo $row['Price']; ?>" required class="textboxstyle"/></td>
                                </tr>
                                <tr>
                                    <td style="float:right;">EnginePower  : </td>
                                    <td><input type="text" name="EnginePower" value="<?php echo $row['EnginePower']; ?>" required class="textboxstyle"/></td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td>
                                    <input type="submit" value="Update" class="btnstyle" name="btnUpdate"/>
                    				<input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle" ><br><br>
                                    
                                </tr>
                            </table>
                        </form>
                    <?php
				}
				
				else
				{
					?>
                    	<center><h2 style="color:#2c4c09;">You don't have permission to edit this car!</h2></center>
                    <?php
				}
				
				
			}
			else
			{
				?>
                	<center><h2 style="color:#2c4c09;">No available!</h2></center>
                <?php
			}
		?>
	</div>
        
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>