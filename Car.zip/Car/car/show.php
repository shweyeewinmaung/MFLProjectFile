<form method="POST" enctype="multipart/form-data">
			<?php
					$query=mysql_query("SELECT * FROM tbl_car")or die("SELECT ERROR");
				
					while($row=mysql_fetch_assoc($query))
					{
			?>
					<table>
						<tr>
							<td colspan="2"><?php echo $row['CarName']; ?></td>	
						</tr>
						<tr>
							<td style="padding-right:90px;">Car Brand</td>	
							<td><?php echo $row['CarName']; ?></td>	
						</tr>
						<tr>
							<td>Wheel Drive</td>	
							<td><?php echo $row['WheelDrive']; ?></td>	
						</tr>
						<tr>
							<td>Engine Power</td>	
							<td><?php echo $row['EnginePower']; ?></td>	
						</tr>
						<tr>
							<td>Fuel</td>	
							<td><?php echo $row['Fuel']; ?></td>	
						</tr>
						<tr>
							<td>Model</td>	
							<td><?php echo $row['Model']; ?></td>	
						</tr>
						<tr>
							<td>Price</td>	
							<td><?php echo $row['Price']; ?></td>	
						</tr>
					</table>
					<div id="images-box" style="margin-left:350px;">
									<div class="holder">
										<div id="image-1" class="image-lightbox">
											<span class="close"><a href="#">X</a></span>
											<img src="carphoto/<?php echo $row['Image']; ?>" alt="earth!">
											<a class="expand" href="#image-1"></a>
										</div>
									</div>
									<div class="holder">
										<div id="image-2" class="image-lightbox">
											<span class="close"><a href="#">X</a></span>
											<img src="carphoto/<?php echo $row['Image']; ?>" alt="earth!">
											<a class="expand" href="#image-2"></a>
										</div>
									</div>
									<div class="holder">
										<div id="image-3" class="image-lightbox">
											<span class="close"><a href="#">X</a></span>
											<img src="carphoto/<?php echo $row['Image']; ?>" alt="earth!">
											<a class="expand" href="#image-3"></a>
										</div>
									</div>
					</div>
			<?php
					}
			?>
		</form>