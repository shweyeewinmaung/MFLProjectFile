<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_car.php");
require_once("dal/dal_brand.php");
require_once("dal/dal_township.php");
require_once("library/function.php");
require_once("library/globalfunction.php");

if(isset($_GET['CarID']) && $_GET['CarID']!="")
{	
	$CarID=$_GET['CarID'];
	IncreaseView($CarID);
	$ret=GetCarDataByCarID($CarID);
	$num=mysql_num_rows($ret);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>

</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         <div style="width:600px; margin:10px auto;border-radius:10px; font-size:16px;">
    	<?php
			if($num>0)
			{
				$row=mysql_fetch_array($ret);
				?>
                	<form method="POST" enctype="multipart/form-data">
                        <table style="margin:0 auto; color:#000;">
                         <tr>
                                <td colspan="2"> <h1 style="color:#2c4c09; margin-left:100px; height:50px;">Add Car</h1></td>
                                
                            </tr>
                           
                            <tr style="line-height:25px;">
                                <td style="float:right; ">Car No : </td>
                                <td><?php echo $row['CarNo']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Car Brand : </td>
                                <td><?php echo $row['Brand']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Car Name : </td>
                                <td><?php echo $row['CarName']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Model : </td>
                                <td><?php echo $row['Model']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Kilo : </td>
                                <td><?php echo $row['Kilo']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Gear : </td>
                                <td><?php echo $row['Gear']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Fuel : </td>
                                <td><?php echo $row['Fuel']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">CarType : </td>
                                <td><?php echo $row['CarType']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td valign="top" style="float:right;">Description : </td>
                                <td><?php echo $row['Description']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">EnginePower : </td>
                                <td><?php echo $row['EnginePower']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">ContactPerson : </td>
                                <td><?php echo $row['ContactPerson']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">ContactNumber : </td>
                                <td><?php echo $row['ContactNumber']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Township : </td>
                                <td><?php echo $row['CarType']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Price : </td>
                                <td><?php echo $row['Price']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Total View : </td>
                                <td><?php echo $row['CarView']; ?></td>
                            </tr>
                            <tr >
                                <td valign="top" style="float:right;">Photo : </td>
                                <td><img src="carphoto/<?php echo $row['Photo']; ?>" width="111px;" height="75px;" style="border:2px solid#333;" /></td>
                            </tr>
                        </table>
                    </form>
                <?php
			}
			else
			{
				?>
                	<center><h1>No result found!</h1></center>
                <?php
			}
		?>
	</div>
         
         
         
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>