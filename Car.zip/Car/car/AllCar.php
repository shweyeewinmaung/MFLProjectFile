<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_car.php");
require_once("dal/dal_brand.php");
require_once("dal/dal_township.php");
require_once("library/function.php");
require_once("library/pager_car.php");
require_once("library/globalfunction.php");

$pageSize=10;



if(isset($_GET['page']))
{
	$currentPageIndex=Clean($_GET['page']);
}
else
{
	$currentPageIndex=1;
}
$objPager=new pager($pageSize,$currentPageIndex);

$sql=$objPager->SearchData_GetAllCar();
$ret=$objPager->Search_Data($sql);
$num=mysql_num_rows($ret);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>

</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         
         <div style="width:650px; margin:10px auto;  border-radius:10px;">
		<form method="POST" enctype="multipart/form-data">
            <table style="margin:0 auto; font-size:16px; " >
                
                <tr>
                    <td colspan="3"><h1 style="color:#2c4c09; margin-left:150px;">View Car</h1></td>
                    
                </tr>
                <?php
					if($num>0)
					{
						?>
                        	<tr style="background:#999; height:40px;">
                                <td colspan="4" align="center" style="font-size:16px; color:#2c4c09; ">Car List</td>
                                <td style="font-size:16px; color:#2c4c09; text-align:center;">Edit</td>
                            </tr>
                        <?php
						for($i=0;$i<$num;$i++)
						{
							$row=mysql_fetch_array($ret);
							$retp=GetCarPhotoByCarID($row['CarID']);
							$rowp=mysql_fetch_array($retp);
						?>
                        	
                            <tr>
                                <td rowspan="3" width="25%"><img src="carphoto/Mini/<?php echo $rowp['PhotoMini']; ?>" width="100" height="100"  style="border:2px solid#300;"/></td>
                                <td width="10%"><?php echo GetBrandNameByBrandID($row['2']); ?></td>
                                <td width="25%"><?php echo $row['CarName']; ?></td>
                                <td width="20%"><?php echo $row['Model']; ?></td>
                                <td rowspan="3" width="20%"><a href="Admin/EditCar.php?CarID=<?php echo $row['CarID']; ?>"><img src="images/wrench-screwdriver.png" width="20" height="20"  style="margin-left:50px;"/></a></td>
                            </tr>
                            <tr>
                                <td colspan="4"><br /><br /></td>
                            </tr>
                            <tr>
                                <td><?php echo $row['EnginePower']; ?></td>
                                <td><?php echo $row['Price']; ?></td>
                                <td><?php echo $row['Brand']; ?></td>
                            </tr>   
                            <tr><td colspan="5" style="height:30px;"><font style="color:#660;">------------------------------------------------------------------------------------------------------------------------</font></td></tr>
                        <?php
						}
						
					}
					else
					{
						?>
                        	<center>Not available!</center>
                        <?php
					}
				?>
                
            </table>
            <br />
            <?php
                	$objPager->Generate_Pager($str);
                ?>
        </form>
	</div>
         
         
         
         
         
         
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>