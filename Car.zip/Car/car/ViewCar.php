<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_advertise.php");
require_once("dal/dal_car.php");
require_once("library/globalfunction.php");

include("Permission.php");

$UserID=$_SESSION['SESS']['User']['UserID'];

$ret=GetCarDataByUserID($UserID);
$num=mysql_num_rows($ret);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>

</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
        <div style="width:650px; margin:10px auto; border-radius:10px; font-size:16px;">
    	<?php
			if($num<=0)
			{
				echo "You don't have car!";
			}
			elseif($num>0)
			{
				?>
                    <table style="width:645px; margin:0 auto;">
                        <tr>
                            <td colspan="6" ><h2 style="color:#2c4c09; margin-left:250px; line-height:40px;">Car List</h2></td>
                        </tr>
                        <?php
							if(isset($_SESSION['DeleteCar']) && $_SESSION['DeleteCar']=="Deleted")
							{
								?>
                                	<tr>
                                    	<td colspan="6"><h2 style="color:red;"><b>Successfully Deleted</b></h2></td>
                                    </tr>
                                <?php
								unset($_SESSION['DeleteCar']);
							}
						?>
                        <tr style="background-color:#999; line-height:30px; text-align:center; color:#2c4c09;">
                            <td>Photo</td>
                            <td>CarID</td>
                            <td>Brand</td>
                            <td>Car Name</td>
                            <td>Model</td>
                            <td>Price</td>
                            <td>Primium</td>
                            <td>Advertise Date</td>
                            <td colspan="2">Update/<br />Delete</td>
                            
                        </tr>
                        <?php
							$i=0;
							while($row=mysql_fetch_array($ret))
							{
								if($i>0)
								{
									echo "<tr><td colspan='8'><br /></td></tr>";
								}
								$i=$i+1;
								?>
                                	<tr style="text-align: center;">
                                        <td><img src="carphoto/<?php echo $row['Photo']; ?>" width="100px;" height="100px;" style="border:2px solid#666;" /></td>
                                        <td><?php echo $row['CarID']; ?></td>
                                        <td><?php echo $row['Brand']; ?></td>
                                        <td><?php echo $row['Carname']; ?></td>
                                        <td><?php echo $row['Model']; ?></td>
                                        <td><?php echo $row['Price']; ?></td>
                                        <td><?php 
											$reta=GetA_CarDataByCarID($row['CarID']);
											$numa=mysql_num_rows($reta);
											if($numa>0)
											{
												echo "<label style='color:#2c4c09;'><b>Yes</b></label>";
											}
											else
											{
												echo "No";
											}
										 ?></td>
                                        <td><?php echo $row['PublishDate']; ?></td>
                                        <td><a href="EditCar.php?CarID=<?php echo $row['CarID']; ?>"><img src="images/wrench-screwdriver.png" alt="" width="20" height="20" /></a></td>
                                        <td><a href="DeleteCar.php?CarID=<?php echo $row['CarID']; ?>"><img src="images/cross-script.png" alt="" width="20" height="20" /></a></td>
                                    </tr>
                                <?php
							}
						?>
                    </table>
                <?php
			}
		?>
        
	</div>
        
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>