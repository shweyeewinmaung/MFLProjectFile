<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_news.php");
require_once("library/globalfunction.php");

include("Permission.php");
if(isset($_POST['btnDelete']) && isset($_POST['NewsID']))
{
	$NewsID=Clean($_POST['NewsID']);
	$Title=Clean($_POST['Title']);
	$Description=Clean($_POST['Description']);
	$NewsDate=GetCurrentDate();
	$NewsTime=GetCurrentTime();
	$Status="Active";
	$UserID=$_SESSION['SESS']['User']['UserID'];
	DeleteNews( $NewsID, $Title, $Description, $NewsDate, $NewsTime, $Status, $UserID);
	print "<script language=\"JavaScript\">window.location.href=\"News.php\";</script>";
}



if (isset($_GET['NewsID']) && $_GET['NewsID']!="")
{	
	$NewsID=Clean($_GET['NewsID']);
	$ret=GetNewsDataByNewsID($NewsID);
	$num=mysql_num_rows($ret);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>
</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
            <?php
			if($num>0)
			{
				$row=mysql_fetch_array($ret);
				
				if($row['UserID']==$_SESSION['SESS']['User']['UserID'])
				{
					?>
         <form method="POST">
	<table style="margin:0 auto;">
      <td colspan="2"><h1 style="color:#2c4c09; margin-left:80px;">Delete News</h1></td>
			
         
            <tr style="display:none;">
				<td style="float:right;">NewsID : </td>
				<td><input type="text" name="NewsID" required class="textboxstyle" value="<?php echo $row['NewsID']; ?>"></td>
			</tr>
			<tr>
				<td style="float:right;">Title : </td>
				<td><input type="text" name="Title" required class="textboxstyle" value="<?php echo $row['Title']; ?>" style="width:400px;"></td>
			</tr>
            <tr>
                <td valign="top" style="float:right;">Description : </td>
                <td><textarea name="Description" required  style="margin-left:7px;border: 2px solid#605858;width:400px;" rows="5" cols="2"><?php echo $row['Description']; ?></textarea></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="Delete" class="btnstyle" name="btnDelete"/>
                    <input name="Reset" type="reset"  value="Cancel" class="btnstyle" ><br><br></td>
            </tr>
             
        </table>
	</form>
    <?php
				}
				
				else
				{
					?>
                    	<center><h2 style="color:#2c4c09;">You don't have permission to delete this news!</h2></center>
                    <?php
				}
				
				
			} 
			else
			{
				?>
                	<center><h2 style="color:#2c4c09;">No available!</h2></center>
                <?php
			}
		?>
         </div><!------Form End--------->

	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>
	

