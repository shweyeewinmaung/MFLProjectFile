<?php
$a1="4";
$a2=1;
$a3=2;
$a4="";

$sa1="";
$sa2="";
$sa3="";
$sa4="";

if($a1!="")
{
	$sa1="a1='$a1'";
}

if($a2!="")
{
	$sa2="a2='$a2'";
}

if($a3!="")
{
	$sa3="a3='$a3'";
}

if($a4!="")
{
	$sa4="a4='$a4'";
}



$sql="select * from tbl_car where $sa1";
if($sa2!="")
{
	if($a1!="")
		$sql .=" AND $sa2";
	else
		$sql .="$sa2";
}

if($sa3!="")
{
	if($a1!="" || $a2!="")
		$sql .=" AND $sa3";
	else
		$sql .=" $sa3";
}

if($sa4!="")
{
	if($a1!="" || $a2!="" || $a3!="")
		$sql .=" AND $sa4";
	else
		$sql .=" $sa4";
}

$sql .=" ORDER BY a1 ASC";



echo $sql;




?> 