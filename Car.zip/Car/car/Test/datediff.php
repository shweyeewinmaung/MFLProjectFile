<?php
$start_date = new DateTime('2012-12-04 23:58:40');
$end_date = new DateTime('2012-12-08 00:11:36');

$time_one = new DateTime('2010-07-28 12:43:54');
$time_two = new DateTime('2010-07-30 01:23:45');

$difference = $time_one->diff($time_two);

if ($difference->format('%Y')>0 && $difference->format('%m')>0)
{
	echo $difference->format('%Y');
}
else
{
	
}

echo $difference->format('%d day %h hours %i minutes %s seconds');

//echo date_diff($end_date, $start_date);
?>