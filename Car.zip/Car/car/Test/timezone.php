<?php
date_default_timezone_set("Asia/Rangoon");
echo date_default_timezone_get();

echo "<br><br>";

echo date_default_timezone_get();
$currenttime = date('h:i:s');
//list($hrs,$mins,$secs,$msecs) = split(':',$currenttime);
//echo " => $hrs:$mins:$secs\n<br>";
echo $currenttime . "<br>";
echo date("d-M-Y");
?> 