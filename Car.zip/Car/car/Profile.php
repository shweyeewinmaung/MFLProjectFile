<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_advertise.php");
require_once("dal/dal_car.php");
require_once("dal/dal_brand.php");
require_once("dal/dal_city.php");
require_once("dal/dal_township.php");
require_once("dal/dal_user.php");
require_once("library/function.php");
require_once("library/globalfunction.php");

if((isset($_SESSION['SESS']['User']['UserID']) && $_SESSION['SESS']['User']['UserID']!="") || (isset($_GET['UserID']) && $_GET['UserID']!=""))
{	
	if(isset($_SESSION['SESS']['User']['UserID']))
	{
		$UserID=$_SESSION['SESS']['User']['UserID'];
	}
	else
	{
		$UserID=Clean($_GET['UserID']);
	}
	
	$ret=GetUserDataByUserID($UserID);
	$num=mysql_num_rows($ret);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>
<style>
a{ text-decoration:none;}
.cc{ color:#2c4c09; text-decoration:underline; font-size:18px;}
.cc:hover{ color:#000; text-decoration:underline;}
</style>
</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
        
        <div style="width:600px; height:auto; overflow:hidden; margin:10px auto; border-radius:10px;">
    	<div style="width:600px; height:auto; overflow:hidden; float:left; font-size:16px;">
           
                <table style="width:600px;">
                <?php
                    if($num>0)
                    {
                        $row=mysql_fetch_array($ret);
                        ?>
                            <tr><td colspan="2" style="text-align:center; "><h2 style="color:#2c4c09;">User Info</h2></td></tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Full Name : </td>
                               
                                <td><?php echo $row['FullName']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">DOB : </td>
                               
                                <td><?php echo $row['DOB']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Gender : </td>
                                
                                <td><?php echo $row['Gender']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Phone : </td>
                               
                                <td><?php echo $row['Phone']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">Email : </td>
                               
                                <td><?php echo $row['Email']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">User Role : </td>
                               
                                <td><?php echo $row['Role']; ?></td>
                            </tr>
                            <tr style="line-height:25px;">
                                <td style="float:right;">User Status : </td>
                               
                                <td><?php echo $row['Status']; ?></td>
                            </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                            <center><h3>Sorry User Information is not available!</h3></center>
                        <?php
                    }
                ?>
                </table>
            
            
            
            
                <?php
                    if($num>0)
                    {
                        $retc=GetCarDataByUserID($UserID);
                        $numc=mysql_num_rows($retc);
                        $reta=GetA_CarDataByUserID($UserID);
                        $numa=mysql_num_rows($reta);
                        
                        ?>
                            <table style="width:600px;">
                                <tr style="line-height:30px; background-color:#2c4c09; color:#fff;">
                                    <td style="float:right;">Total Cars : </td>
                                    
                                    <td style="text-align:center;" ><?php echo $numc; ?></td>
                                </tr>
                                
                                <tr style="line-height:30px;background-color:#2c4c09; color:#fff;">
                                    <td style="float:right;">Total Advertised Cars : </td>
                                    
                                    <td style="text-align:center;" ><?php echo $numa; ?></td>
                                </tr>
                            </table>
                        <?php
                    }
                ?>
            
        </div>
        
        
         <table style="width:600px;">
         <tr style="line-height:30px; text-align:center;">
         <td>
                <a href="ViewCar.php"><font class="cc">View Your Cars</font></a><br /></td></tr>
                 <tr style="line-height:30px; text-align:center;">
             <td >   <a href="AdvertiseCars.php" ><font class="cc">View Advertised Cars</font></a></td></tr></table>
          
        <?php
			if($num>0)
			{
				?>
                	<div style="width:48%; margin-left:2%; float:left">
        				<table>
                        	<tr>
                            	<td></td>
                            </tr>
                        </table>
			        </div>
                <?php
			}
		?>
        
	</div>
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>