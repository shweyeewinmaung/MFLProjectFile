<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_news.php");
require_once("library/globalfunction.php");
include("Permission.php");
if (isset($_POST['Title']) && isset($_POST['Description']))
{	
	$Title=Clean($_POST['Title']);
	$Description=Clean($_POST['Description']);
	$NewsDate=GetCurrentDate();
	$NewsTime=GetCurrentTime();
	$Status="Active";
	$UserID=$_SESSION['SESS']['User']['UserID'];
	
	InsertNews($Title, $Description, $NewsDate, $NewsTime, $Status, $UserID);
	$msg="Successfully News Save";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>
</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         <form method="POST">
	<table style="margin:0 auto;">
      <td colspan="2"><h1 style="color:#2c4c09; margin-left:80px;">Add News</h1></td>
			<tr>
            	<td colspan="2"><font style="font-size:14px; color:red;"><?php echo $msg ?></font></td>
            </tr>
			<tr>
				<td style="float:right;">Title : </td>
				<td><input type="text" name="Title" required class="textboxstyle" style="width:400px; height:30px;"></td>
			</tr>
            <tr>
                <td valign="top" style="float:right;">Description : </td>
                <td><textarea name="Description" required  style="margin-left:7px;border: 2px solid#605858;width:400px;" rows="5"  ></textarea></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="Add" class="btnstyle"/>
                    <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle" ><br><br></td>
            </tr>
        </table>
	</form>
         </div><!------Form End--------->

	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>
	

