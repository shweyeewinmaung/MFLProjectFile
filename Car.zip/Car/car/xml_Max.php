<?php
require_once("library/db.php");
require_once("library/globalfunction.php");
require_once("dal/dal_car.php");

header('Content-Type: text/xml; charset=utf-8');

$ret=Premium_Max();
$noOfRows = mysql_num_rows($ret);

if ($noOfRows == 0) {
	die ("<p>No such entry</p>");
}

else {

	$doc = new DOMDocument(); 
	$doc->formatOutput = true; 

	$root = $doc->createElement('All_Max');
	$doc->appendChild($root);

	$node = $doc->createElement("Max");
	$Number = $doc->createElement("Number");
	
	$Number->appendChild($doc->createTextNode(mysql_num_rows($ret)));
	  
	$node->appendChild($Number);
	$root->appendChild($node);

	echo $doc->saveXML();
}
?>
