<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_advertise.php");
require_once("dal/dal_car.php");
require_once("dal/dal_brand.php");
require_once("dal/dal_city.php");
require_once("dal/dal_township.php");
require_once("dal/dal_user.php");
require_once("library/function.php");
require_once("library/globalfunction.php");

$UserID=$_SESSION['SESS']['User']['UserID'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>
<style>a {
	color:#1a250e;
	
}
a:hover {
	color:#000;
	text-decoration:underline;
}
.imgstyle{position:relative;
bottom:30px;
left:0px;
visibility:hidden;}
.imgstyle:hover .text{visibility:visible;}
</style>
<script language="JavaScript" type="text/javascript">
<!--
function CngTxt(id,txt){
 var obj=document.getElementById(id);
 if (txt){ obj.innerHTML=txt; }
 else {  obj.innerHTML='some standard text'; }
}

//-->
</script>
</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         <div style="width:630; height:auto; overflow:hidden; margin:2% auto; padding:20px;  border-radius:10px; font-size:16px;">
         <div style="width:47%; height:auto; margin-left:1%; float:left; background-color:#2c4c09; line-height:50px; border-radius:5px;  " align="center"><a href="MyCar.php?C=N" >Normal</a></div>
         <div style="width:47%; height:auto; margin-left:1%; float:left;background-color:#2c4c09;  line-height:50px;border-radius:5px;" align="center"><a href="MyCar.php?C=A">Premium</a></div>
        </div>
        
        <?php
			if(Clean($_GET['C'])=="A")
			{
				$reta=Premium_All();
				$numa=mysql_num_rows($reta);
				if($numa>0)
				{
					?>
                    <div style="width:630px; height:auto; overflow:hidden; margin:10px auto; padding:20px;border-radius:10px; font-size:16px;">
						<table style="width:630px;margin:0 auto;">
                            <tr>
                                <td colspan="10" align="center" style="line-height:30px;"><h2 style="color:#2c4c09; padding-bottom:5px;">Premium Car List</h2></td>
                            </tr>
                            <tr style="background-color:#999; line-height:30px; text-align:center; color:#2c4c09;">
                                <td>Photo</td>
                                <td>CarID</td>
                                <td>Brand</td>
                                <td>Car Name</td>
                                <td>Model</td>
                                <td>Price</td>
                                <td>Advertise Date</td>
                                <td>Primium Date</td>
                                <td></td>
                            </tr>
                            <?php
                                $i=0;
                                while($rowa=mysql_fetch_array($reta))
                                {
                                    if($i>0)
                                    {
                                        echo "<tr><td colspan='10' style='border-bottom-style:solid; border-bottom-width:2px; border-bottom-color:#2c4c09;'><br /></td></tr>";
                                    }
                                    $i=$i+1;
									
									$retp=GetCarPhotoByCarID($rowa['CarID']);
									$rowp=mysql_fetch_array($retp);
                                    ?>
                                        <tr>
                                            <td><img src="carphoto/Mini/<?php echo $rowp['PhotoMini']; ?>" width="100px;" height="100px;" style="border:2px solid#666;" /></td>
                                            <td><?php echo $rowa['CarID']; ?></td>
                                            <td><?php echo GetBrandNameByBrandID($rowa['2']); ?></td>
                                            <td><?php echo $rowa['CarName']; ?></td>
                                            <td><?php echo $rowa['Model']; ?></td>
                                            <td><?php echo $rowa['Price']; ?></td>
                                            <td><?php echo $rowa['PublishDate']; ?></td>
                                            <td><?php echo $rowa['StartDate']; ?></td>
                                            <td>
                                            	<center><a href="AddPhoto.php?CarID=<?php echo $rowa['CarID']; ?>"><img src="images/gal5.jpg" alt="" width="20" height="20" /></a><br /><br />
                                                <a href="EditCar.php?CarID=<?php echo $rowa['CarID']; ?>"><img src="images/wrench-screwdriver.png" alt="" width="20" height="20"  /></a><br /><br />
                                                <a href="DeleteCar.php?CarID=<?php echo $rowa['CarID']; ?>"><img src="images/cross-script.png" alt="" width="20" height="20"  /></a></center>
                                            </td>
                                        </tr>
                                    <?php
                                }
                            ?>
                        </table>
					</div>
                    <?php
				}
			}
			
			else
			{
				$retc=GetCarDataByUserID($UserID);
				$numc=mysql_num_rows($retc);
				if($numc>0)
				{
					?>
                    <div style="width:620px; height:auto; overflow:hidden; margin:0 auto; padding:10px; font-size:16px; ">
						<table style="width:620px; margin:0 auto;">
                            <tr>
                                <td colspan="10" align="center" style="line-height:30px;  "><h2  style="color:#2c4c09; padding-bottom:5px;	">Normal Car List</h2></td>
                            </tr>
                            <tr style="background-color:#999; line-height:30px; text-align:center; color:#2c4c09;">
                                <td>Photo</td>
                                <td>CarID</td>
                                <td>Brand</td>
                                <td>Car Name</td>
                                <td>Model</td>
                                <td>Price</td>
                                <td>Advertise Date</td>
                                <td colspan="2"></td>
                                
                            </tr>
                            <?php
                                $i=0;
                                while($rowc=mysql_fetch_array($retc))
                                {
                                    if($i>0)
                                    {
                                        echo "<tr><td colspan='10' style='border-bottom-style:solid; border-bottom-width:2px; border-bottom-color:#2c4c09; '><br /></td></tr>";
                                    }
                                    $i=$i+1;
									$retp=GetCarPhotoByCarID($rowc['CarID']);
									$rowp=mysql_fetch_array($retp);
                                    ?>
                                        <tr>
                                            <td><img src="carphoto/Mini/<?php echo $rowp['PhotoMini']; ?>" width="100px;" height="100px;"  style="border:2px solid#666;"/></td>
                                            <td><?php echo $rowc['CarID']; ?></td>
                                            <td><?php echo GetBrandNameByBrandID($rowc['2']); ?></td>
                                            <td><?php echo $rowc['CarName']; ?></td>
                                            <td><?php echo $rowc['Model']; ?></td>
                                            <td><?php echo $rowc['Price']; ?></td>
                                            <td><?php echo $rowc['PublishDate']; ?></td>
                                            <td>
                                            	<center><a href="AddPhoto.php?CarID=<?php echo $rowc['CarID']; ?>"><img src="images/gal5.jpg" alt="" width="20" height="20" /></a></a><br /><br />
                                                <a href="EditCar.php?CarID=<?php echo $rowc['CarID']; ?>"><img src="images/wrench-screwdriver.png" alt="" width="20" height="20" /></a><br /><br />
                                                <a href="DeleteCar.php?CarID=<?php echo $rowc['CarID']; ?>"><img src="images/cross-script.png" alt="" width="20" height="20" /></a></center>
                                            </td>
                                        </tr>
                                    <?php
                                }
                            ?>
                        </table>
					</div>
                    <?php
				}
			}
		?>
         
         
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>