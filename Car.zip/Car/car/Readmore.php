<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_news.php");
require_once("dal/dal_user.php");


if(isset($_GET['NewsID']) && $_GET['NewsID']!="")
{	
	$NewsID=$_GET['NewsID'];
	
	$ret=GetNewsDataByNewsID($NewsID);
	$num=mysql_num_rows($ret);
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<link rel="stylesheet" type="text/css" href="css/tab.css"/>
<script type="text/javascript" src="js/jquery.min.js"></script>
<head>

</head>
<body>
   <?php include("template/headernews.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar" style="padding-top:10px;">
   

        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px; ">
        
         <form>
        		<table style="font-size:14px;">
                  <?php
					if($num>0)
					{
						$row=mysql_fetch_array($ret);
					?>
                		<tr>
                        	<td colspan="2"><h2 style="color:#2c4c09; margin-left:200px;text-transform:uppercase;"><?php echo $row['Title']; ?></h2></td>
                            
                        </tr>
                        	                       
                		<tr>
                        	<td colspan="2"><img src="carphoto/2.jpg" width="200" height="150" style="border:2px solid#666; margin-left:200px;" /></td>
                        </tr>
                         <tr height="25">
                         	<td style="float:right; font-size:14px;">NewsDate : </td>
                        	<td><?php echo $row['NewsDate']; ?></td>
                        </tr>
                         <tr height="30" >
                        	 <td style="float:right; font-size:14px;">NewsTime : </td>
                        	<td><?php echo $row['NewsTime']; ?></td>
                        </tr>
                         <tr height="30">
                         	<td style="float:right; font-size:14px;">Status : </td>
                        	<td><?php echo $row['Status']; ?></td>
                        </tr>
                         <tr height="30">
                         	<td style="float:right; font-size:14px;">UserName : </td>
                        	<td><?php echo GetUserNameByUserID($row['6']); ?> </td>
                        </tr>
                        <tr>
                        	<td style="float:right; font-size:14px;">Description : </td>
                        	<td> <?php echo $row['Description']; ?> </td>
                        </tr>
                       
                <?php } ?>
                </table>
         
         
         </form>
         
         
         
         
         </div><!---------Form End----------->

	</div><!---mainbar End----->
      <?php include("template/sidebarnews.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>