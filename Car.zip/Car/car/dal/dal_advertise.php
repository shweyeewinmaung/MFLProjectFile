<?php
function GetA_AllCarData()
{
	$sql="SELECT * FROM tbl_car c ,tbl_advertise a WHERE c.CarID=a.CarID ";
	
	return mysql_query($sql);
}

function GetA_CarDataByAID($AID)
{
	$sql="SELECT * FROM tbl_advertise WHERE AID='$AID'";
	return mysql_query($sql);
}

function GetA_CarDataByCarID($CarID)
{
	$sql="SELECT * FROM tbl_advertise WHERE CarID='$CarID'";
	return mysql_query($sql);
}

function GetA_CarDataByAdminID($AdminID)
{
	$sql="SELECT * FROM tbl_advertise WHERE AdminID='$AdminID'";
	return mysql_query($sql);
}

function GetA_CarDataByStartDate($StartDate)
{
	$sql="SELECT * FROM tbl_advertise WHERE StartDate='$StartDate'";
	return mysql_query($sql);
}

function GetA_CarDataByEndDate($EndDate)
{
	$sql="SELECT * FROM tbl_advertise WHERE EndDate='$EndDate'";
	return mysql_query($sql);
}

function GetA_CarDataByAStatus($AStatus, $Status)
{
	$sql="SELECT * FROM tbl_advertise WHERE AStatus='$AStatus' AND Status='$Status'";
	return mysql_query($sql);
}

function GetA_CarDataByStatus($Status)
{
	$sql="SELECT * FROM tbl_advertise WHERE Status='$Status'";
	return mysql_query($sql);
}

function GetA_CarDataByUserID($UserID)
{
	$sql="SELECT * FROM tbl_advertise WHERE CarID='$CarID'";
	return mysql_query($sql);
}

////////////////////////// Advertise //////////////////////////

function GetA_Popular()
{
	$sql="SELECT * FROM tbl_advertise WHERE AStatus='Popular' AND Status='Active'";
	return mysql_query($sql);
}

function GetA_Favourite()
{
	$sql="SELECT * FROM tbl_advertise WHERE AStatus='Favourite' AND Status='Active'";
	return mysql_query($sql);
}

function GetA_Premium()
{
	$sql="SELECT * FROM tbl_advertise WHERE AStatus='Premium' AND Status='Active'";
	return mysql_query($sql);
}



function GetA_PopularCount()
{
	$sql="SELECT * FROM tbl_advertise WHERE AStatus='Popular' AND Status='Active'";
	$ret=mysql_query($sql);
	return mysql_num_rows($ret);
}

function GetA_FavouriteCount()
{
	$sql="SELECT * FROM tbl_advertise WHERE AStatus='Favourite' AND Status='Active'";
	$ret=mysql_query($sql);
	return mysql_num_rows($ret);
}

function GetA_PremiumCount()
{
	$sql="SELECT * FROM tbl_advertise WHERE AStatus='Premium' AND Status='Active'";
	$ret=mysql_query($sql);
	return mysql_num_rows($ret);
}
////////////////////////// Advertise //////////////////////////

function InsertAdvertise($CarID, $AdminID, $StartDate, $EndDate, $Price, $AStatus, $Status)
{
	$sql="INSERT INTO tbl_advertise(CarID, AdminID, StartDate, EndDate, Price, AStatus, Status) 
			VALUES('$CarID', '$AdminID', '$StartDate', '$EndDate', '$Price', '$AStatus', '$Status')";
	mysql_query($sql);
}

function UpdateAdvertise($AID, $AdminID, $StartDate, $EndDate, $Price, $AStatus, $Status)
{
	$sql="UPDATE tbl_advertise SET StartDate='$StartDate', 
									  EndDate='$EndDate', 
									  Price='$Price', 
									  AStatus='$AStatus', 
									  Status='$Status' 
									WHERE AID='$AID'";
	mysql_query($sql);
}

function UpdateA_AStatus($AStatus, $AID)
{
	$sql="UPDATE tbl_advertise SET AStatus='$AStatus' WHERE AID='$AID'";
	mysql_query($sql);
}

function UpdateA_Status($Status, $AID)
{
	$sql="UPDATE tbl_advertise SET Status='$Status' WHERE AID='$AID'";
	mysql_query($sql);
}

?>