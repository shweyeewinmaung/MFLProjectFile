<?php
function CheckMail($Email)
{
    $sql="SELECT * FROM tbl_user WHERE UserName='$Email'";
    $ret=mysql_query($sql);
    $num=mysql_num_rows($ret);
    
    if($num>0)
    {
        return true;
    }
    elseif($num==0 || $num<0)
    {
        return false;
    }
}

function CheckLogInData($UserName, $Password)
{
	$sql="SELECT * FROM tbl_user WHERE UserName='$UserName' AND Password='" . md5($Password) . "'";
	$ret=mysql_query($sql);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

function GetUserDataByUserID($UserID)
{
	$sql="SELECT * FROM tbl_user WHERE UserID='$UserID'";
	return mysql_query($sql);
}

function GetLogInData($UserName, $Password)
{
	$sql="SELECT * FROM tbl_user WHERE UserName='$UserName' AND Password='" . md5($Password) . "'";
	return mysql_query($sql);
}
function GetUserNameByUserID($UserID)
{
	$sql="SELECT * FROM tbl_user WHERE UserID='$UserID'";
	
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	return $row[6];
}

function InsertUser($UserID, $FullName, $DOB, $Gender, $Phone, $Email, $UserName, $Password, $Role, $Status)
{
	$sql="INSERT INTO tbl_user(UserID, FullName, DOB, Gender, Phone, Email, UserName, Password, Role, Status) 
	VALUES('$UserID', '$FullName', '$DOB', '$Gender', '$Phone', '$Email', '$UserName', '" . md5($Password) . "', '$Role', '$Status')";
	mysql_query($sql);
}

function UpdateUserData($UserID, $FullName, $DOB, $Gender, $Phone, $Email, $UserName, $Password, $Role, $Status)
{
	$sql="UPDATE tbl_user SET FullName='$FullName', 
							  DOB='$DOB', 
							  Gender='$Gender', 
							  Phone='$Phone', 
							  Email='$Email'
							WHERE UserID='$UserID'";
	mysql_query($sql);
}

function UpdateUserPassword($UserID, $Password)
{
	$sql="UPDATE tbl_user SET Password='" . md5($Password) . "' WHERE UserID='$UserID'";
	mysql_query($sql);
}

function UpdateUserRole($UserID, $Role)
{
	$sql="UPDATE tbl_user SET Role='$Role' WHERE UserID='$UserID'";
	mysql_query($sql);
}

function UpdateUserStatus($UserID, $Status)
{
	$sql="UPDATE tbl_user SET Status='$Status' WHERE UserID='$UserID'";
	mysql_query($sql);
}

function DeleteUser($UserID)
{
	$sql="DELETE FROM tbl_user WHERE UserID='$UserID'";
	mysql_query($sql);
}
?>