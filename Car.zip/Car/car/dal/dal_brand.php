<?php
function GetAllBrandData()
{
	$sql="SELECT * FROM tbl_brand";
	return mysql_query($sql);
}
function GetBrandNameByBrandID($BrandID)
{
	$sql="SELECT * FROM tbl_brand WHERE BrandID='$BrandID'";
	
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	return $row[1];
}

function GetBrandDataByBrandID($BrandID)
{
	$sql="SELECT * FROM tbl_brand WHERE BrandID='$BrandID'";
	return mysql_query($sql);
}

function GetBrandDataByBrandName($BrandName)
{
	$sql="SELECT * FROM tbl_brand WHERE BrandName='$BrandName'";
	return mysql_query($sql);
}

/*function GetBrandNameByBrandID($BrandID)
{
	$sql="SELECT * FROM tbl_brand WHERE BrandID='$BrandID'";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row['BrandName'];
}*/

function InsertBrand($BrandName, $UserID)
{
	$sql="INSERT INTO tbl_brand(BrandName, UserID) VALUES('$BrandName', '$UserID')";
	mysql_query($sql);
}

function DeleteBrand($BrandID)
{
	$sql="DELETE FROM tbl_brand WHERE BrandID='$BrandID'";
	mysql_query($sql);
}
?>