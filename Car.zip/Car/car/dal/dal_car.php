<?php
function CheckCarDataByCarIDAndUserID($CarID, $UserID)
{
	$sql="SELECT * FROM tbl_car WHERE CarID='$CarID' AND UserID='$UserID'";
	return mysql_query($sql);
}

function GetCarDataByCarID($CarID)
{
	$sql="SELECT * FROM tbl_car WHERE CarID='$CarID'";
	
	return mysql_query($sql);
}

function GetCarDataByCarNo($CarNo)
{
	$sql="SELECT * FROM tbl_car WHERE CarNo='$CarNo'";
	return mysql_query($sql);
}

function GetCarDataByCarName($CarName)
{
	$sql="SELECT * FROM tbl_car WHERE CarName LIKE '%$CarName%'";
	return mysql_query($sql);
}

function GetCarDataByContact($Contact)
{
	$sql="SELECT * FROM tbl_car WHERE ContactPerson='$Contact' OR ContactNumber LIKE '%$Contact%'";
	return mysql_query($sql);
}

function GetCarDataByCarStatus($CarStatus)
{
	$sql="SELECT * FROM tbl_car WHERE CarStatus='$CarStatus'";
	return mysql_query($sql);
}

function GetCarDataByUserID($UserID)
{
	$sql="SELECT * FROM tbl_car WHERE UserID='$UserID'";
	return mysql_query($sql);
}

function GetCarPhotoByCarID($CarID)
{
	$sql="SELECT * FROM tbl_carphoto WHERE CarID='$CarID' ORDER BY PhotoID LIMIT 0,1";
	return mysql_query($sql);
}

function GetCarPhotoAllByCarID($CarID)
{
	$sql="SELECT * FROM tbl_carphoto WHERE CarID='$CarID' ORDER BY PhotoID";
	return mysql_query($sql);
}

/////////////////////////////// For Primium ///////////////////////////////
function Premium_All()
{
	$sql="SELECT a.*, c.* FROM tbl_advertise a, tbl_car c WHERE a.CarID=c.CarID ORDER BY a.AID DESC";
	return mysql_query($sql);
}

function Premium_CheckAvailable($Number)
{
	$sql="SELECT a.*, c.* FROM tbl_advertise a, tbl_car c WHERE a.CarID=c.CarID ORDER BY a.AID DESC LIMIT $Number,1";
	$ret=mysql_query($sql);
	return mysql_num_rows($Number);
}

function Premium_Photo($Number)
{
	$sql="SELECT a.*, c.* FROM tbl_advertise a, tbl_car c WHERE a.CarID=c.CarID ORDER BY a.AID DESC LIMIT $Number,1";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row['Photo'];
}

function Premium_Brand($Number)
{
	$sql="SELECT a.*, c.* FROM tbl_advertise a, tbl_car c WHERE a.CarID=c.CarID ORDER BY a.AID DESC LIMIT $Number,1";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row['Brand'];
}

function Premium_CarName($Number)
{
	$sql="SELECT a.*, c.* FROM tbl_advertise a, tbl_car c WHERE a.CarID=c.CarID ORDER BY a.AID DESC LIMIT $Number,1";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row['CarName'];
}

function Premium_Model($Number)
{
	$sql="SELECT a.*, c.* FROM tbl_advertise a, tbl_car c WHERE a.CarID=c.CarID ORDER BY a.AID DESC LIMIT $Number,1";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row['Model'];
}

function Premium_Fuel($Number)
{
	$sql="SELECT a.*, c.* FROM tbl_advertise a, tbl_car c WHERE a.CarID=c.CarID ORDER BY a.AID DESC LIMIT $Number,1";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row['Fuel'];
}

function Premium_Price($Number)
{
	$sql="SELECT a.*, c.* FROM tbl_advertise a, tbl_car c WHERE a.CarID=c.CarID ORDER BY a.AID DESC LIMIT $Number,1";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row['Price'];
}

function Premium_Max()
{
	$sql="SELECT a.*, c.* FROM tbl_advertise a, tbl_car c WHERE a.CarID=c.CarID ORDER BY a.AID DESC";
	return mysql_query($sql);
}

function Premium_Number($Number)
{
	$sql="SELECT a.*, c.* FROM tbl_advertise a, tbl_car c WHERE a.CarID=c.CarID ORDER BY a.AID DESC LIMIT $Number,1";
	return mysql_query($sql);
}

/////////////////////////////// For Primium ///////////////////////////////

function InsertCar($CarID, $CarNo, $Brand, $CarName, $Model, $Kilo, $Gear, $Fuel, $CarType, $Description, $ContactPerson, $ContactNumber, $TownshipID, $Price, $EnginePower, $UserID, $View, $Like, $CarStatus, $Status, $PublishDate, $PublishTime)
{
	$sql="INSERT INTO tbl_car(CarID, CarNo, Brand, CarName, Model, Kilo, Gear, Fuel, CarType, Description, ContactPerson, ContactNumber, TownshipID, 
			Price, EnginePower, UserID, CarView, CarLike, CarStatus, Status, PublishDate, PublishTime) 
			
			VALUES('$CarID', '$CarNo', '$Brand', '$CarName', '$Model', '$Kilo', '$Gear', '$Fuel', '$CarType', '$Description', '$ContactPerson', 
			'$ContactNumber', '$TownshipID', '$Price', '$EnginePower', '$UserID', '$View', '$Like', '$CarStatus', '$Status', '$PublishDate', '$PublishTime')";
	mysql_query($sql);
}

function InsertCarPhoto($CarID, $Mini, $Large)
{
	$sql="INSERT INTO tbl_carphoto(CarID, PhotoMini, PhotoLarge) VALUES('$CarID', '$Mini', '$Large')";
	mysql_query($sql);
}

function UpdateCarUser($CarID, $CarNo, $Brand, $CarName, $Model, $Kilo, $Gear, $Fuel, $CarType, $Description, $ContactPerson, $ContactNumber, $TownshipID, $Price, $EnginePower)
{
	$sql="UPDATE tbl_car SET CarNo='$CarNo', 
							  Brand='$Brand', 
							  CarName='$CarName', 
							  Model='$Model', 
							  Kilo='$Kilo', 
							  Gear='$Gear', 
							  Fuel='$Fuel', 
							  CarType='$CarType', 
							  Description='$Description', 
							  ContactPerson='$ContactPerson', 
							  ContactNumber='$ContactNumber', 
							  TownshipID='$TownshipID', 
							  Price='$Price', 
							  EnginePower='$EnginePower' 
							WHERE CarID='$CarID'";
							
	mysql_query($sql);
}

function UpdateCarStatus($CarStatus, $CarID)
{
	$sql="UPDATE tbl_car SET CarStatus='$CarStatus' WHERE CarID='$CarID'";
	mysql_query($sql);
}

function UpdateStatus($Status, $CarID)
{
	$sql="UPDATE tbl_car SET Status='$Status' WHERE CarID='$CarID'";
	mysql_query($sql);
}

function RemoveCarPhoto($PhotoID)
{
	$sql="DELETE FROM tbl_carphoto WHERE PhotoID='$PhotoID'";
	mysql_query($sql);
}

function IncreaseView($CarID)
{
	$sql="UPDATE tbl_car SET CarView=CarView+1 WHERE CarID='$CarID'";
	mysql_query($sql);
}

function DeleteCar($CarID)
{
	$sql="DELETE FROM tbl_car WHERE CarID='$CarID'";
	mysql_query($sql);
}
?>