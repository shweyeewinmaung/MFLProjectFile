<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>

</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         
         <div style="width:600px; margin:20px auto; border-radius:10px; font-size:14px;">
            
            <table>
             <tr>
                    <td colspan="2"><h1 style="color:#2c4c09; margin-left:150px;">Admin's Page</h1></td>
                    
                </tr>
                <tr>
                    <td id="tddesign"><a href="#">- View All Car</a></td>
                    <td id="tddesign"><a href="#">- Add Township</a></td>
                </tr>
                <tr>
                    <td id="tddesign"><a href="#">- Add Car</a></td>
                    <td id="tddesign"><a href="#">- Add City</a></td>
                </tr>
                <tr>
                    <td id="tddesign"><a href="#">- Add Admin</a></td>
                    <td id="tddesign"><a href="#">- Add City</a></td>
                </tr>
                <tr>
                    <td id="tddesign"><a href="#">- Change Password</a></td>
                    <td id="tddesign"><a href="#"></a></td>
                </tr>
            </table>
        </div>
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>