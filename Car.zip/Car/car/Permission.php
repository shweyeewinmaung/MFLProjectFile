<?php
	if(!isset($_SESSION['SESS']['User']['UserID']))
	{
		header("Location:LogIn.php");
	}
?>