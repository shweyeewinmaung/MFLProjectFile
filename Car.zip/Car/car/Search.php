<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_advertise.php");
require_once("dal/dal_car.php");
require_once("dal/dal_brand.php");
require_once("dal/dal_city.php");
require_once("dal/dal_township.php");
require_once("dal/dal_user.php");
require_once("library/function.php");
require_once("library/pager_car.php");
require_once("library/globalfunction.php");


$pageSize=7;

if(isset($_GET['page']))
{
	$currentPageIndex=Clean($_GET['page']);
}
else
{
	$currentPageIndex=1;
}

$objPager=new pager($pageSize,$currentPageIndex);


if(isset($_POST['Brand']) || isset($_POST['CarName']) || isset($_POST['CarType']) || isset($_POST['Model']) || isset($_POST['Price']))
{
	$Brand=Clean($_POST['Brand']);

	$CarName=Clean($_POST['CarName']);
	$CarType=Clean($_POST['CarType']);
	$Model=Clean($_POST['Model']);
	$Price=Clean($_POST['Price']);
	
	$sql=$objPager->SearchData_CarSearch($_POST['Brand'], $_POST['CarName'], $_POST['CarType'], $_POST['Model'], $_POST['Price']);
	$ret=$objPager->Search_Data($sql);
	$num=mysql_num_rows($ret);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>
<style>
a{ color:#2c4c09; text-decoration:underline;}
a:hover{ color:#000; text-decoration:underline;}
</style>
</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
         
         <div style="width:600px; height:auto; overflow:hidden; margin:5px auto;  border-radius:10px; font-size:16px;">
    	<form method="post">
        <table style="width:100%; overflow:hidden; float:left;">	
         <tr>
            	<td colspan="6" ><h2 style="color:#2c4c09; line-height:30px; text-align:center;">Search Car By</h2></td>
            </tr>
			
            <tr>
            	<td colspan="6"><br /></td>
            </tr>
            <tr style="font:bold; color:#2c4c09; text-align:center;">
            	<td>Brand</td>
                <td>Car Name</td>
                <td>Car Type</td>
                <td>Model</td>
                <td>Price</td>
            </tr>
            <tr>
            	<td width="18%;"><select name="Brand" style="width:90px; height:28px; border:2px solid#666;">
                	<option></option>
                	<?php
						$retBrand=GetAllBrandData();
						
						while($rowBrand=mysql_fetch_array($retBrand))
						{
							echo "<option>" . $rowBrand['BrandName'] . "</option>";
						}
					?>
                </select></td>
                
                <td width="18%;"><input type="text" name="CarName" style="width:90px; height:22px; border:2px solid#666;" /></td>
                
                <td width="18%;"><select name="CarType" style="width:90px; height:28px; border:2px solid#666;">
                	<option></option>
                	<option>Sedan</option>
                    <option>Hatchback</option>
                    <option>Stationwagon</option>
                    <option>Sports</option>
                    <option>SUV</option>
                    <option>Truck</option>
                    <option>Bus</option>
                    <option>Others</option>
                    <option>MPV(Minivan)</option>
                </select></td>
                
                <td width="18%;"><input type="text" name="Model" style="width:90px; height:22px; border:2px solid#666;" /></td>
                
                <td width="16%;"><select name="Price" style="width:90px; height:28px; border:2px solid#666;">
                	<option>0 to 50L</option>
                    <option>50L to 75L</option>
                    <option>75L to 100L</option>
                    <option>100L to 150L</option>
                    <option>150L to 200L</option>
                    <option>200L to 300L</option>
                    <option>300L to 400L</option>
                    <option>400L to 500L</option>
                    <option>500L to 600L</option>
                    <option>Over 600L</option>
                </select></td>
                
                <td width="12%;"><input type="submit" name="btnSearch" value="Search"  class="btnstyle"/></td>
            </tr>
        </table>
        <br /><br />
        </form>
        <br />
       <form style="margin-top:120px;"> 
        <?php
			
			//if(!isset($_POST['Brand']) || !isset($_POST['CarName']) || !isset($_POST['CarType']) || !isset($_POST['Model']) || !isset($_POST['Price']) || !isset($_GET['page']))
			if(!isset($_POST['btnSearch']) && !isset($_GET['page']))
			{
				
				$numP=GetA_PopularCount();
				if($numP>0)
				{
					$retP=GetA_Popular();
					$rowP=mysql_fetch_array($retP);
					$retPR=GetCarDataByCarID($rowP['CarID']);
					$rowPR=mysql_fetch_array($retPR);
					?>
                    	<div style="width:600px; margin:60px auto; padding:20px; border:1px solid black; background:#c7ec9f; border-radius:10px;">
                            <table>
                            	<tr>
                                	<td colspan="7" style="color:#2c4c09;">Popular Car</td>
                                </tr>
                                <tr>
                                    <td rowspan="3" width="10%"><img src="carphoto/<?php echo $rowPR['Photo']; ?>" width="100px;" height="100px;" style="border:2px solid#666;" /></td>
                                    <td width="30%">Brand - <?php echo GetBrandNameByBrandID($rowPR['2']); ?></td>
                                    <td width="30%">Name - <?php echo $rowPR['CarName']; ?></td>
                                    <td width="25%">Model - <?php echo $rowPR['Model']; ?></td>
                                    <td rowspan="3" width="5%"><a href="CarDetail.php?CarID=<?php echo $rowPR['CarID']; ?>">Check</a></td>
                                </tr>
                                <tr>
                                    <td>Engine - <?php echo $rowPR['EnginePower']; ?></td>
                                    <td>Brand - <?php echo GetBrandNameByBrandID($rowPR['2']); ?></td>
                                    <td>Price - <?php echo $rowPR['Price']; ?></td>
                                </tr>
                                <tr>
                                    <td>Owner - <?php echo $rowPR['ContactPerson']; ?></td>
                                    <td>Owner No -<?php echo $rowPR['ContactNumber']; ?></td>
                                    <td>Car Status - <?php echo $rowPR['CarStatus']; ?></td>
                                </tr>
                            </table>
                        </div></form>
                    <?php
				}
				
				$numPr=GetA_PremiumCount();
				if($numPr>0)
				{
					
					$retPr=GetA_Premium();
					
					for($i=0;$i<$numPr;$i++)
					{
						$rowPr=mysql_fetch_array($retPr);
						$retPrR=GetCarDataByCarID($rowPr['CarID']);
						$rowPrR=mysql_fetch_array($retPrR);
						
						$retcp=GetCarPhotoByCarID($rowPr['CarID']);
						$rowcp=mysql_fetch_array($retcp);

						?>
							<div style=" margin:60px auto; padding:20px; border:1px solid black; background:#c7ec9f; border-radius:10px;">
								<table>
									<tr>
										<td colspan="7" style="color:#2c4c09;">Premium Car</td>
									</tr>
									<tr>
										<td rowspan="3" width="10%"><img src="carphoto/Mini/<?php echo $rowcp['PhotoMini']; ?>" width="100px;" height="100px;" style="border:2px solid#666;" /></td>
										<td width="30%">Brand - <?php echo GetBrandNameByBrandID($rowPrR['2']); ?></td>
										<td width="30%">Name - <?php echo $rowPrR['CarName']; ?></td>
										<td width="25%">Model - <?php echo $rowPrR['Model']; ?></td>
										<td rowspan="3" width="5%"><a href="CarDetail.php?CarID=<?php echo $rowPrR['CarID']; ?>">Check</a></td>
									</tr>
									<tr>
										<td>Engine - <?php echo $rowPrR['EnginePower']; ?></td>
										<td>Brand - <?php echo GetBrandNameByBrandID($rowPrR['2']); ?></td>
										<td>Price - <?php echo $rowPrR['Price']; ?></td>
									</tr>
									<tr>
										<td>Owner - <?php echo $rowPrR['ContactPerson']; ?></td>
										<td>Owner No -<?php echo $rowPrR['ContactNumber']; ?></td>
										<td>Car Status - <?php echo $rowPrR['CarStatus']; ?></td>
									</tr>
								</table>
							</div>
						<?php
					}
				}
			}
			
			
			
			
			if($num>0)
			{
				
				for($i=0;$i<$num;$i++)
				{
				$row=mysql_fetch_array($ret);
				?>

                	
					<div style="width:550px; margin:60px auto; padding:20px; border:1px solid black;background:#c7ec9f; border-radius:10px;">
						<table>
							<tr>
								<td rowspan="3" width="10%"><img src="carphoto/<?php echo $row['Photo']; ?>" width="100px;" height="100px;" style="border:2px solid#666;" /></td>
								<td width="30%">Brand - <?php echo GetBrandNameByBrandID($row['2']); ?></td>
								<td width="30%">Name - <?php echo $row['CarName']; ?></td>
								<td width="25%">Model - <?php echo $row['Model']; ?></td>
								<td rowspan="3" width="5%"><a href="CarDetail.php?CarID=<?php echo $row['CarID']; ?>">Check</a></td>
							</tr>
							<tr>
								<td>Engine - <?php echo $row['EnginePower']; ?></td>
								<td>Brand - <?php echo GetBrandNameByBrandID($row['2']); ?></td>
								<td>Price - <?php echo $row['Price']; ?></td>
							</tr>
							<tr>
								<td>Owner - <?php echo $row['ContactPerson']; ?></td>
								<td>Owner No -<?php echo $row['ContactNumber']; ?></td>
								<td>Car Status - <?php echo $row['CarStatus']; ?></td>
							</tr>
						</table>
					</div>
				<?php
				}
			}
			elseif(isset($num) && $num<=0)
			{
				//echo 0;
			}
			
		?>
        
	</div>
         
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>
