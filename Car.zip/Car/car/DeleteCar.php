<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_car.php");
require_once("dal/dal_brand.php");
require_once("dal/dal_township.php");
require_once("library/function.php");
require_once("library/globalfunction.php");

include("Permission.php");

$UserID=$_SESSION['SESS']['User']['UserID'];


if(isset($_POST['btnDelete']) && isset($_POST['CarID']) && $_POST['CarID']!="")
{
	$CarID=Clean($_POST['CarID']);
	$retu=CheckCarDataByCarIDAndUserID($CarID, $UserID);
	$numu=mysql_num_rows($retu);
	
	if($numu>0)
	{
		DeleteCar($CarID);
		$_SESSION['DeleteCar']="Deleted";
		header("Location:ViewCar.php");
	}
}

if (isset($_GET['CarID']) && $_GET['CarID']!="")
{	
	$CarID=Clean($_GET['CarID']);
	$ret=CheckCarDataByCarIDAndUserID($CarID, $UserID);
	$num=mysql_num_rows($ret);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/tablestyle.css"/>

</head>
<body>
   <?php include("template/header.php"); ?>
 <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
        <div style="width:600px; margin:10px auto;  border-radius:10px; font-size:16px;">
    	<?php
			if(isset($num) && $num>0)
			{
				$retc=GetCarDataByCarID($CarID);
				$rowc=mysql_fetch_array($retc);
				$retp=GetCarPhotoByCarID($CarID);
				$rowp=mysql_fetch_array($retp);
				?>
                <form method="POST">
                <input type="hidden" name="CarID" value="<?php echo $rowc['CarID']; ?>" />
                    <table style="margin:0 auto;">
                      
                         <tr>
                            <td colspan="2"><h1 style="color:#2c4c09; margin-left:100px; ">Delete Car</h1></td>
                            
                        </tr>
                        <tr style="line-height:25px;">
                            <td style="float:right; ">Car No : </td>
                            <td><?php echo $rowc['CarNo']; ?></td>
                        </tr>
                        <tr style="line-height:25px;">
                        <td style="float:right; ">Car Brand : </td>
                         <td>
                          <?php
                                            $ret1=GetAllBrandData();
                                            
                                           $row1=mysql_fetch_array($ret1);
                                          echo   $row1['BrandName'] ;
                                            
                                        ?>
                            
                         </td>
                        </tr>
                        <tr style="line-height:25px;">
                            <td style="float:right; ">Car Name : </td>
                            <td><?php echo $rowc['CarName']; ?></td>
                        </tr>
                        <tr style="line-height:25px;">
                            <td style="float:right; ">Model : </td>
                            <td><?php echo $rowc['Model']; ?></td>
                        </tr>
                        <tr style="line-height:25px;">
                            <td style="float:right; ">Kilo : </td>
                            <td><?php echo $rowc['Kilo']; ?></td>
                        </tr>
                        <tr style="line-height:25px;">
                            <td style="float:right; ">Gear : </td>
                            <td><?php echo $rowc['Gear']; ?></td>
                        </tr>
                        <tr style="line-height:25px;">
                            <td style="float:right; ">Fuel : </td>
                            <td><?php echo $rowc['Fuel']; ?></td>
                        </tr>
                        <tr style="line-height:25px;">
                            <td style="float:right; ">CarType : </td>
                            <td><?php echo $rowc['CarType']; ?></td>
                        </tr>
                        <tr style="line-height:25px;">
                            <td valign="top"style="float:right; ">Description : </td>
                            <td><?php echo $rowc['Description']; ?></td>
                        </tr>
                        <tr style="line-height:25px;">
                            <td style="float:right; ">ContactPerson : </td>
                            <td><?php echo $rowc['ContactPerson']; ?></td>
                        </tr>
                        <tr style="line-height:25px;">
                            <td style="float:right; ">ContactNumber : </td>
                            <td><?php echo $rowc['ContactNumber']; ?></td>
                        </tr>
                        <tr style="line-height:25px;">
                            <td style="float:right; ">Price : </td>
                            <td><?php echo $rowc['Price']; ?></td>
                        </tr>
                        <tr style="line-height:25px;">
                            <td style="float:right; ">EnginePower : </td>
                            <td><?php echo $rowc['EnginePower']; ?></td>
                        </tr>
                        <tr>
                            <td valign="top" style="float:right; ">Photo : </td>
                            <td ><img src="carphoto/Mini/<?php echo $rowp['PhotoMini']; ?>" width="200px;" height="200px;" style="border:2px solid#333;" /></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                            <input type="submit" value="Delete" class="btnstyle" name="btnDelete"/>
                            </td>
                        </tr>
                    </table>
                </form>
                <?php
			}
			else
			{
				echo "Unable to perform this task!";
			}
		?>
		
	</div>
        
        
        
        
         </div>
	 <!---------Form End----------->
	</div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
   </body>
</html>
