<?php
session_start();

require_once("library/db.php");
require_once("dal/dal_car.php");
require_once("dal/dal_advertise.php");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

</head>
<script src="javascript/jquery-1.6.2.min.js" type="text/javascript" charset="utf-8"></script>
<script src="javascript/jquery.jcarousel.min.js" type="text/javascript" charset="utf-8"></script>
<script src="javascript/functions.js" type="text/javascript" charset="utf-8"></script>
<link rel="stylesheet" type="text/css" href="css/smallslide.css" />

<body onload="Start()">

<?php include("template/header.php"); ?>
  <div class="content">
    <div class="content_resize">
    <!-------mainbar Start------------->
      <div class="mainbar">
        <!---------Form start----------->
         <div style="width:680px; height:auto; margin-top:-1px; float:left;  overflow:hidden; border:5px solid #2c4c09; margin-left:-23px;">
    	<fieldset>
    		<legend style="color:#4a5a38;font-weight:bold;">Premium Car</legend>
            <div id="showc">
                <?php
                    $sqla="SELECT a.*, c.* FROM tbl_advertise a, tbl_car c WHERE a.CarID=c.CarID AND a.Status='Active'";
                    $reta=mysql_query($sqla);
                    $numa=mysql_num_rows($reta);
                    
                    if($numa>0)
                    {
						?>
                        	<div id="main" class="shell">
                                <!-- Begin Content -->
                                <!-- Begin Products Slider -->
                                <div id="product-slider">
                                    <ul>
                                    <?php
										while($rowa=mysql_fetch_array($reta))
										{
											$retpa=GetCarPhotoByCarID($rowa['CarID']);
											$rowpa=mysql_fetch_array($retpa);
											?>
                                            	<li>
                                                    <a href="CarDetail.php?CarID=<?php echo $rowa['CarID']; ?>">
                                                    <img src="carphoto/Mini/<?php echo $rowpa['PhotoMini']; ?>" alt="Product Image" style="Width:100px;Height:90px; border:2px solid#30312f;"/>
                                                   <font style="margin-left:10px;"> <?php echo $rowa['Brand']; ?> <?php echo $rowa['CarName']; ?><br />
                                                    <?php echo $rowa['Model']; ?> - <?php echo $rowa['Price']; ?></font>
                                                    </a>
                                                </li>
                                            <?php
										}
									?>
                                    </ul>
                                </div>
                                <!-- End Products Slider -->
                            </div>
                        <?php
                    }
                ?>
            </div>
        </fieldset>
         <fieldset style="margin-top:2%;">
    		<legend style="color:#4a5a38;font-weight:bold;">Most viewed car</legend>
            <div id="showc">
                <?php
                    $sqlv="SELECT * FROM tbl_car ORDER BY CarView DESC LIMIT 12";
                    $retv=mysql_query($sqlv);
                    $numv=mysql_num_rows($retv);
                    
                    if($numv>0)
                    {
                        while($rowv=mysql_fetch_array($retv))
                        {
							$retpv=GetCarPhotoByCarID($rowv['CarID']);
							$rowpv=mysql_fetch_array($retpv);
                            ?>
                                <div class="mini" align="center">
                                    <a href="CarDetail.php?CarID=<?php echo $rowv['CarID']; ?>">
                                    <img src="carphoto/Mini/<?php echo $rowpv['PhotoMini']; ?>" width="80px;" height="70px;" style="border:2px solid#30312f;" /><br />
                                    <b><?php echo $rowv['Brand']; ?> <?php echo $rowv['CarName']; ?></b><br />
                                    <?php echo $rowv['Model']; ?> - <?php echo $rowv['Fuel']; ?><br />
                                    <?php echo $rowv['Price']; ?>
                                    </a>
                                </div>
                            <?php
                        }
                    }
                ?>
            </div>
        </fieldset>
        
        
        <fieldset style="margin-top:2%;">
    		<legend style="color:#4a5a38;font-weight:bold;">Latest Car</legend>
            <div id="showc">
                <?php
                    $sqln="SELECT * FROM tbl_car ORDER BY CarID DESC LIMIT 40";
                    $retn=mysql_query($sqln);
                    $numn=mysql_num_rows($retn);
                    
                    if($numn>0)
                    {
                        while($rown=mysql_fetch_array($retn))
                        {
							$retpn=GetCarPhotoByCarID($rown['CarID']);
							$rowpn=mysql_fetch_array($retpn);
                            ?>
                                <div class="mini" align="center">
                                    <a href="CarDetail.php?CarID=<?php echo $rown['CarID']; ?>">
                                    <img src="carphoto/Mini/<?php echo $rowpn['PhotoMini']; ?>" width="80px;" height="70px;" style="border:2px solid#30312f;" /><br />
                                    <b><?php echo $rown['Brand']; ?> <?php echo $rown['CarName']; ?></b><br />
                                    <?php echo $rown['Model']; ?> - <?php echo $rown['Fuel']; ?><br />
                                    <?php echo $rown['Price']; ?>
                                    </a>
                                </div>
                            <?php
                        }
                    }
                ?>
            </div>
        </fieldset>
        </div>
        
        
        <!---------Form End--------->
        
      </div><!---mainbar End----->
      <?php include("template/sidebar.php"); ?>
      <div class="clr"></div>
    </div>
  </div>
  
   <?php include("template/footer.php"); ?>
</body>
</html>