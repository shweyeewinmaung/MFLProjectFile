-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 30, 2015 at 07:48 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mflcar`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_advertise`
--

CREATE TABLE IF NOT EXISTS `tbl_advertise` (
  `AID` int(11) NOT NULL AUTO_INCREMENT,
  `CarID` varchar(20) NOT NULL,
  `AdminID` varchar(20) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `Price` int(11) NOT NULL,
  `AStatus` varchar(20) NOT NULL,
  `Status` varchar(20) NOT NULL,
  PRIMARY KEY (`AID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_advertise`
--

INSERT INTO `tbl_advertise` (`AID`, `CarID`, `AdminID`, `StartDate`, `EndDate`, `Price`, `AStatus`, `Status`) VALUES
(1, 'Car-000007', '1', '2014-12-14', '2014-12-21', 10000, 'Premium', 'Active'),
(6, 'Car-000001', '1', '2015-01-01', '2015-01-10', 100000, 'Premium', 'Active'),
(5, 'Car-000002', '1', '2015-01-01', '2015-01-10', 10000, 'Premium', 'Active'),
(4, 'Car-000005', '1', '1970-01-01', '1970-01-01', 10000, 'Premium', 'Active'),
(7, 'Car-000014', '1', '1970-01-01', '1970-01-01', 10000, 'Premium', 'Active'),
(8, 'Car-000013', '1', '1970-01-01', '1970-01-01', 10000, 'Premium', 'Active'),
(9, 'Car-000012', '1', '1970-01-01', '1970-01-01', 10000, 'Premium', 'Active'),
(10, 'Car-000011', '1', '1970-01-01', '1970-01-01', 10000, 'Premium', 'Active'),
(11, 'Car-000010', '1', '1970-01-01', '1970-01-01', 10000, 'Premium', 'Active'),
(12, 'Car-000009', '1', '1970-01-01', '1970-01-01', 10000, 'Premium', 'Active'),
(13, 'Car-000008', '1', '1970-01-01', '1970-01-01', 10000, 'Premium', 'Active'),
(14, 'Car-000006', '1', '1970-01-01', '1970-01-01', 20000, 'Normal', 'Active'),
(15, 'Car-000003', '1', '1970-01-01', '1970-01-01', 10000, 'Premium', 'Active'),
(16, 'Car-000004', '1', '1970-01-01', '1970-01-01', 10000, 'Premium', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

CREATE TABLE IF NOT EXISTS `tbl_brand` (
  `BrandID` int(11) NOT NULL AUTO_INCREMENT,
  `BrandName` varchar(500) NOT NULL,
  `UserID` varchar(2) NOT NULL,
  PRIMARY KEY (`BrandID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_brand`
--

INSERT INTO `tbl_brand` (`BrandID`, `BrandName`, `UserID`) VALUES
(1, 'Toyota', ''),
(2, 'Honda', 'Us'),
(3, 'Nissan', 'Us'),
(4, 'aa', ''),
(5, 'aaa', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_car`
--

CREATE TABLE IF NOT EXISTS `tbl_car` (
  `CarID` varchar(30) NOT NULL,
  `CarNo` varchar(30) NOT NULL,
  `Brand` varchar(50) NOT NULL,
  `CarName` varchar(70) NOT NULL,
  `Model` varchar(70) NOT NULL,
  `Kilo` varchar(60) NOT NULL,
  `Gear` varchar(50) NOT NULL,
  `Fuel` varchar(50) NOT NULL,
  `CarType` varchar(60) NOT NULL,
  `Description` varchar(5000) NOT NULL,
  `ContactPerson` varchar(300) NOT NULL,
  `ContactNumber` varchar(40) NOT NULL,
  `TownshipID` varchar(40) NOT NULL,
  `Price` int(11) NOT NULL,
  `EnginePower` varchar(50) NOT NULL,
  `mPhotoMini` varchar(5000) NOT NULL,
  `mPhotoLarge` varchar(5000) NOT NULL,
  `UserID` varchar(40) NOT NULL,
  `CarView` int(11) NOT NULL,
  `CarLike` int(11) NOT NULL,
  `CarStatus` varchar(50) NOT NULL,
  `Status` varchar(40) NOT NULL,
  `PublishDate` date NOT NULL,
  `PublishTime` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_car`
--

INSERT INTO `tbl_car` (`CarID`, `CarNo`, `Brand`, `CarName`, `Model`, `Kilo`, `Gear`, `Fuel`, `CarType`, `Description`, `ContactPerson`, `ContactNumber`, `TownshipID`, `Price`, `EnginePower`, `mPhotoMini`, `mPhotoLarge`, `UserID`, `CarView`, `CarLike`, `CarStatus`, `Status`, `PublishDate`, `PublishTime`) VALUES
('Car-000004', '2D/8726', '1', 'Stream', '2009', '120000', 'Auto', 'Petrol', 'Bus', 'sssss', 'U Win Naing', '111', 'TB-000003', 6000000, '2.0', '1416614536IMG_20140831_093805.jpg', '', 'Usr-000001', 1, 1, 'Normal', 'Active', '2014-12-01', '11:11:11'),
('Car-000006', '3E/8899', '3', 'Stream', '2013', '133000', 'Auto', 'Petrol', 'Bus', 'a', 'U Win Naing', '111', 'TB-000002', 10000000, '2.0', '1416614536IMG_20140831_093805.jpg', '', 'Usr-000001', 1, 1, 'Normal', 'Active', '2014-12-01', '11:11:11'),
('Car-000008', '4D/8726', '3', 'Stream', '2013', '120000', 'Auto', 'Petrol', 'Bus', 'a', 'U Win Naing', '111', 'TB-000002', 30000000, '2.0', '3.jpg', '', 'Usr-000001', 1, 1, 'Normal', 'Active', '2014-12-01', '11:11:11'),
('Car-000009', '2F/7111', '2', 'Civic', '2010', '120000', 'Auto', 'Petrol', 'MPV(Minivan)', 'asdf', 'PPK', '199', 'TB-000001', 35000000, '1.3', '080336000 1417739475.jpg', '', 'Usr-000001', 1, 1, 'Normal', 'Active', '2014-12-01', '11:11:11'),
('Car-000010', '7E/8111', '3', 'Stream', '2013', '133000', 'Auto', 'Petrol', 'Bus', 'a', 'U Win Naing', '111', 'TB-000002', 40000000, '2.0', '14200013091419816495f.jpg', '', 'Usr-000001', 1, 1, 'Normal', 'Active', '2014-12-01', '11:11:11'),
('Car-000011', '1I/7119', '2', 'Civic', '2012', '110000', 'Auto', 'Petrol', 'MPV(Minivan)', 'asdf', 'PPK', '199', 'TB-000001', 50000000, '1.3', 'h.jpg', '', 'Usr-000001', 1, 1, 'Normal', 'Active', '2014-12-01', '11:11:11'),
('Car-000012', '2I/8726', '3', 'Stream', '2009', '120000', 'Auto', 'Petrol', 'Bus', 'a', 'U Win Naing', '111', 'TB-000002', 60000000, '2.0', '1408513885_car-image.jpg', '', 'Usr-000001', 1, 1, 'Normal', 'Active', '2014-12-01', '11:11:11'),
('Car-000013', '3I/7000', '2', 'Civic', '2010', '120000', 'Auto', 'Petrol', 'MPV(Minivan)', 'asdf', 'PPK', '199', 'TB-000001', 70000000, '1.3', '2.jpg', '', 'Usr-000001', 1, 1, 'Normal', 'Active', '2014-12-01', '11:11:11'),
('Car-000014', '4I/8899', '3', 'Stream', '2013', '133000', 'Auto', 'Petrol', 'Bus', 'a', 'U Win Naing', '111', 'TB-000002', 80000000, '2.0', '043562000 1417740459.jpg', '', 'Usr-000001', 2, 1, 'Normal', 'Active', '2014-12-01', '11:11:11'),
('Car-000015', 't', '1', 't', 't', 't', 'Auto', 'Petrol', 'Truck', 't', 't', 't', 'TB-000004', 0, 't', 'thumb102689989100x100.jpg', 'd.jpg', 'Usr-000001', 0, 0, 'Used', 'Active', '0000-00-00', '08:54:12'),
('Car-000016', 'aa', '1', 'a', 'aa', 'aa', 'Auto', 'Petrol', 'Sedan', 'aa', 'aa', 'aa', 'TB-000002', 0, 'aa', '', '', 'Usr-000001', 0, 0, 'Used', 'Active', '0000-00-00', '11:22:20');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_carphoto`
--

CREATE TABLE IF NOT EXISTS `tbl_carphoto` (
  `PhotoID` int(11) NOT NULL AUTO_INCREMENT,
  `CarID` varchar(20) NOT NULL,
  `PhotoMini` varchar(5000) NOT NULL,
  `PhotoLarge` varchar(5000) NOT NULL,
  PRIMARY KEY (`PhotoID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_carphoto`
--

INSERT INTO `tbl_carphoto` (`PhotoID`, `CarID`, `PhotoMini`, `PhotoLarge`) VALUES
(1, 'Car-000016', 'thumb1072719326100x100.jpg', '1427172740_528677769.png'),
(2, 'Car-000016', 'thumb949217934100x100.jpg', '1427172761_1792709911.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_city`
--

CREATE TABLE IF NOT EXISTS `tbl_city` (
  `CityID` varchar(20) NOT NULL,
  `CityName` varchar(255) NOT NULL,
  PRIMARY KEY (`CityID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_city`
--

INSERT INTO `tbl_city` (`CityID`, `CityName`) VALUES
('Ct-000001', 'Yangon'),
('Ct-000002', 'aaa');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_news`
--

CREATE TABLE IF NOT EXISTS `tbl_news` (
  `NewsID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` text NOT NULL,
  `Description` text NOT NULL,
  `NewsDate` varchar(20) NOT NULL,
  `NewsTime` varchar(20) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `UserID` varchar(20) NOT NULL,
  PRIMARY KEY (`NewsID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tbl_news`
--

INSERT INTO `tbl_news` (`NewsID`, `Title`, `Description`, `NewsDate`, `NewsTime`, `Status`, `UserID`) VALUES
(17, 'ddddd', 'ddddddddddddddddddddddddddddddd', '2015-Mar-31', '01:19:26', 'Active', 'Usr-000001'),
(16, 'ccccccccc', 'cccccccccccccccccc ccccccccccccccccccccccc', '2015-Mar-31', '01:20:22', 'Active', 'Usr-000001'),
(15, 'bbbbbb', 'bbbbbbbbbbbbbbbbbbbb  bbbbbbbbbbbbbbbbb', '2015-Mar-31', '01:20:15', 'Active', 'Usr-000001'),
(14, 'aaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaaaaaa', '2015-Mar-31', '01:18:41', 'Active', 'Usr-000001'),
(18, 'ddddd', 'ddddddddddddddddddddddddddddddd', '2015-Mar-31', '02:10:59', 'Active', 'Usr-000001');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_photo`
--

CREATE TABLE IF NOT EXISTS `tbl_photo` (
  `CarID` varchar(20) NOT NULL,
  `PhotoID` varchar(20) NOT NULL,
  `Path` varchar(5000) NOT NULL,
  `Description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_photo`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_township`
--

CREATE TABLE IF NOT EXISTS `tbl_township` (
  `TownshipID` varchar(10) NOT NULL,
  `CityID` varchar(50) DEFAULT NULL,
  `TownshipName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`TownshipID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_township`
--

INSERT INTO `tbl_township` (`TownshipID`, `CityID`, `TownshipName`) VALUES
('TB-000002', 'Ct-000001', 'Sanchaung'),
('TB-000001', 'Ct-000001', 'a'),
('TB-000003', 'Ct-000001', 'Dagon'),
('TB-000004', 'Ct-000001', 'Tamwe'),
('TB-000005', 'Ct-000001', 'aaa');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `UserID` varchar(20) NOT NULL,
  `FullName` varchar(255) NOT NULL,
  `DOB` varchar(50) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Phone` varchar(135) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `UserName` varchar(135) NOT NULL,
  `Password` varchar(135) NOT NULL,
  `Role` varchar(20) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`UserID`, `FullName`, `DOB`, `Gender`, `Phone`, `Email`, `UserName`, `Password`, `Role`, `Status`) VALUES
('Usr-000001', 'Pyay Phyo Kyaw', '1/1/2000', 'Male', '199', 'ppk@gmail.com', 'ppk', '3bb3f4dbc050a34d9c401067d396db13', 'Member', 'Active'),
('Usr-000003', 'bb', 'bb', 'bb', 'bb', 'bb', 'bb', '21ad0bd836b90d08f4cf640b4c298e7c', 'Member', 'Active'),
('Usr-000002', 'aa', 'aa', 'aa', 'aa', 'aa', 'aa', '4124bc0a9335c27f086f24ba207a4912', 'Member', 'Active');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
