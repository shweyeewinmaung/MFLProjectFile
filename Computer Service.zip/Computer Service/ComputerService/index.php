<!doctype html>
<html class="no-js" lang="en">
<head>

<script src="js/libs/modernizr-2.5.2.min.js"></script>
</head>
<body>
<?php require_once('template/header.php'); ?>
<section role="banner">
<!--  <hgroup>
    <h1>An HTML5/CSS3 powered website that contains very less images</h1>
    <h2>Even the icons used are texts icons, easier to use/customize and load page faster.</h2>
  </hgroup>-->
  <article role="main" class="clearfix">
    <div class="post">
      <h2>It Fits: an HTML5/CSS3 Responsive template</h2>
      <p>Nunc porta, mauris sit amet laoreet vestibulum, elit leo iaculis lorem, mattis euismod eros lorem sed est. Donec porttitor augue vel nisl blandit gravida. Etiam eu purus non enim vehicula ultrices a non neque.</p>
      <p>Morbi purus odio, faucibus sit amet elementum in:</p>
      <ul>
        <li>interdum eu ipsum.</li>
        <li>Donec cursus pellentesque mauris vitae ultricies.</li>
        <li>Donec lacinia nunc in nisl hendrerit scelerisque.</li>
      </ul>
     <!-- <a href="page.html" class="button left">Learn more <span class="icon">:</span></a>--> </div>
    <aside role="complementary"> <a href="#"><img src="images/nature-2.jpg" alt=""></a> </aside>
  </article>
</section>
<!-- // banner ends -->
<section class="container1">
<?php require_once('template/column.php'); ?>
  
  <!-- //.columns -->
<!--  <ul class="thumb-rotator">
    <li><a href="#"><img src="images/logo.jpg" alt=""></a></li>
    <li><a href="#"><img src="images/brand.jpg" alt=""></a></li>
    <li><a href="#"><img src="images/apple.jpg" alt=""></a></li>
    <li><a href="#"><img src="images/nike.jpg" alt=""></a></li>
    <li><a href="#"><img src="images/levi.jpg" alt=""></a></li>
  </ul>-->
</section>
<?php require_once('template/footer.php'); ?>

<script src="js/libs/jquery-1.7.1.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>