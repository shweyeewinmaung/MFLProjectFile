<?php
function GetCustomerDataByCustomerID($CustomerID)
{
	$sql="SELECT * FROM tbl_customer WHERE CustomerID='$CustomerID'";
	return mysql_query($sql);
}
function GetCustomerNameByCustomerID($CustomerID)
{
	$sql="SELECT * FROM tbl_customer WHERE CustomerID='$CustomerID'";
	
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	return $row[1];
}
function InsertCustomer($CustomerID, $CustomerName, $Phone, $Email, $Address)
{
	$sql="INSERT INTO tbl_customer(CustomerID,CustomerName,Phone,Email,Address)
	VALUES('$CustomerID', '$CustomerName', '$Phone', '$Email', '$Address')";
	
	mysql_query($sql);
}

function UpdateCustomer($CustomerID, $CustomerName, $Phone, $Email, $Address)
{ 
	$sql="UPDATE  tbl_customer SET CustomerName='$CustomerName', 
							  Phone='$Phone', 
							  Email='$Email', 
							  Address='$Address'
							 
							WHERE CustomerID='$CustomerID'";
							
	mysql_query($sql);
}
?>