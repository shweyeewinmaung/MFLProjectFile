<?php 



function GetAssignDataByAssignID($AssignID)
{
	$sql="SELECT * FROM tbl_assign order by AssignID asc";
	
	return mysql_query($sql);
}
function GetAssignDataByAssign($AssignID)
{
	$sql="SELECT * FROM tbl_assign Where AssignID='$AssignID'";
	
	return mysql_query($sql);
}
function InsertAssign($AssignID, $ServiceID, $UserID, $AssignDate, $AssignTime, $AssignUser)
{
	$sql="INSERT INTO tbl_assign(AssignID, ServiceID, UserID, AssignDate, AssignTime, AssignUser)
	VALUES('$AssignID', '$ServiceID', '$UserID', '$AssignDate', '$AssignTime', '$AssignUser')";
	
	mysql_query($sql);
}

function UpdateAssign($AssignID,$ServiceID,$UserID,$AssignDate,$AssignTime,$AssignUser)
{
	$sql="UPDATE  tbl_assign SET ServiceID='$ServiceID', 
							  UserID='$UserID', 
							  AssignDate='$AssignDate', 
							  AssignTime='$AssignTime', 
							  AssignUser='$AssignUser'
							 
							 
							WHERE AssignID='$AssignID'";
							
	mysql_query($sql);
}
function DeleteAssign($AssignID)
{
	$sql="DELETE FROM tbl_assign WHERE AssignID='$AssignID'";
	mysql_query($sql);
}

?>