<?php

function GetServiceDataByServiceID($ServiceID)
{
	$sql="SELECT * FROM tbl_service WHERE ServiceID='$ServiceID'";
	return mysql_query($sql);
}
function GetServiceDataByCustomerID($CustomerID)
{
	$sql="SELECT * FROM tbl_service WHERE CustomerID='$CustomerID'";
	return mysql_query($sql);
}

function GetServiceDataByService($ServiceID)
{
	$sql="SELECT * FROM tbl_service  order by ServiceID asc ";
	return mysql_query($sql);
}

function  GetServiceReport_ReceiveCountByReceiveDate($ReceiveDate)
{
	$sql="SELECT COUNT(*) FROM tbl_service WHERE ReceiveDate='$ReceiveDate'";
	//$ret=mysql_query($sql);
	//return mysql_num_rows($ret);
	return mysql_query($sql);
}


function DeleteService($ServiceID)
{
	$sql="DELETE FROM tbl_service WHERE ServiceID='$ServiceID' ";
	echo $sql;
	mysql_query($sql);
}

function InsertService($ServiceID, $CustomerID, $ReceiveDate, $ReceiveTime, $DeliverDate,$DeliverTime, $ServiceType, 
	$Description, $RequireDate, $Quantity,$Charges, $Amount, $Receiver, $TrackNo, $Status)
{
	$sql="INSERT INTO tbl_service(ServiceID, CustomerID, ReceiveDate, ReceiveTime, DeliverDate,DeliverTime, ServiceType, 
	Description, RequireDate, Quantity,Charges, Amount, Receiver, TrackNo,Status)
	VALUES ('$ServiceID', '$CustomerID', '$ReceiveDate', '$ReceiveTime', '$DeliverDate','$DeliverTime', '$ServiceType', 
	'$Description', '$RequireDate', '$Quantity','$Charges', '$Amount', '$Receiver', '$TrackNo', '$Status')";
	
	mysql_query($sql);
}

function AddService($ServiceID, $CustomerID, $ReceiveDate, $ReceiveTime, $DeliverDate,$DeliverTime, $ServiceType, 
	$Description, $RequireDate, $Quantity,$Charges, $Amount, $Receiver, $TrackNo, $Status)
{
	$sql="INSERT INTO tbl_service(ServiceID, CustomerID, ReceiveDate, ReceiveTime, DeliverDate,DeliverTime, ServiceType, 
	Description, RequireDate, Quantity,Charges, Amount, Receiver, TrackNo,Status)
	VALUES ('$ServiceID', '$CustomerID', '$ReceiveDate', '$ReceiveTime', '$DeliverDate','$DeliverTime', '$ServiceType', 
	'$Description', '$RequireDate', '$Quantity','$Charges', '$Amount', '$Receiver', '$TrackNo', '$Status')";
	
	mysql_query($sql);
}

function UpdateService($ServiceID, $CustomerID, $ReceiveDate, $ReceiveTime, $DeliverDate,$DeliverTime, $ServiceType, 
	$Description, $RequireDate, $Quantity,$Charges, $Amount, $Receiver, $TrackNo, $Status)
{ 
	$sql="UPDATE  tbl_service SET CustomerID='$CustomerID', 
							  ReceiveDate='$ReceiveDate', 
							  ReceiveTime='$ReceiveTime', 
							  DeliverDate='$DeliverDate',
							  DeliverTime='$DeliverTime', 
							  ServiceType='$ServiceType', 
							  Description='$Description', 
							  RequireDate='$RequireDate',
							  Quantity='$Quantity', 
							  Charges='$Charges', 
							  Amount='$Amount', 
							  Receiver='$Receiver',
							   TrackNo='$TrackNo', 
							  Status='$Status'
							 
							WHERE ServiceID='$ServiceID'";
							
	mysql_query($sql);
}
?>