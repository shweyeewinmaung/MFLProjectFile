/* Author: $hekh@r d-Ziner */

(function($){
    $(document).ready(function(){

	    
		//fixing ie/older browsers
		$('.oldies .columns article:nth-child(4n)').css('border-right', '0');
		$('.oldies .thumb-list li:nth-child(4n)').css('margin-right','0');

	
	}); //ready
})(jQuery);




