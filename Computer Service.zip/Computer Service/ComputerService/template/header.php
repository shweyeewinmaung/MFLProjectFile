<title>Computer</title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/raphaelicons.css">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/navi.css">
<meta charset="utf-8">
<meta name="HandheldFriendly" content="True">
<meta name="MobileOptimized" content="320">
<meta name="viewport" content="minimum-scale=1.0, width=device-width, maximum-scale=1.0, user-scalable=no">
<link href="http://fonts.googleapis.com/css?family=Oswald:regular" rel="stylesheet" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Junge' rel='stylesheet' type='text/css'>

<body>
<header class="clearfix">
  <div class="container"> <a id="logo" href="index.php">Computer</a>
   <nav class="clearfix">
    
    <div id="topnav">
      <ul role="navigation">
        <li><a href="#" class="activePage"><span class="icon">S</span>Home</a></li>
        <li><a href="#"><span class="icon">E</span>List</a> 
         <ul>
            <li><a href="admin/UserList.php">User List</a></li>
            <li><a href="admin/AllServiceList.php">Service List</a></li>
           
          </ul>
        </li>
        <li><a href="#"><span class="icon">U</span>Entry</a> 
         <ul>
            <li><a href="admin/UserEntry.php">User Entry</a></li>
            <li><a href="admin/ServiceEntry.php">Service Entry</a></li>
            
          </ul>
        </li>
        <li><a href="#"><span class="icon">E</span>Report</a> 
        <ul>
        <li><a href="admin/DailyReport.php">DailtReport</a></li>  
        </ul>       
        </li>
        <li > <a href="#"><span class="icon">M</span>Contact us</a> </li>
        <li > <a href="#"><span class="icon">M</span>Log In</a> </li>
        <li class="last"> <a href="#"><span class="icon">M</span>Log Out</a> </li>
      </ul>
    </div>
    </nav>
  </div>
</header>
</body>