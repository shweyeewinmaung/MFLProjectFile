<div class="columns">
    <article>
      <figure> <img src="images/technics.jpg" alt="">
        <figcaption>
          <h3>Micro-formatted HTML5</h3>
          <p>Pellentesque mi arcu, sollicitudin vel malesu, <a href="#">volutpat vitae nisi.</a> Nulla luctus lacus at tortor blandit semper. Donec gravida aliquet urna, eu pulvinar ligula pellentesque ornare. <a href="#" class="more-link">Read more &rarr;</a></p>
        </figcaption>
      </figure>
    </article>
    <article>
      <figure> <img src="images/sports-2.jpg" alt="" class="alt-col">
        <figcaption>
          <h3>Responsive</h3>
          <p>Pellentesque mi arcu, sollicitudin vel malesu, volutpat vitae nisi. Nulla luctus lacus at tortor blandit semper. Donec gravida aliquet urna, eu pulvinar ligula pellentesque ornare. <a href="#" class="more-link">Read more &rarr;</a></p>
        </figcaption>
      </figure>
    </article>
    <article>
      <figure> <img src="images/people.jpg" alt="">
        <figcaption>
          <h3>Pure CSS3</h3>
          <p>Pellentesque mi arcu, sollicitudin vel malesu, <strong>volutpat vitae nisi. Nulla luctus</strong> lacus at tortor blandit semper. Donec gravida aliquet urna, eu pulvinar ligula pellentesque ornare. <a href="#" class="more-link">Read more &rarr;</a></p>
        </figcaption>
      </figure>
    </article>
    <article>
      <figure> <img src="images/nightlife.jpg" alt="" class="alt-col">
        <figcaption>
          <h3>Browser compatible</h3>
          <p>Pellentesque mi arcu, sollicitudin vel malesu, volutpat vitae nisi. Nulla luctus lacus at tortor blandit semper. Donec gravida aliquet urna, eu pulvinar ligula pellentesque ornare. <a href="#" class="more-link">Read more &rarr;</a></p>
        </figcaption>
      </figure>
    </article>
  </div>