<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_service.php");
require_once("../dal/dal_customer.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");

if (isset($_POST['btnSave']))
{	
	$ServiceID=AutoID('tbl_service','ServiceID','Ser-',6);
	$CustomerID=Clean($_POST['CustomerID']);
	$ReceiveDate=date("Y/m/d");
	$ReceiveTime=GetCurrentTime();
	$DeliverDate="-";
	$DeliverTime="-";
	$ServiceType=Clean($_POST['ServiceType']);
	$Description=Clean($_POST['Description']);
	$RequireDate=Clean($_POST['RequireDate']);
	$Quantity=Clean($_POST['Quantity']);
	$Charges=Clean($_POST['Charges']);
	$Amount=Clean($_POST['Amount']);
	$Receiver=Clean($_POST['Receiver']);
	$TrackNo=Clean($_POST['TrackNo']);
	$Status=Clean($_POST['Status']);
	
	AddService($ServiceID, $CustomerID, $ReceiveDate, $ReceiveTime, $DeliverDate,$DeliverTime, $ServiceType, 
	$Description, $RequireDate, $Quantity,$Charges, $Amount, $Receiver, $TrackNo, $Status);
	/*header("Location:ServiceList.php?CustomerID=$CustomerID");*/
	print "<script language=\"JavaScript\">window.location.href=\"ServiceList.php?CustomerID=$CustomerID\";</script>";
	

}




if (isset($_GET['CustomerID']) && $_GET['CustomerID']!="")
{
	

	$CustomerID=Clean($_GET['CustomerID']);
	$ret=GetCustomerDataByCustomerID($CustomerID);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
	
	/*$ret1=GetServiceDataByCustomerID($CustomerID);
	$num1=mysql_num_rows($ret1);
	
	if($num1>0)
	{
		$row1=mysql_fetch_array($ret1);
	}*/
}



?>
<!doctype html>
<html class="no-js" lang="en">
<head>
<link rel="stylesheet"  href="../css/date.css"/>
    
    <!-- Load jQuery JS -->
    <script src="../js/jquery-1.9.1.js"></script>
    <!-- Load jQuery UI Main JS  -->
    <script src="../js/jquery-ui.js"></script>
    <script type="text/javascript">
	 $(document).ready(
  
  /* This is the function that will get executed after the DOM is fully loaded */
  function () {
    $( "#datepicker" ).datepicker({
      changeMonth: true,//this option for allowing user to select month
      changeYear: true //this option for allowing user to select from year range
    });
  }

);
    
    </script>
    <style>
    .ui-widget-header { background:#5b050d;}
    </style>
</head>
<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post1">

<br>
<font style=" margin-left:400px; font-size:24px;">Add Service</font><br><br>
<form  method="post"  >
<table width="330" style="float:left;">
<!--
<tr>
<td style="float:right; " height="40">CustomerID : </td>
<td>&nbsp;&nbsp;<input name="CustomerID" type="text"  size="30" style="height:27px;" value="<!--?php echo AutoID('tbl_customer','CustomerID','C-',6); ?>" /></td>
</tr>-->
	<tr>
		<td style="float:right;" height="40">CustomerName : </td>
		<td>&nbsp;&nbsp;<?php echo $row['CustomerName']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Phone : </td>
		<td>&nbsp;&nbsp;<?php echo $row['Phone']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Email : </td>
		<td>&nbsp;&nbsp;<?php echo $row['Email']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Address : </td>
		<td>&nbsp;&nbsp;<?php echo $row['Address']; ?></td>
	</tr>
</table>

<table width="430" style="float:right;">
<tr style="display:none;">
<td style="float:right; " height="40">ServiceID : </td>
<td>&nbsp;&nbsp;<input name="ServiceID" type="hidden"  size="30" style="height:27px;" value="<?php echo AutoID('tbl_service','ServiceID','Ser-',6); ?>" /></td>
</tr>
<tr style="display:none;">
<td style="float:right; " height="40">CustomerID : </td>
<td>&nbsp;&nbsp;<input name="CustomerID" type="hidden"  size="30" style="height:27px;" value="<?php echo  $row['CustomerID'] ?>" /></td>
</tr>
	<tr>
		<td style="float:right;" height="40">ReceiveDate : </td>
		<td>&nbsp;&nbsp;<input name="ReceiveDate" type="text"  size="30" style="height:27px;" id="datepicker" maxlength="11" value="<?php echo date("d-M-Y")?>" onFocus="showCalender(calender,this)"/></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">ReceiveTime : </td>
		<td>&nbsp;&nbsp;<input name="ReceiveTime" type="text"  size="30" style="height:27px;" value="<?php echo GetCurrentTime();?>"  /></td>
	</tr>
<!--
<tr>
<td style="float:right;" height="40">DeliveryDate : </td>
<td>&nbsp;&nbsp;<input name="DeliveryDate" type="text"  size="30" style="height:27px;"  /></td>
</tr>
<tr>
<td style="float:right;" height="40">DeliveryTime : </td>
<td>&nbsp;&nbsp;<input name="DeliveryTime" type="text"  size="30" style="height:27px;"  /></td>
</tr>
-->
	<tr>
		<td style="float:right;" height="40">ServiceType : </td>
		<td>&nbsp; <select name="ServiceType"  style="background:#CCC; color:#000; width:207px; height:30px;">
	   					<option>Network </option>
       					<option>Software Installation </option>
       					<option>Hardware </option>
       					<option>Cleaning </option>
       					<option>Driver Installation </option>
        			</select></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Description : </td>
		<td height="95">&nbsp;
      		<textarea name="Description" cols="25" rows="3"style="background:#CCC;"></textarea></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">RequireDate : </td>
		<td >&nbsp;&nbsp;<input name="RequireDate" type="text"  size="30" style="height:27px;"  /></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Quantity : </td>
		<td>&nbsp;&nbsp;<input name="Quantity" type="text"  size="30" style="height:27px;"  /></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Charges : </td>
		<td>&nbsp;&nbsp;<input name="Charges" type="text"  size="30" style="height:27px;"  /></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Amount : </td>
		<td>&nbsp;&nbsp;<input name="Amount" type="text"  size="30" style="height:27px;"  /></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Receiver : </td>
		<td>&nbsp;&nbsp;<input name="Receiver" type="text"  size="30" style="height:27px;"  /></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">TrackNo : </td>
		<td>&nbsp;&nbsp;<input name="TrackNo" type="text"  size="30" style="height:27px;"  /></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Status : </td>
		<td>&nbsp; <select name="Status"  style="background:#CCC; color:#000; width:207px; height:30px;">
	   					<option>Received </option>
       					<option>Servicing </option>
       					<option>Finished </option>
       					<option>Delivered </option>
      					<option>Cancelled</option>
        			</select></td>
	</tr>
	<tr>
		<td></td>
		<td > <input name="btnSave" type="submit" value="Add" class="btnstyle">
      <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle"><br><br></td>
	</tr>
</table>

  
</form>




    
    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>