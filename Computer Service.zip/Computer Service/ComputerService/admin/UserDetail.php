<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");
require_once("../library/pager_house.php");

if(isset($_GET['UserID']) && $_GET['UserID']!="")
{	
	$UserID=$_GET['UserID'];
	//IncreaseView($houseid);
	$ret=GetUserDataByUserID($UserID);
	$num=mysql_num_rows($ret);
}


?>

<!doctype html>
<html class="no-js" lang="en">
<head>
<title>Computer</title>
</head>
<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post">

  <form name="userform" method="post" action="" class="formstyle1" ><br>
   <font style="color:#fff;  font-size:24px; margin-left:250px;">User Detail</font>
    <?php
			if($num>0)
			{
				$row=mysql_fetch_array($ret);
				?>
  <table width="800" border="0">
  <tr>
      <td colspan="2"  height="40"></td>
    </tr>
    
<tr>
            	<td height="40" style="text-align:right; width:200px;">User ID :</td>
                <td style="width:450px;">&nbsp;&nbsp;<?php echo $row['UserID'];?></td>
            </tr>
     <tr>
      <td height="40" style="text-align:right;">Full Name :</td>
      <td>&nbsp;&nbsp;
       <?php echo $row['FullName'];?></td>
    </tr>
    
       <tr>
      <td height="40" style="text-align:right;">Gender :</td>
      <td>&nbsp;&nbsp;<?php echo $row['Gender'];?>
        </td>
        </tr>
         <tr>
      <td height="40" style="text-align:right;">DOB :</td>
      <td>&nbsp;&nbsp;
      
        <?php echo $row['DOB'];?>
       
       </td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Phone :</td>
      <td>&nbsp;&nbsp;
       <?php echo $row['Phone'];?></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Email :</td>
      <td>&nbsp;&nbsp;
        <?php echo $row['Email'];?></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Address :</td>
      <td>&nbsp;&nbsp;
        <?php echo $row['Address'];?></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Username:</td>
      <td>&nbsp;&nbsp;
        <?php echo $row['UserName'];?></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Password :</td>
      <td>&nbsp;&nbsp;
        <?php echo $row['Password'];?></td>
    </tr>
     
    <tr>
      <td height="40" style="text-align:right;">Role :</td>
      <td>&nbsp;&nbsp;
     <?php echo $row['Role'];?></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Status :</td>
      <td>&nbsp;&nbsp;
        <?php echo $row['Status'];?></td>
    </tr>
    
	
    
    
   
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
     <!-- <input name="submit" type="submit" id="submit"  value="Save" class="btnstyle">
      <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle"><br><br>
      <!--<input type="submit" name="submit" id="submit" value="" class="entry" onClick="return Validate()">
      <input type="reset" name="Reset" id="button" value="" class="reset">--></td>
    </tr>
  </table>
   <?php
			}
			else
			{
				?>
                	<center><h1>No result found!</h1></center>
                <?php
			}
		?>
</form>  
    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>