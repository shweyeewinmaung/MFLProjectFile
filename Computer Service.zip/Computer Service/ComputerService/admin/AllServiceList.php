<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_service.php");
require_once("../dal/dal_customer.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");




$ret=GetServiceDataByService($ServiceID);
$num=mysql_num_rows($ret);

$ret1=GetServiceDataByService($ServiceID);
$num1=mysql_num_rows($ret1);
	



?>

<!doctype html>
<html class="no-js" lang="en">
<head>
<link rel="stylesheet" href="../css/tab.css">
<script type='text/javascript' src='../js/juery.min.js'></script>
<script type='text/javascript' src='../js/tab.js'></script>


</head>
<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post1">

 <form method="post" ><br>
      <font style="color:#fff;  font-size:24px; margin-left:400px;">All Service List</font><br><br>
      <div id="example-one">
			
    <ul class="nav">
                <li class="nav-one"><a href="#featured" class="current">Finished</a></li>
                <li class="nav-two"><a href="#core">UnFinished</a></li>
               
    </ul>
	
    <div class="list-wrap">
	
		<ul id="featured" style="margin-left:-30px;">
        <font style=" margin-left:10px;font-size:18px; color:#999;">Finished List</font><br><br>
			<li><table >
     		 <tr style="background:#CCC; color:#900; font-size:16px; height:30px; text-align:center; " >
             		<td width="12%" style="border:2px solid#fff;">ServiceID</td>
                    <td width="12%" style="border:2px solid#fff;">CustomerName</td>
                    <td width="12%" style="border:2px solid#fff;">ReceiveDate</td>
                    <td width="12%" style="border:2px solid#fff;">Receiver</td>
                    <td width="12%" style="border:2px solid#fff;">ServiceType</td>
                    <td width="12%" style="border:2px solid#fff;">TrackNo</td>
                    <td width="12%" style="border:2px solid#fff;">Status</td>
                    <td width="15%" style="border:2px solid#fff;"></td>
                          
      		 </tr>
              <?php  while($row=mysql_fetch_array($ret)){ 
			  if($row['Status']==Finished){
			  ?> 
             <tr style="line-height:30px; font-size:12px; font-family:Arial, Helvetica, sans-serif; text-align:center; ">
            
             		<td><?php echo $row['ServiceID']; ?></td>
                    <td><?php echo GetCustomerNameByCustomerID($row[1]); ?></td>
                    <td><?php echo $row['ReceiveDate']; ?></td>
                    <td><?php echo $row['Receiver']; ?></td>
                    <td><?php echo $row['ServiceType']; ?></td>
                    <td><?php echo $row['TrackNo']; ?></td>
                    <td><?php echo $row['Status']; ?></td>
                    <td >
                    <a href="ServiceList.php?CustomerID=<?php echo $row['CustomerID']; ?>" target="_blank">
    Detail</a> 
   &nbsp;
                                 <a href="ServiceUpdate.php?ServiceID=<?php echo $row['ServiceID']; ?>" target="_blank">
   Update </a> 
   &nbsp; 
    <a href="ServiceDelete.php?CustomerID=<?php echo $row['CustomerID']; ?>" target="_blank">
    Delete</a>
                    
                    
                   </td>
             
             </tr>
             <?php }} ?> 
      </table>
      
      </li>
		</ul>
		 
		 <ul id="core" class="hide" style="margin-left:-30px;">
         <font style=" margin-left:10px;font-size:18px; color:#999;">UnFinished List</font><br><br>
			<li><table >
          
     		 <tr style="background:#CCC; color:#900; font-size:16px; height:30px; text-align:center; " >
             		<td width="12%" style="border:2px solid#fff;">ServiceID</td>
                    <td width="12%" style="border:2px solid#fff;">CustomerName</td>
                    <td width="12%" style="border:2px solid#fff;">ReceiveDate</td>
                    <td width="12%" style="border:2px solid#fff;">Receiver</td>
                    <td width="12%" style="border:2px solid#fff;">ServiceType</td>
                    <td width="12%" style="border:2px solid#fff;">TrackNo</td>
                    <td width="12%" style="border:2px solid#fff;">Status</td>
                    <td width="15%" style="border:2px solid#fff;"></td>
                          
      		 </tr>
               <?php  while($row1=mysql_fetch_array($ret1)){ 
				if($row1['Status']<>Finished){
			  ?>
             <tr style="line-height:30px; font-size:12px; text-align:center; font-family:Arial, Helvetica, sans-serif;">
          
             		<td><?php echo $row1['ServiceID']; ?></td>
                    <td><?php echo GetCustomerNameByCustomerID($row1[1]); ?></td>
                    <td><?php echo $row1['ReceiveDate']; ?></td>
                    <td><?php echo $row1['Receiver']; ?></td>
                    <td><?php echo $row1['ServiceType']; ?></td>
                    <td><?php echo $row1['TrackNo']; ?></td>
                    <td><?php echo $row1['Status']; ?></td>
                    <td style="text-align:left;"> <a href="ServiceList.php?CustomerID=<?php echo $row1['CustomerID']; ?>" target="_blank">
    Detail</a> 
   &nbsp;
                                 <a href="ServiceUpdate.php?ServiceID=<?php echo $row1['ServiceID']; ?>" target="_blank">
   Update </a> 
   &nbsp;
    <a href="ServiceDelete.php?CustomerID=<?php echo $row1['CustomerID']; ?>" target="_blank">
    Delete</a></td>
             
             </tr>
              <?php } } ?> 
      </table></li>
		 </ul>
		 
		 
		 
    </div> <!-- END List Wrap -->
 
 </div> <!-- END Organic Tabs (Example One) -->
      
      
      
      
                    
</form>
            



    
    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>