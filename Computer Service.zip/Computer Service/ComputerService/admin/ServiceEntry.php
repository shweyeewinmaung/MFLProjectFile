<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_service.php");
require_once("../dal/dal_customer.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");


if (isset($_POST['submit']) )
{	

	$CustomerID=AutoID('tbl_customer','CustomerID','C-',6);
	$CustomerName=Clean($_POST['CustomerName']);
	$Phone=Clean($_POST['Phone']);
	$Email=Clean($_POST['Email']);
	$Address=Clean($_POST['Address']);
	
	
	InsertCustomer($CustomerID, $CustomerName, $Phone, $Email, $Address);
	
	
	$ServiceID=AutoID('tbl_service','ServiceID','Ser-',6);
	$CustomerID=$CustomerID;
	$ReceiveDate=date("Y/m/d");
	$ReceiveTime=GetCurrentTime();
	$DeliverDate="-";
	$DeliverTime="-";
	$ServiceType=Clean($_POST['ServiceType']);
	$Description=Clean($_POST['Description']);
	$RequireDate=Clean($_POST['RequireDate']);
	$Quantity=Clean($_POST['Quantity']);
	$Charges=Clean($_POST['Charges']);
	$Amount=Clean($_POST['Amount']);
	$Receiver=Clean($_POST['Receiver']);
	$TrackNo=Clean($_POST['TrackNo']);
	$Status=Clean($_POST['Status']);
	
	InsertService($ServiceID, $CustomerID, $ReceiveDate, $ReceiveTime, $DeliverDate,$DeliverTime, $ServiceType, 
	$Description, $RequireDate, $Quantity,$Charges, $Amount, $Receiver, $TrackNo, $Status);
	
	header("Location:servicelist.php?CustomerID=$CustomerID");
}
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    
   
</head>
<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post1">
<br>
<font style=" margin-left:400px; font-size:24px;">Service Entry</font><br><br>
<font style="color:#F90;margin-left:350px;"> <?php echo "<tr><th colspan='2'>$msg</th></tr>" ?></font>
<form  method="post"  >
<table width="330" style="float:left;">
<!--
<tr>
<td style="float:right; " height="40">CustomerID : </td>
<td>&nbsp;&nbsp;<input name="CustomerID" type="text"  size="30" style="height:27px;" value="<!--?php echo AutoID('tbl_customer','CustomerID','C-',6); ?>" /></td>
</tr>-->
	<tr>
		<td style="float:right;" height="40">CustomerName : </td>
		<td>&nbsp;&nbsp;<input name="CustomerName" type="text"  size="30" style="height:27px;"  /></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Phone : </td>
		<td>&nbsp;&nbsp;<input name="Phone" type="text"  size="30" style="height:27px;"  /></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Email : </td>
		<td>&nbsp;&nbsp;<input name="Email" type="text"  size="30" style="height:27px;"  /></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Address : </td>
		<td>&nbsp;  <textarea name="Address" cols="25" rows="3"style="background:#CCC;"></textarea></td>
	</tr>
</table>

<table width="430" style="float:right;">
<!--<tr>
<td style="float:right; " height="40">ServiceID : </td>
<td>&nbsp;&nbsp;<input name="ServiceID" type="text"  size="30" style="height:27px;" value="<!--?php echo AutoID('tbl_service','ServiceID','Ser-',6); ?>"  /></td>
</tr>
<tr>
<td style="float:right; " height="40">CustomerID : </td>
<td>&nbsp;&nbsp;<input name="CustomerID" type="text"  size="30" style="height:27px;"  /></td>
</tr>-->
	<tr>
		<td style="float:right;" height="40">ReceiveDate : </td>
		<td>&nbsp;&nbsp;<input name="ReceiveDate" type="text"  size="30" style="height:27px;"  maxlength="11" value="<?php echo date("d-M-Y")?>" onFocus="showCalender(calender,this)"/></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">ReceiveTime : </td>
		<td>&nbsp;&nbsp;<input name="ReceiveTime" type="text"  size="30" style="height:27px;" value="<?php echo GetCurrentTime();?>"  /></td>
	</tr>
<!--
<tr>
<td style="float:right;" height="40">DeliveryDate : </td>
<td>&nbsp;&nbsp;<input name="DeliveryDate" type="text"  size="30" style="height:27px;"  /></td>
</tr>
<tr>
<td style="float:right;" height="40">DeliveryTime : </td>
<td>&nbsp;&nbsp;<input name="DeliveryTime" type="text"  size="30" style="height:27px;"  /></td>
</tr>
-->
	<tr>
		<td style="float:right;" height="40">ServiceType : </td>
		<td>&nbsp; <select name="ServiceType"  style="background:#CCC; color:#000; width:207px; height:30px;">
	   					<option>Network </option>
       					<option>Software Installation </option>
       					<option>Hardware </option>
       					<option>Cleaning </option>
       					<option>Driver Installation </option>
        			</select></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Description : </td>
		<td height="95">&nbsp;
      		<textarea name="Description" cols="25" rows="3"style="background:#CCC;"></textarea></td>
	</tr>
	<tr>
<td style="float:right;" height="40">RequireDate : </td>
<td >&nbsp;&nbsp;<input name="RequireDate" type="text"  size="30" style="height:27px;"  /></td>
</tr>
<tr>
<td style="float:right;" height="40">Quantity : </td>
<td>&nbsp;&nbsp;<input name="Quantity" type="text"  size="30" style="height:27px;"  /></td>
</tr>
<tr>
<td style="float:right;" height="40">Charges : </td>
<td>&nbsp;&nbsp;<input name="Charges" type="text"  size="30" style="height:27px;"  /></td>
</tr>
<tr>
<td style="float:right;" height="40">Amount : </td>
<td>&nbsp;&nbsp;<input name="Amount" type="text"  size="30" style="height:27px;"  /></td>
</tr>
<tr>
<td style="float:right;" height="40">Receiver : </td>
<td>&nbsp;&nbsp;<input name="Receiver" type="text"  size="30" style="height:27px;"  /></td>
</tr>
<tr>
<td style="float:right;" height="40">TrackNo : </td>
<td>&nbsp;&nbsp;<input name="TrackNo" type="text"  size="30" style="height:27px;"  /></td>
</tr>
<tr>
<td style="float:right;" height="40">Status : </td>
<td>&nbsp; <select name="Status"  style="background:#CCC; color:#000; width:207px; height:30px;">
	   <option>Received </option>
       <option>Servicing </option>
       <option>Finished </option>
       <option>Delivered </option>
       <option>Cancelled</option>
        </select></td>
</tr>
<tr>
<td></td>
<td > <input name="submit" type="submit" id="submit"  value="Save" class="btnstyle">
      <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle"><br><br></td>
</tr>
</table>

  
</form>

    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>