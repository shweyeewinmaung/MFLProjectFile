<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../dal/dal_assign.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");

if (isset($_POST['btnUpdate']) && isset($_POST['AssignID']) )
{	
	//$UserID=AutoID('tbl_user','UserID','Usr-',6);
	$AssignID=Clean($_POST['AssignID']);
	$ServiceID=Clean($_POST['ServiceID']);
	$UserID=Clean($_POST['UserID']);
	$AssignDate=date("Y/m/d");
	$AssignTime=GetCurrentTime();
	$AssignUser=Clean($_POST['AssignUser']);
	
	
	
	UpdateAssign($AssignID,$ServiceID,$UserID,$AssignDate,$AssignTime,$AssignUser);
	$msg="Successfully Assign Updated";

}

if (isset($_GET['AssignID']) && $_GET['AssignID']!="")
{
	$AssignID=Clean($_GET['AssignID']);
	$ret=GetAssignDataByAssign($AssignID);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
}
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
</head>
<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post1" style="height:450px;"> 

<br><br>
<font style=" margin-left:300px; font-size:24px;">Assign Update</font><br><br>
<form  method="post"  style="font-family:Arial, Helvetica, sans-serif;" >
<table width="400" style="float:left; margin-left:150px;">
<tr><td colspan="2" height="20"><font style="color:#000;"><?php echo $msg;?></font></td></tr>
<tr>
		<td style="float:right; " height="40">AssignID : </td>
		<td>&nbsp;&nbsp;<input name="AssignID" type="text"  size="40" style="height:27px;"  value="<?php echo $row['AssignID']; ?>" readonly/></td>
	</tr>
    					<tr>
		<td style="float:right; " height="40">ServiceID : </td>
		<td>&nbsp;&nbsp;<input name="ServiceID" type="text"  size="40" style="height:27px;"  value="<?php echo $row['ServiceID']; ?>"  /></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">UserID : </td>
		<td>&nbsp;&nbsp;<input name="UserID" type="text"  size="40" style="height:27px;"  value="<?php echo $row['UserID']; ?>"  /></td>
	</tr>
	
	<tr>
		<td style="float:right;" height="40">AssignUser : </td>
		<td>&nbsp;
        <select name="AssignUser"  onChange="showCustomer(this.value)" style="background:#CCC; color:#000; width:270px; height:30px;"  >
	    							<option><?php echo GetUserNameByUserID($row[5]);?></option>
												<?php	$sql="select * from tbl_user";
											            $ret= mysql_query($sql);
             											while($rowsd=mysql_fetch_array($ret)){?>
          							<option value="<?php echo $rowsd['UserID'];?>" ><?php echo $rowsd['UserName'];?></option>
         								 <?php }?>
	   
		  							 </select>
                    
        </td>
	</tr>
  	 <tr>
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input name="btnUpdate" type="submit"  value="Update" class="btnstyle">
      <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle"><br><br>
     </td>
    </tr>
        
</table>
 
</form>




    
    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>