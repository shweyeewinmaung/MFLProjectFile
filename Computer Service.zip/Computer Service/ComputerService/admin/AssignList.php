<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_assign.php");
require_once("../dal/dal_service.php");
require_once("../dal/dal_user.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");



$ret=GetAssignDataByAssignID($AssignID);
$num=mysql_num_rows($ret);


?>
<!doctype html>
<html class="no-js" lang="en">
<head>
</head>
<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post1">
 <form method="post" ><br>
      <font style="color:#fff;  font-size:24px; margin-left:400px;">All Assign List</font><br><br>
 <table >
     		 <tr style="background:#CCC; color:#900; font-size:16px; height:30px; text-align:center; " >
             		<td width="12%" style="border:2px solid#fff;">AssignID</td>
                    <td width="12%" style="border:2px solid#fff;">ServiceID</td>
                    <td width="12%" style="border:2px solid#fff;">UserID</td>
                    <td width="12%" style="border:2px solid#fff;">AssignDate</td>
                    <td width="12%" style="border:2px solid#fff;">AssignTime</td>
                    <td width="12%" style="border:2px solid#fff;">AssignUser</td>
                    
                    <td width="15%" style="border:2px solid#fff;"></td>
                          
      		 </tr>
             <?php
           while($row=mysql_fetch_array($ret))
				
							{	
								?>
             <tr style="line-height:30px; font-size:12px; font-family:Arial, Helvetica, sans-serif; text-align:center;">
             		<td><?php echo  $row['AssignID'];?></td>
                    <td><?php echo  $row['ServiceID'];?></td>
                    <td><?php echo  $row['UserID'];?></td>
                    <td><?php echo  $row['AssignDate'];?></td>
                    <td><?php echo  $row['AssignTime'];?></td>
                    <td>
					<?php echo GetUserNameByUserID($row[5]); ?>
							</td>
                   
                    <td >
                    <a href="DetailAssign.php?AssignID=<?php echo $row['AssignID']; ?>" target="_blank">
    Detail</a> 
   &nbsp;
                                 <a href="AssignUpdate.php?AssignID=<?php echo $row['AssignID']; ?>" target="_blank">
   Update </a> 
   &nbsp; 
    <a href="AssignDelete.php?AssignID=<?php echo $row['AssignID']; ?>" target="_blank">
    Remove</a>
                    
                    
                   </td>
             <?php  }
			 
			 
			  ?>
             
             </tr>
      </table>


</form>
    
    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>