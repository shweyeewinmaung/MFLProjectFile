<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_service.php");
require_once("../dal/dal_customer.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");


if (isset($_GET['CustomerID']) && $_GET['CustomerID']!="")
{
	

	$CustomerID=Clean($_GET['CustomerID']);
	$ret=GetCustomerDataByCustomerID($CustomerID);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
	
	$ret1=GetServiceDataByCustomerID($CustomerID);
	$num1=mysql_num_rows($ret1);
	
	
}



?>
<!doctype html>
<html class="no-js" lang="en">
<head>
</head>
<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post1">


<form name="form1" method="post" ><br>
      <font style="color:#fff;  font-size:24px; margin-left:400px;">Service List</font>
          <div style="margin-left:60px; padding:10px; border:1px solid #333; border-radius:10px;margin-top: 20px; width:800px; float:left; font-family:Arial, Helvetica, sans-serif;font-size:14px;">
  					 <table>
                        <tr style="height:40px; color:#900; font-size:16px;">
                        	<td style="width:200px; background:#999; ">CustomerID</td>
                        	<td style="width:200px;background:#999;">CustomerName</td>
                        	<td style="width:200px;background:#999;">Phone</td>
                        	<td style="width:200px;background:#999;">Email</td>
                        	<td style="width:200px;background:#999;">Address</td>
                        </tr>
                        <tr style="height:35px; border-bottom:2px solid#333;">
                        	<td><?php echo $row['CustomerID']; ?></td>
                        	<td><?php echo $row['CustomerName']; ?></td>
                        	<td><?php echo $row['Phone']; ?></td>
                        	<td><?php echo $row['Email']; ?></td>
                        	<td><?php echo $row['Address']; ?></td>
                        </tr>
       				</table>
  					<table>
                   
                          <?php 
						  while($row1=mysql_fetch_array($ret1)or die(mysql_error())){
						  
						  ?>  	                        
                       	<tr>
                       
                            <td style="text-align:right; width:150px; height:25px;">ServiceID :</td>   
                            <td style="width:200px;" > &nbsp;&nbsp;<?php echo $row1['ServiceID']; ?></td>   
                            <td  style="text-align:right; width:150px;">DeliverDate :</td>   
                            <td style="width:200px;">&nbsp;&nbsp;<?php echo $row1['DeliverDate']; ?></td>   
                            <td style="text-align:right; width:150px;">RequireDate :</td>   
                            <td  style="width:200px;">&nbsp;&nbsp;<?php echo $row1['RequireDate']; ?></td>   
                        </tr>
                        <tr>
                             <td style="text-align:right; height:25px;">CustomerID :</td>   
                             <td >&nbsp;&nbsp;<?php echo $row['CustomerID']; ?></td>   
                             <td style="text-align:right;">DeliverTime :</td>   
                             <td >&nbsp;&nbsp;<?php echo $row1['DeliverTime']; ?></td>   
                             <td  style="text-align:right;">Quantity :</td>   
                             <td>&nbsp;&nbsp;<?php echo $row1['Quantity']; ?></td>   
                         </tr>
                         <tr>
                              <td style="text-align:right; height:25px;">ReceivedDate :</td>   
                              <td >&nbsp;&nbsp;<?php echo $row1['ReceiveDate']; ?></td>   
                              <td style="text-align:right;">ServiceType :</td>   
                              <td >&nbsp;&nbsp;<?php echo $row1['ServiceType']; ?></td>   
                              <td style="text-align:right;">Charges :</td>   
                              <td>&nbsp;&nbsp;<?php echo $row1['Charges']; ?></td>   
                          </tr>
                          <tr>
                              <td  style="text-align:right; height:25px;">ReceivedTime :</td>   
                              <td>&nbsp;&nbsp;<?php echo $row1['ReceiveTime']; ?></td>   
                              <td style="text-align:right;">Description :</td>   
                              <td >&nbsp;&nbsp;<?php echo $row1['Description']; ?></td>   
                              <td style="text-align:right;">Amount :</td>   
                              <td>&nbsp;&nbsp;<?php echo $row1['Amount']; ?></td> 
                           </tr>   
                            <tr >
                              <td  style="text-align:right; height:25px;">Receiver :</td>   
                              <td>&nbsp;&nbsp;<?php echo $row1['Receiver']; ?></td>   
                              <td style="text-align:right;">TrackNo :</td>   
                              <td >&nbsp;&nbsp;<?php echo $row1['TrackNo']; ?></td>   
                              <td style="text-align:right;">Status :</td>   
                              <td>&nbsp;&nbsp;<?php echo $row1['Status']; ?></td> 
                           </tr> 
                       
                               <tr style="border-bottom:2px solid#333;"> <td colspan="6" style="margin-right:20px; text-align:right;">
  
   &nbsp; &nbsp;
    <a href="ServiceDelete.php?CustomerID=<?php echo $row['CustomerID']; ?>">
    <img src="../images/cross-script.png" width="20" height="20" /></a></td>   
                                </tr>
                                 <?php }?>
                               <tr><td colspan="6" style="margin-right:20px; text-align:right;"><a href="AddService.php?CustomerID=<?php echo $row['CustomerID']; ?>" target="_blank">
    Add Service</a> </td></tr>
                            </table>
                            </div>
</form>


    
    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>