<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");

if (isset($_POST['btnDelete']) && isset($_POST['UserID']) )
{	
	//$UserID=AutoID('tbl_user','UserID','Usr-',6);
	$UserID=Clean($_POST['UserID']);
	$FullName=Clean($_POST['FullName']);
	$Gender=Clean($_POST['Gender']);
	$DOB=Clean($_POST['DOB']);
	$Phone=Clean($_POST['Phone']);
	$Email=Clean($_POST['Email']);
	$Address=Clean($_POST['Address']);
	$UserName=Clean($_POST['UserName']);
	$Password=Clean($_POST['Password']);
	$Role=Clean($_POST['Role']);
	$Status=Clean($_POST['Status']);
	
	
	
	DeleteUser($UserID,$FullName,$Gender,$DOB,$Phone,$Email,$Address,$UserName,$Password,$Role,$Status);
	$msg="Successfully User Deleted";
	print "<script language=\"JavaScript\">window.location.href=\"userlist.php\";</script>";

}

if (isset($_GET['UserID']) && $_GET['UserID']!="")
{
	$UserID=Clean($_GET['UserID']);
	$ret=GetUserDataByUserID($UserID);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
}
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
<link rel="stylesheet"  href="../css/date.css"/>
    
    <!-- Load jQuery JS -->
    <script src="../js/jquery-1.9.1.js"></script>
    <!-- Load jQuery UI Main JS  -->
    <script src="../js/jquery-ui.js"></script>
    <script type="text/javascript">
	 $(document).ready(
  
  /* This is the function that will get executed after the DOM is fully loaded */
  function () {
    $( "#datepicker" ).datepicker({
      changeMonth: true,//this option for allowing user to select month
      changeYear: true //this option for allowing user to select from year range
    });
  }

);
    
    </script>
    <style>
    .ui-widget-header { background:#5b050d;}
    </style>
</head>
<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post">


<form name="userform" method="post" action="" class="formstyle" >
  <font style="color:#930;"> <?php echo "<tr><th colspan='2'>$msg</th></tr>" ?></font>
  <table width="400" border="0">
  <tr>
      <td colspan="2"  height="40"></td>
    </tr>
    <tr>
      <td colspan="2"  height="40" style=" text-align:center; font-size:24px; text-shadow: 2px solid#333;">User Delete</td>
    </tr>
	 <tr>
      <td height="40" style="text-align:right;">UserID:</td>
      <td>&nbsp;&nbsp;
        <input name="UserID" type="text"  size="40" style="height:27px;"  value="<?php echo $row['UserID']; ?>"  /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Full Name:</td>
      <td>&nbsp;&nbsp;
        <input name="FullName" type="text"  size="40" style="height:27px;"  value="<?php echo $row['FullName']; ?>"  /></td>
    </tr>
    
       <tr>
      <td height="40" style="text-align:right;">Gender:</td>
      <td>&nbsp;&nbsp;
        <input type="radio" name="Gender" value="Male" checked="checked" style="width:20px; " <?php if($row['Gender']=="Male"){ echo "checked";} ?>><font style="color:#fff;">&nbsp;&nbsp;Male</font>
		&nbsp;&nbsp;<input type="radio" name="Gender" value="Female"  style="width:20px;font-size:14px;" <?php if($row['Gender']=="Female"){ echo "checked";} ?>><font style="color:#fff;">&nbsp;&nbsp;Female</font>
        </td>
        </tr>
         <tr>
      <td height="40" style="text-align:right;">DOB:</td>
      <td>&nbsp;&nbsp;
      
        <input name="DOB" type="text" size="40" id="datepicker" maxlength="11" style="height:27px;"  value="<?php echo $row['DOB']; ?>"  onFocus="showCalender(calender,this)"/>
       
       </td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Phone:</td>
      <td>&nbsp;&nbsp;
        <input name="Phone" type="text"  size="40" style="height:27px;" value="<?php echo $row['Phone']; ?>"   /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Email:</td>
      <td>&nbsp;&nbsp;
        <input name="Email" type="text"  size="40" style="height:27px;"  value="<?php echo $row['Email']; ?>"  /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Address:</td>
      <td  height="95">&nbsp;&nbsp;
      <textarea name="Address" cols="34" rows="3" style="background:#CCC;"><?php echo $row['Address']; ?> </textarea>
        </td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Username:</td>
      <td>&nbsp;&nbsp;
        <input name="UserName" type="text" size="40" style="height:27px;"  value="<?php echo $row['UserName']; ?>" /></td>
    </tr>
    
     
    <tr>
      <td height="40" style="text-align:right;">Role:</td>
      <td>&nbsp;&nbsp;
     <select name="Role"  style="background:#CCC; color:#000; width:270px; height:30px;">
	   <option ><?php echo $row['Role']; ?></option>
        </select></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Status:</td>
      <td>&nbsp;&nbsp;
        <input name="Status" type="text"  size="40" style="height:27px;" value="<?php echo $row['Status']; ?>"   /></td>
    </tr>
    
	
    
    
   
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input name="btnDelete" type="submit"  value="Delete" class="btnstyle">
      <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle"><br><br>
      <!--<input type="submit" name="submit" id="submit" value="" class="entry" onClick="return Validate()">
      <input type="reset" name="Reset" id="button" value="" class="reset">--></td>
    </tr>
  </table>
</form>


    
    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>