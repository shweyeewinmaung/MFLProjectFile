<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_service.php");
require_once("../dal/dal_customer.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");

if (isset($_POST['btnSearch']))
{
	

	$ReceiveDate=Clean($_POST['ReceiveDate']);
	$ret=GetServiceReport_ReceiveCountByReceiveDate($ReceiveDate);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
	
	
}



?>
<!doctype html>
<html class="no-js" lang="en">
<head>
</head>
<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post1">
<br>
<font style=" margin-left:400px; font-size:24px;">Daily Report</font><br><br>
<form  method="post">
<table style="margin-left:100px;">
	<tr>
		<td><font style="color:#999; font-weight:bold;">Search By Date :</font> </td>
		<td> &nbsp;&nbsp;<input name="ReceiveDate" type="text"  size="25" style="height:20px;"  /></td>
		<td>&nbsp;&nbsp;<font style="color:#999; font-weight:bold;">(dd/mm/yy)</font></td>
		<td>&nbsp;&nbsp;<input name="btnSearch" type="submit" value="Search" class="btnstyle"></td>

	</tr>
</table><br><br>
<table width="300">
	<tr>
		<td style="float:right; " height="40" >Date : </td>
		<td>&nbsp;&nbsp;<?php echo $row['ReceiveDate'] ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Received Service : </td>
		<td>&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Finished Service : </td>
		<td>&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Ongoing Service : </td>
		<td>&nbsp;&nbsp;</td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Total Amount : </td>
		<td>&nbsp;&nbsp;</td>
	</tr>

</table>
<br><br>
<table>
	<tr style="background:#CCC; color:#900; font-size:16px; height:30px; text-align:center; " >
        <td width="12%" style="border:2px solid#fff;">ServiceID</td>
        <td width="12%" style="border:2px solid#fff;">CustomerName</td>
        <td width="12%" style="border:2px solid#fff;">ReceiveDate</td>
        <td width="12%" style="border:2px solid#fff;">Receiver</td>
        <td width="12%" style="border:2px solid#fff;">ServiceType</td>
        <td width="12%" style="border:2px solid#fff;">TrackNo</td>
        <td width="12%" style="border:2px solid#fff;">Amount</td>
        <td width="12%" style="border:2px solid#fff;">Status</td>
                          
    </tr>
    <tr style="line-height:30px; font-size:12px; font-family:Arial, Helvetica, sans-serif; text-align:center; ">
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
</table>

</form>



    
    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>