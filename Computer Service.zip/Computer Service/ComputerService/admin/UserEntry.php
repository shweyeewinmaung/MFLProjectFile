<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");


if (isset($_POST['submit']) )
{	
	$UserID=AutoID('tbl_user','UserID','Usr-',6);
	$FullName=Clean($_POST['FullName']);
	$Gender=Clean($_POST['Gender']);
	$DOB=Clean($_POST['DOB']);
	$Phone=Clean($_POST['Phone']);
	$Email=Clean($_POST['Email']);
	$Address=Clean($_POST['Address']);
	$UserName=Clean($_POST['UserName']);
	$Password=Clean($_POST['Password']);
	$Role=Clean($_POST['Role']);
	$Status=Clean($_POST['Status']);
	
	
	
	InsertUser($UserID, $FullName, $Gender, $DOB, $Phone, $Email, $Address, $UserName,$Password,$Role,$Status);
	$msg="Successfully User Save";
}
?>
<!doctype html>
<html class="no-js" lang="en">
<head>

<link rel="stylesheet"  href="../css/date.css"/>
    
    <!-- Load jQuery JS -->
    <script src="../js/jquery-1.9.1.js"></script>
    <!-- Load jQuery UI Main JS  -->
    <script src="../js/jquery-ui.js"></script>
    <script type="text/javascript">
	 $(document).ready(
  
  /* This is the function that will get executed after the DOM is fully loaded */
  function () {
    $( "#datepicker" ).datepicker({
      changeMonth: true,//this option for allowing user to select month
      changeYear: true //this option for allowing user to select from year range
    });
  }

);
    
    </script>
    <style>
    .ui-widget-header { background:#5b050d;}
    </style>
</head>
 

<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post">
 <form  method="post" action="" class="formstyle" >
  <font style="color:#F90;"> <?php echo "<tr><th colspan='2'>$msg</th></tr>" ?></font>
  <table width="400" border="0">
  <tr>
      <td colspan="2"  height="40"></td>
    </tr>
    <tr>
      <td colspan="2"  height="40" style=" text-align:center; font-size:24px; text-shadow: 2px solid#333;">User Entry</td>
    </tr>
 <!-- <tr>
            	<td>User ID</td>
                <td><input type="text" name="UserID" value="<!--?php echo AutoID('tbl_user','UserID','Usr-',6); ?>" required /></td>
            </tr>-->
     <tr>
      <td height="40" style="text-align:right;">Full Name:</td>
      <td>&nbsp;&nbsp;
        <input name="FullName" type="text" id="txtfullname" size="40" style="height:27px;"  /></td>
    </tr>
    
       <tr>
      <td height="40" style="text-align:right;">Gender:</td>
      <td>&nbsp;&nbsp;
        <input type="radio" name="Gender" value="Male" checked="checked" style="width:20px; "><font style="color:#fff;">&nbsp;&nbsp;Male</font>
		&nbsp;&nbsp;<input type="radio" name="Gender" value="Female"  style="width:20px;font-size:14px;"><font style="color:#fff;">&nbsp;&nbsp;Female</font>
        </td>
        </tr>
         <tr>
      <td height="40" style="text-align:right;">DOB:</td>
      <td>&nbsp;&nbsp;
      
        <input name="DOB" type="text" size="40" id="datepicker" maxlength="11" style="height:27px;"  value="<?php echo date("d-M-Y")?>" onFocus="showCalender(calender,this)"/>
       
       </td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Phone:</td>
      <td>&nbsp;&nbsp;
        <input name="Phone" type="text" id="txtphone" size="40" style="height:27px;"  /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Email:</td>
      <td>&nbsp;&nbsp;
        <input name="Email" type="text" id="txtemail" size="40" style="height:27px;"  /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Address:</td>
      <td  height="95">&nbsp;&nbsp;
      <textarea name="Address" cols="34" rows="3" id="txtemail" style="background:#CCC;"></textarea>
        </td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Username:</td>
      <td>&nbsp;&nbsp;
        <input name="UserName" type="text" id="txtusername" size="40" style="height:27px;"  /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Password:</td>
      <td>&nbsp;&nbsp;
        <input name="Password" type="password" id="txtpassword" size="40" style="height:27px;"  /></td>
    </tr>
     
    <tr>
      <td height="40" style="text-align:right;">Role:</td>
      <td>&nbsp;&nbsp;
     <select name="Role"  style="background:#CCC; color:#000; width:270px; height:30px;">
	   <option>Admin </option>
        </select></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Status:</td>
      <td>&nbsp;&nbsp;
        <input name="Status" type="text" id="txtusertype" size="40" style="height:27px;"  /></td>
    </tr>
    
	
    
    
   
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input name="submit" type="submit" id="submit"  value="Save" class="btnstyle">
      <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle"><br><br>
      <!--<input type="submit" name="submit" id="submit" value="" class="entry" onClick="return Validate()">
      <input type="reset" name="Reset" id="button" value="" class="reset">--></td>
    </tr>
  </table>
</form>
    
    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>