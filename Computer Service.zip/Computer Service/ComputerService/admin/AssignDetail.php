<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../dal/dal_assign.php");
require_once("../dal/dal_service.php");
require_once("../dal/dal_customer.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");

if (isset($_GET['ServiceID']) && $_GET['ServiceID']!="")
{
	

	$ServiceID=Clean($_GET['ServiceID']);
	$ret=GetServiceDataByServiceID($ServiceID);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
	
}
if (isset($_POST['btnAssign']))
{	
	$AssignID=AutoID('tbl_assign','AssignID','A-',6);
	$ServiceID=Clean($_GET['ServiceID']);
	$UserID=AutoID('tbl_assign','UserID','UID-',6);
	$AssignDate=date("Y/m/d");
	$AssignTime=GetCurrentTime();
	$AssignUser=Clean($_POST['UserName']);
	
	
	
	
	InsertAssign($AssignID, $ServiceID, $UserID, $AssignDate, $AssignTime, $AssignUser);
	
}


?>
<!doctype html>
<html class="no-js" lang="en">
<head>
</head>
<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post1">



<br>
<font style=" margin-left:400px; font-size:24px;">Assign Detail</font><br><br>
<form  method="post">
	<table style="float:left; margin-left:550px; margin-bottom:20px;">
			<tr>
            		<td height="30">UserName : </td>
                    <td>&nbsp;&nbsp;<select name="UserName"  onChange="showCustomer(this.value)" style="background:#CCC; color:#000; width:150px; height:30px;"  >
	    							<?php echo GetUserNameByUserID($row[2]);?>
												<?php	$sql="select * from tbl_user";
											            $ret= mysql_query($sql);
             											while($rowsd=mysql_fetch_array($ret)){?>
          							<option value="<?php echo $rowsd['UserID'];?>" ><?php echo $rowsd['UserName'];?></option>
         								 <?php }?>
	   
		  							 </select>
                    
                    
                    
                    
                    
                   
	  </td>
                    <td>&nbsp;&nbsp;<input name="btnAssign" type="submit"  value="Assign" class="btnstyle"></td>
            </tr>

	</table>
</form><br><br>
<form  method="post"  style="font-family:Arial, Helvetica, sans-serif;" >
<table width="330" style="float:left; margin-left:100px;">

<tr>
		<td style="float:right; " height="40">ServiceID : </td>
		<td>&nbsp;&nbsp;<?php echo $row['ServiceID']; ?></td>
	</tr>
    				 <?php			
							
							$ret1=GetCustomerDataByCustomerID($row['CustomerID']);
							$row1=mysql_fetch_array($ret1);
						?>
	<tr>
		<td style="float:right; " height="40">CustomerID : </td>
		<td>&nbsp;&nbsp;<?php echo $row1['CustomerID']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">CustomerName : </td>
		<td>&nbsp;&nbsp;<?php echo $row1['CustomerName']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Phone : </td>
		<td>&nbsp;&nbsp;<?php echo $row1['Phone']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Email : </td>
		<td>&nbsp;&nbsp;<?php echo $row1['Email']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Address : </td>
		<td>&nbsp;&nbsp;<?php echo $row1['Address']; ?></td>
	</tr>
   
    <tr>
		<td style="float:right;" height="40">ServiceType : </td>
		<td>&nbsp;&nbsp;<?php echo $row['ServiceType']; ?></td>
	</tr>
    <tr>
		<td style="float:right;" height="40">DeliverDate : </td>
		<td>&nbsp;&nbsp;<?php echo $row['DeliverDate']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">DeliverTime : </td>
		<td>&nbsp;&nbsp;<?php echo $row['DeliverTime']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Description : </td>
		<td height="95">&nbsp;&nbsp;<?php echo $row['Description']; ?>
      		</td>
	</tr>
    
</table>

<table width="430" style="float:right; margin-right:100px;">

<tr>
		<td style="float:right;" height="40">ReceiveDate : </td>
		<td>&nbsp;&nbsp;<?php echo $row['ReceiveDate']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">ReceiveTime : </td>
		<td>&nbsp;&nbsp;<?php echo $row['ReceiveTime']; ?></td>
	</tr>
	
	<tr>
		<td style="float:right;" height="40">RequireDate : </td>
		<td >&nbsp;&nbsp;<?php echo $row['RequireDate']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Quantity : </td>
		<td>&nbsp;&nbsp;<?php echo $row['Quantity']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Charges : </td>
		<td>&nbsp;&nbsp;<?php echo $row['Charges']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Amount : </td>
		<td>&nbsp;&nbsp;<?php echo $row['Amount']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Receiver : </td>
		<td>&nbsp;&nbsp;<?php echo $row['Receiver']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">TrackNo : </td>
		<td>&nbsp;&nbsp;<?php echo $row['TrackNo']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">Status : </td>
		<td>&nbsp;&nbsp; <?php echo $row['Status']; ?></td>
	</tr>
	
</table>

  
</form>




    
    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>