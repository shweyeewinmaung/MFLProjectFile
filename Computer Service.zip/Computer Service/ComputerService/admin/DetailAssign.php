<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_assign.php");
require_once("../dal/dal_service.php");
require_once("../dal/dal_user.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");



if(isset($_GET['AssignID']) && $_GET['AssignID']!="")
{	
	$AssignID=Clean($_GET['AssignID']);
	$ret=GetAssignDataByAssign($AssignID);
	$num=mysql_num_rows($ret);
}



?>
<!doctype html>
<html class="no-js" lang="en">
<head>
</head>
<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post1" style="height:450px;">
<br><br>
<font style=" margin-left:300px; font-size:24px;">Assign Detail</font><br><br>
<form  method="post"  style="font-family:Arial, Helvetica, sans-serif;" >
<table width="330" style="float:left; margin-left:150px;">
<?php
			if($num>0)
			{
				$row=mysql_fetch_array($ret);
				?>
 
<tr>
		<td style="float:right; " height="40">AssignID : </td>
		<td>&nbsp;&nbsp;<?php echo $row['AssignID']; ?></td>
	</tr>
    					<tr>
		<td style="float:right; " height="40">ServiceID : </td>
		<td>&nbsp;&nbsp;<?php echo $row['ServiceID']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">UserID : </td>
		<td>&nbsp;&nbsp;<?php echo $row['UserID']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">AssignDate : </td>
		<td>&nbsp;&nbsp;<?php echo $row['AssignDate']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">AssignTime : </td>
		<td>&nbsp;&nbsp;<?php echo $row['AssignTime']; ?></td>
	</tr>
	<tr>
		<td style="float:right;" height="40">AssignUser : </td>
		<td>&nbsp;&nbsp;<?php echo GetUserNameByUserID($row[5]); ?></td>
	</tr>
  
        
</table>
 <?php
			}
			else
			{
				?>
                	<center><h1>No result found!</h1></center>
                <?php
			}
		?>
</form>



    
    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>