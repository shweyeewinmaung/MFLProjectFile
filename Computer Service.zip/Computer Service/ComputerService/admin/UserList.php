<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");



$ret=GetUserDataByUser($UserID);
$num=mysql_num_rows($ret);


?>
<!doctype html>
<html class="no-js" lang="en">
<head>

</head>
<body>
<?php require_once("../template/headermain.php"); ?>
<section role="banner">
<article role="main" class="clearfix">
<div class="post">

     <form name="form1" method="post" ><br>
      <font style="color:#fff;  font-size:24px; margin-left:400px;">User List</font>
            <?php
           while($row=mysql_fetch_array($ret))
				
							{	
								?>
                     <div style="margin-left:60px; padding:10px; border:1px solid #333; border-radius:10px;margin-top: 20px; width:800px; float:left;">
  <table>
                       
                                <tr>
                                <td style="text-align:right; width:150px; height:25px;">UserID :</td>   
                                <td style="width:200px;" > &nbsp;&nbsp;<?php echo $row['UserID']; ?></td>   
                                <td  style="text-align:right; width:150px;">Phone :</td>   
                                <td style="width:200px;">&nbsp;&nbsp;<?php echo $row['Phone']; ?></td>   
                                <td style="text-align:right; width:150px;">Email :</td>   
                                <td  style="width:200px;">&nbsp;&nbsp;<?php echo $row['Email']; ?></td>   
                                </tr>
                                
                                 <tr>
                                <td style="text-align:right; height:25px;">FullName :</td>   
                                <td >&nbsp;&nbsp;<?php echo $row['FullName']; ?></td>   
                                <td style="text-align:right;">UserName :</td>   
                                <td >&nbsp;&nbsp;<?php echo $row['UserName']; ?></td>   
                                <td  style="text-align:right;">Role :</td>   
                                <td>&nbsp;&nbsp;<?php echo $row['Role']; ?></td>   
                                </tr>
                                 <tr>
                                <td style="text-align:right; height:25px;">Gender :</td>   
                                <td >&nbsp;&nbsp;<?php echo $row['Gender']; ?></td>   
                                <td style="text-align:right;">Password :</td>   
                                <td >&nbsp;&nbsp;<?php echo $row['Password']; ?></td>   
                                <td style="text-align:right;">Status :</td>   
                                <td>&nbsp;&nbsp;<?php echo $row['Status']; ?></td>   
                                </tr>
                                 <tr>
                                <td  style="text-align:right; height:25px;">DOB :</td>   
                                <td>&nbsp;&nbsp;<?php echo $row['DOB']; ?></td>   
                                <td  style="text-align:right;">Address:</td> 
                                <td colspan="4">&nbsp;&nbsp;<?php echo $row['Address']; ?></td> 
                                </tr>   
                               <tr> <td colspan="6" style="margin-right:20px; text-align:right;"><a href="UserDetail.php?UserID=<?php echo $row['UserID']; ?>" target="_blank">
    Detail</a> 
   &nbsp; &nbsp;
                                 <a href="UserUpdate.php?UserID=<?php echo $row['UserID']; ?>">
    <img src="../images/wrench-screwdriver.png"  width="20" height="20"/></a> 
   &nbsp; &nbsp;
    <a href="UserDelete.php?UserID=<?php echo $row['UserID']; ?>">
    <img src="../images/cross-script.png" width="20" height="20" /></a></td>   
                                </tr>
                                
                               
                            </table>
                           
                            </div>
                             <?php } ?>
</form>
                  
    
   </div>
  </article>
</section>
<!-- // banner ends -->

<?php require_once('../template/footermain.php'); ?>


</body>
</html>