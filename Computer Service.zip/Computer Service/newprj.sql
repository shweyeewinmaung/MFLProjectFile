-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 30, 2015 at 07:47 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `newprj`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assign`
--

CREATE TABLE IF NOT EXISTS `tbl_assign` (
  `AssignID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ServiceID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `UserID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `AssignDate` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `AssignTime` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `AssignUser` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_assign`
--

INSERT INTO `tbl_assign` (`AssignID`, `ServiceID`, `UserID`, `AssignDate`, `AssignTime`, `AssignUser`) VALUES
('A-000003', 'Ser-000010', 'UID-000003', '2015/03/17', '12:34:08', 'Usr-000005'),
('A-000001', 'Ser-000002', 'UID-000001', '2015/03/17', '12:33:50', 'Usr-000004');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `CustomerID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CustomerName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CustomerID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`CustomerID`, `CustomerName`, `Phone`, `Email`, `Address`) VALUES
('C-000007', 'a', 'a', 'a', 'a'),
('C-000006', 'a', 'B', 'c', 'd'),
('C-000005', 'tt', 'tt', 'tt', 'tt'),
('C-000004', 'bb', 'bb', 'bb', 'bb'),
('C-000003', 'aa', 'aa', 'aa', 'aa'),
('C-000002', 'bb', 'aa', 'aa', 'aa'),
('C-000001', 'aa', 'aa', 'aa', 'aa');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_log`
--

CREATE TABLE IF NOT EXISTS `tbl_log` (
  `ID` int(11) NOT NULL,
  `LogID` int(11) NOT NULL,
  `LogType` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `UserID` int(11) NOT NULL,
  `LogDate` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LogTime` datetime NOT NULL,
  `Role` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_member`
--

CREATE TABLE IF NOT EXISTS `tbl_member` (
  `MemberID` varchar(20) NOT NULL,
  `FullName` varchar(100) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `DOB` date NOT NULL,
  `Photo` text NOT NULL,
  `PhoneNo` varchar(25) NOT NULL,
  `Email` varchar(135) NOT NULL,
  `Address` text NOT NULL,
  `RegisterationDate` date NOT NULL,
  `RegisterationTime` varchar(20) NOT NULL,
  PRIMARY KEY (`MemberID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_member`
--

INSERT INTO `tbl_member` (`MemberID`, `FullName`, `Gender`, `DOB`, `Photo`, `PhoneNo`, `Email`, `Address`, `RegisterationDate`, `RegisterationTime`) VALUES
('0153815001390635856', 'Arkar', 'Male', '1993-10-10', 'Photo/0153815001390635856.png', '199', 'arkar@gmail.com', 'YGN', '2014-01-25', '07:44:16');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_partnar`
--

CREATE TABLE IF NOT EXISTS `tbl_partnar` (
  `PartnarID` varchar(20) NOT NULL,
  `PartnarName` varchar(100) NOT NULL,
  `PartnarType` varchar(25) NOT NULL,
  `Website` varchar(100) NOT NULL,
  PRIMARY KEY (`PartnarID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_partnar`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_recommend`
--

CREATE TABLE IF NOT EXISTS `tbl_recommend` (
  `RecommendID` varchar(50) NOT NULL,
  `PartnarID` varchar(20) NOT NULL,
  `Description` text NOT NULL,
  `RecommendDate` date NOT NULL,
  `RecommendTime` varchar(20) NOT NULL,
  `RecommendStatus` varchar(25) NOT NULL,
  `AdminApproveal` varchar(25) NOT NULL,
  PRIMARY KEY (`RecommendID`,`PartnarID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_recommend`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_reply`
--

CREATE TABLE IF NOT EXISTS `tbl_reply` (
  `ReplyID` varchar(50) NOT NULL,
  `TopicID` varchar(50) NOT NULL,
  `ReplyDetail` text NOT NULL,
  `ReplyDate` date NOT NULL,
  `ReplyTime` varchar(20) NOT NULL,
  `UserID` varchar(20) NOT NULL,
  `ReplyStatus` varchar(25) NOT NULL,
  PRIMARY KEY (`ReplyID`,`TopicID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_reply`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_service`
--

CREATE TABLE IF NOT EXISTS `tbl_service` (
  `ServiceID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CustomerID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ReceiveDate` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ReceiveTime` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DeliverDate` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DeliverTime` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ServiceType` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `RequireDate` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Quantity` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Charges` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Amount` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Receiver` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TrackNo` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_service`
--

INSERT INTO `tbl_service` (`ServiceID`, `CustomerID`, `ReceiveDate`, `ReceiveTime`, `DeliverDate`, `DeliverTime`, `ServiceType`, `Description`, `RequireDate`, `Quantity`, `Charges`, `Amount`, `Receiver`, `TrackNo`, `Status`) VALUES
('Ser-000014', 'C-000007', '2015/03/17', '02:30:08', '-', '-', 'Network', 'kkkkkkk', 'kkkkkkk', 'kkkkkkkkk', 'kkkkkkk', 'kk', 'kkkkkkkkkkk', 'kkkkkkkkk', 'Received'),
('Ser-000013', 'C-000001', '2015/03/17', '02:29:07', '-', '-', 'Network', 'hhhh', 'hhhhhhh', 'hhhhhhhhhh', 'hhhhhhhhhh', 'hhhhhhhhhhh', 'hhhhhhhhhh', 'hhhhhhhhhhhh', 'Cancelled'),
('Ser-000008', 'C-000001', '2015/03/13', '09:50:56', '-', '-', 'Network', 'jj', 'jj', 'jj', 'jj', 'jj', 'jj', 'jj', 'Finished'),
('Ser-000006', 'C-000006', '2015/03/17', '02:19:17', '-', '-', 'Network', '1', '11', '1', '1', '1', '1', '1', 'Finished'),
('Ser-000010', 'C-000001', '2015/03/13', '09:52:05', '-', '-', 'Network', 'yy', 'yy', 'yy', 'yy', 'yy', 'yy', 'yy', 'Delivered'),
('Ser-000011', 'C-000001', '2015/03/13', '09:52:32', '-', '-', 'Network', 'aa', 'aa', 'aa', 'aa', 'aa', 'aa', 'aa', 'Received'),
('Ser-000012', 'C-000001', '2015/03/13', '09:53:45', '-', '-', 'Network', 'aa', 'aa', 'aa', 'aa', 'aa', 'aa', 'aa', 'Received');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_thread`
--

CREATE TABLE IF NOT EXISTS `tbl_thread` (
  `ThreadID` varchar(50) NOT NULL,
  `ThreadName` varchar(255) NOT NULL,
  `ThreadType` varchar(50) NOT NULL,
  `ThreadDate` date NOT NULL,
  `ThreadTime` varchar(20) NOT NULL,
  `UserID` varchar(20) NOT NULL,
  `ThreadStatus` varchar(25) NOT NULL,
  PRIMARY KEY (`ThreadID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_thread`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_topic`
--

CREATE TABLE IF NOT EXISTS `tbl_topic` (
  `TopicID` varchar(50) NOT NULL,
  `ThreadID` varchar(50) NOT NULL,
  `TopicTitle` varchar(255) NOT NULL,
  `TopicDetail` text NOT NULL,
  `TopicDate` date NOT NULL,
  `TopicTime` varchar(20) NOT NULL,
  `UserID` varchar(20) NOT NULL,
  `TopicStatus` varchar(25) NOT NULL,
  PRIMARY KEY (`TopicID`,`ThreadID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_topic`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `UserID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FullName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Gender` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DOB` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `UserName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Role` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`UserID`, `FullName`, `Gender`, `DOB`, `Phone`, `Email`, `Address`, `UserName`, `Password`, `Role`, `Status`) VALUES
('Usr-000004', 'bb', 'Female', '11-Mar-2015', 'bb', 'bb', 'bb', 'bb', '21ad0bd836b90d08f4cf640b4c298e7c', 'Admin', 'bb'),
('Usr-000003', 'aa', 'Male', '11-Mar-2015', 'aa', 'aa', 'aa', 'aa', '4124bc0a9335c27f086f24ba207a4912', 'aa', 'aa'),
('Usr-000002', 'aa', 'Male', '11-Mar-2015', 'aa', 'aa', 'aa', 'aa', '4124bc0a9335c27f086f24ba207a4912', 'aa', 'aa'),
('Usr-000005', 'nn', 'Male', '11-Mar-2015', 'nn', 'nn', 'nn', 'nn', 'eab71244afb687f16d8c4f5ee9d6ef0e', 'Admin', 'nn'),
('Usr-000006', 'nn', 'Male', '11-Mar-2015', 'nn', 'nn', 'nn', 'nn', 'eab71244afb687f16d8c4f5ee9d6ef0e', 'Admin', 'nn');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
