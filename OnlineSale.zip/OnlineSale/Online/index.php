<html>
<head>
<link href="css/style.css" type="text/css" media="all" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <div id="logobox">
            
        </div>
        <div id="header">
            <h1 style="color:black; font-size:31px; font-weight:bold; padding:70px 0 0 240px;">
                Save us to 50% on your deliverey
            </h1></br>
            <div style="width:60%; height:50px; background-color:#b8baf0; margin:0 auto; padding-top:8px;">
                <center>
                    <input type="text" value="weight...10kg" style="color:#CCC; font-size:21px;" />
                    <select style="color:#CCC; font-size:21px; width:200px;">
                        <option>Select Township</option>
                        <option></option>
                        <option></option>
                        <option></option>
                    </select>
                    <input type="submit" value="Get Quote" style="color:white; font-size:21px; background-color:#123abe" />
                </center>
            </div>
        </div>
        <div id="body">
            <div style="color:#ef4234; font-size:31px; font-weight:bold; padding:20px 0 0 140px; margin:0;">Track a shipment</div>
                </br>
            <div style="width:25%; float:left;">
                <img src="#" style="width:160px; height:200px; margin:0 0 0 140px;">
            </div>
            <div style="width:55%; float:left; margin:110px 0 0 0;">
                <div style="color:black; font-size:14px; font-weight:bold;  margin:0; float:left;">Enter your track code here</div>
                <div style="float:left;">
                    <input type="text" placerholder="Eg. 12391afx89" style="color:#CCC; font-size:21px; width:500px; margin-right:3%;"/>
                    <input type="submit" value="Track" style="color:white; font-size:21px; background-color:#0d82be; width:130px;" />
                </div>
                
            </div>
        </div>
        <div id="pic">
            <img src="photo/Koala.jpg" style="width:45%; height:330px; margin:10px 0 0 40px;"/>
            <img src="photo/Penguins.jpg" style="width:45%; height:330px;  margin:10px 0 0 20px;">
        </div>
    </div>
</body>
</html>