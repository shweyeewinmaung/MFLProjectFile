-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2015 at 05:30 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bfd`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `AdminID` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(255) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Email` varchar(135) NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `Address` text NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(135) NOT NULL,
  `Role` varchar(20) NOT NULL,
  PRIMARY KEY (`AdminID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`AdminID`, `FullName`, `Gender`, `Email`, `Phone`, `Address`, `UserName`, `Password`, `Role`) VALUES
(1, 'Moe Nge', 'Male', 'moenge@gmail.com', '199', 'YGN', 'moenge', 'moenge', 'Owner'),
(2, 'pi pi lay', 'Female', 'pipi@gmail.com', '111', 'afdj', 'pipi', '16d5d24f5b09a1991bd4e5f57bf11237', 'Delivery');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `CustomerID` varchar(20) NOT NULL DEFAULT '0',
  `AdminID` varchar(20) NOT NULL,
  `EntryDate` date NOT NULL,
  `CustomerName` varchar(255) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Phone` varchar(100) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Address` text NOT NULL,
  `Status` varchar(50) NOT NULL,
  PRIMARY KEY (`CustomerID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`CustomerID`, `AdminID`, `EntryDate`, `CustomerName`, `Gender`, `Phone`, `Email`, `Address`, `Status`) VALUES
('C-0000003', '', '0000-00-00', 'Phyo', 'Male', 'yyy', 'jsjfj', 'YGN', 'From'),
('C-0000004', '', '0000-00-00', 'Pyae', 'Male', '111', 'ppp', 'MDY', 'To'),
('C-0000001', '', '0000-00-00', 'PPK', 'Male', '111', 'ppk@gmail.com', 'YGN', 'From'),
('C-0000002', '', '0000-00-00', 'MN', 'Male', '222', 'mn@gmail.com', 'MDY', 'To');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_item`
--

CREATE TABLE IF NOT EXISTS `tbl_item` (
  `ItemNo` int(11) NOT NULL AUTO_INCREMENT,
  `FCustomer` varchar(20) NOT NULL,
  `TCustomer` varchar(20) NOT NULL,
  `AdminID` varchar(20) NOT NULL,
  `ItemCode` varchar(100) NOT NULL,
  `ItemName` varchar(255) NOT NULL,
  `ItemDetail` text NOT NULL,
  `TrackNo` varchar(50) NOT NULL,
  `DeliveryStaff` varchar(255) NOT NULL,
  `Process` varchar(50) NOT NULL,
  PRIMARY KEY (`ItemNo`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_item`
--

INSERT INTO `tbl_item` (`ItemNo`, `FCustomer`, `TCustomer`, `AdminID`, `ItemCode`, `ItemName`, `ItemDetail`, `TrackNo`, `DeliveryStaff`, `Process`) VALUES
(5, 'C-0000001', 'C-0000002', '1', 'Itm-1212', 'test', 'special', '1423123238-277421132', '2', 'Delivered'),
(6, 'C-0000003', 'C-0000004', '1', 'Itm-111', 'book', 'special', '1423138625-1026624490', '3', 'Received');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
