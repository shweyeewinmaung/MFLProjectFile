<?php
if($_SESSION['SESS']['User']['Role']!="Admin")
{
	header("Location:../LogIn.php");
}
?>