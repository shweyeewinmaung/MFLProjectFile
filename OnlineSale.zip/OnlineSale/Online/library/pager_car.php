<?php
class pager
{
	public $pageSize,$currentPageIndex;
	public $offset,$maxPage;
	public $totalRecordCount;
	
	//Constructor
	function __construct($pageSize,$currentPageIndex)
	{
		//Page Size
		$this->pageSize=$pageSize;
		//by default we show first page
		$this->currentPageIndex=$currentPageIndex;		
		//counting the offset
		$this->offset=($currentPageIndex-1)*$pageSize;
	}	

	/////////////////////////// One ///////////////////////////

	function SearchData_Brand($Brand)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_CarName($CarName)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_CarType($CarType)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarType LIKE '%$CarType%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_EnginePower($EnginePower)
	{
		$sql="SELECT * FROM `tbl_car` WHERE EnginePower LIKE '%$EnginePower%' ORDER BY Model";
		return $sql;
	}

	function SearchData_Model($Model)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Model LIKE '%$Model%' ORDER BY Model";
		return $sql;
	}

	function SearchData_Price($Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Price >= $Price ORDER BY Price";
		return $sql;
	}
	
	/////////////////////////// One ///////////////////////////

	
	
	/////////////////////////// Two ///////////////////////////

	function SearchData_BrandAndCarName($Brand, $CarName)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND CarName LIKE '%$CarName%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_BrandAndCarType($Brand, $CarType)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND CarType LIKE '%$CarType%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_BrandAndEnginePower($Brand, $EnginePower)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND EnginePower LIKE '%$EnginePower%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_BrandAndModel($Brand, $Model)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND Model LIKE '%$Model%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_BrandAndPrice($Brand, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}
	

	
	function SearchData_CarNameAndCarType($CarName, $CarType)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_CarNameAndEnginePower($CarName, $EnginePower)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' AND EnginePower LIKE '%$EnginePower%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_CarNameAndModel($CarName, $Model)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' AND Model LIKE '%$Model%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_CarNameAndPrice($CarName, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}
	
	
	
	function SearchData_CarTypeAndEnginePower($CarType, $EnginePower)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarType LIKE '%$CarType%' AND EnginePower LIKE '%$EnginePower%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_CarTypeAndModel($CarType, $Model)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarType LIKE '%$CarType%' AND Model LIKE '%$Model%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_CarTypeAndPrice($CarType, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarType LIKE '%$CarType%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}
	
	
	
	function SearchData_EnginePowerAndModel($EnginePower, $Model)
	{
		$sql="SELECT * FROM `tbl_car` WHERE EnginePower LIKE '%$EnginePower%' AND Model LIKE '%$Model%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_EnginePowerAndPrice($EnginePower, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE EnginePower LIKE '%$EnginePower%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}
	
	
	
	
	function SearchData_ModelAndPrice($Model, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Model LIKE '%$Model%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}

	/////////////////////////// Two ///////////////////////////

	

	/////////////////////////// Three ///////////////////////////

	function SearchData_BrandAndCarNameAndCarType($Brand, $CarName, $CarType)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_BrandAndCarNameAndEnginePower($Brand, $CarName, $EnginePower)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND CarName LIKE '%$CarName%' AND EnginePower LIKE '%$EnginePower%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_BrandAndCarNameAndModel($Brand, $CarName, $Model)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND CarName LIKE '%$CarName%' AND Model LIKE '%$Model%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_BrandAndCarNameAndPrice($Brand, $CarName, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND CarName LIKE '%$CarName%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}

	
	
	
	function SearchData_CarNameAndCarTypeAndEnginePower($CarName, $CarType, $EnginePower)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' AND EnginePower LIKE '%$EnginePower%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_CarNameAndCarTypeAndModel($CarName, $CarType, $Model)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' AND Model LIKE '%$Model%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_CarNameAndCarTypeAndPrice($CarName, $CarType, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}
	
	
	
	
	function SearchData_CarNameAndEnginePowerAndModel($CarName, $EnginePower, $Model)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' And EnginePower LIKE '%$EnginePower%' AND Model LIKE '%$Model%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_CarNameAndEnginePowerAndPrice($CarName, $EnginePower, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' And EnginePower LIKE '%$EnginePower%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}
	
	
	
	
	function SearchData_CarNameAndModelAndPrice($CarName, $Model, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' And Model LIKE '%$Model%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}
	
	
	/////////////////////////// Three ///////////////////////////

	
	/////////////////////////// Four ///////////////////////////
	
	function SearchData_BrandAndCarNameAndCarTypeAndEnginePower($Brand, $CarName, $CarType, $EnginePower)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' AND EnginePower LIKE '%$EnginePower%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_BrandAndCarNameAndCarTypeAndModel($Brand, $CarName, $CarType, $Model)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' AND Model LIKE '%$Model%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_BrandAndCarNameAndCarTypeAndPrice($Brand, $CarName, $CarType, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}
	
	
	
	
	function SearchData_CarNameAndCarTypeAndEnginePowerAndModel($CarName, $CarType, $EnginePower, $Model)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' AND EnginePower LIKE '%$EnginePower%' AND Model LIKE '%$Model%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_CarNameAndCarTypeAndEnginePowerAndPrice($CarName, $CarType, $EnginePower, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' AND EnginePower LIKE '%$EnginePower%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}
	
	
	
	
	function SearchData_CarTypeAndEnginePowerAndModelAndPrice($CarType, $EnginePower, $Model, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' AND EnginePower LIKE '%$EnginePower%' AND Model LIKE '%$Model%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}

	/////////////////////////// Four ///////////////////////////
	
	
	
	/////////////////////////// Five ///////////////////////////
	
	function SearchData_BrandAndCarNameAndCarTypeAndEnginePowerAndModel($Brand, $CarName, $CarType, $EnginePower, $Model)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' AND EnginePower LIKE '%$EnginePower%' AND Model LIKE '%$Model%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_BrandAndCarNameAndCarTypeAndEnginePowerAndPrice($Brand, $CarName, $CarType, $EnginePower, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' AND EnginePower LIKE '%$EnginePower%' AND Price >= $Price ORDER BY Price";
		return $sql;
	}
	
	/////////////////////////// Five ///////////////////////////
	
	
	
	/////////////////////////// Six ///////////////////////////
	
	function SearchData_BrandAndCarNameAndCarTypeAndEnginePowerAndModelAndPrice($Brand, $CarName, $CarType, $EnginePower, $Model, $Price)
	{
		$sql="SELECT * FROM `tbl_car` WHERE Brand LIKE '%$Brand%' AND CarName LIKE '%$CarName%' AND CarType LIKE '%$CarType%' AND EnginePower LIKE '%$EnginePower%' AND Model LIKE '%$Model%' AND Price >= $Price ORDER BY Price ORDER BY Price";
		return $sql;
	}
	
	/////////////////////////// Six ///////////////////////////
	
	
	/////////////////////////// All Car ///////////////////////////
	
	function SearchData_GetAllCar()
	{
		$sql="SELECT * FROM `tbl_car` ORDER BY CarID DESC ";
		return $sql;
	}
	
	/////////////////////////// All Car ///////////////////////////
	
	
	/////////////////////////// Test Search ///////////////////////////
	
	function SearchData_CarSearch($Brand, $CarName, $CarType, $Model, $Price)
	{
		$B="";
		$CN="";
		$CT="";
		$M="";
		$P="";
		$OrderBy=" ORDER BY Model";
		
		if($Brand!="")
		{
			$B="Brand LIKE '%$Brand%' ";
		}
		
		if($CarName!="")
		{
			if($B!="")
			{
				$CN="AND CarName LIKE '%$CarName%' ";
			}
			elseif($B=="")
			{
				$CN="CarName LIKE '%$CarName%' ";
			}
		}
		
		if($CarType!="")
		{
			if($B!="" || $CN!="")
			{
				$CT="AND CarType LIKE '%$CarType%' ";
			}
			elseif($B=="" && $CN=="")
			{
				$CT="CarType LIKE '%$CarType%' ";
			}
		}
		
		if($Model!="")
		{
			if($B!="" || $CN!="" || $CT!="")
			{
				$CT="AND Model LIKE '%$Model%' ";
			}
			elseif($B=="" && $CN=="" && $CT=="")
			{
				$CT="Model LIKE '%$Model%' ";
			}
		}
		
		if($Price!="")
		{		
			$OrderBy="ORDER BY Price";
			if($Price=="0 to 50L")
			{
				$P="Price BETWEEN '0' AND '5000000' $OrderBy";
			}
			if($Price=="50L to 75L")
			{
				$P="Price BETWEEN 5000000 AND 7500000 $OrderBy";
			}
			if($Price=="75L to 100L")
			{
				$P="Price BETWEEN 7500000 AND 10000000 $OrderBy";
			}
			if($Price=="100L to 150L")
			{
				$P="Price BETWEEN 10000000 AND 15000000 $OrderBy";
			}
			if($Price=="150L to 200L")
			{
				$P="Price BETWEEN 15000000 AND 20000000 $OrderBy";
			}
			if($Price=="200L to 300L")
			{
				$P="Price BETWEEN 20000000 AND 30000000 $OrderBy";
			}
			if($Price=="300L to 400L")
			{
				$P="Price BETWEEN 30000000 AND 40000000 $OrderBy";
			}
			if($Price=="400L to 500L")
			{
				$P="Price BETWEEN 40000000 AND 50000000 $OrderBy";
			}
			if($Price=="500L to 600L")
			{
				$P="Price BETWEEN 50000000 AND 60000000 $OrderBy";
			}
			if($Price=="Over 600L")
			{
				$P="Price>=60000000 $OrderBy";
			}
			
			
			if($B!="" || $CN!="" || $CT!="" || $M!="")
			{
				$P="AND " . $P;
			}
		}
		
		$sql="SELECT * FROM `tbl_car` WHERE $B $CN $CT $M $P ";
		return $sql;
	}
	
	/////////////////////////// All Car ///////////////////////////


	//function Search_Data($tableName,$orderByFieldName)

	function Search_Data($str)
	{
		$sql= $str . " LIMIT $this->offset,$this->pageSize";
		$this->totalRecordCount=$this->Search_TotalRecordCount($str);
		//how many pages
		$this->maxPage=ceil($this->totalRecordCount/$this->pageSize);	
		$result=mysql_query($sql) or die(mysql_error());
		return $result;
	}

	/********************************************************************/	

	function Search_TotalRecordCount($sql)
	{
		//If no search key is defined
		$ret=mysql_query($sql);
		$num=mysql_num_rows($ret);
		return $num;					
	}

	/********************************************************************/

	function Generate_Pager($str)
	{
		/********************************************************************/
		// creating previous and next link
		// plus the link to go straight to
		// the first and last page
		/********************************************************************/				
		
		//the name of the current page	
		$self = $_SERVER['PHP_SELF'];
		/********************************************************************/
		// "Previous" and "First" page link

		if ($this->currentPageIndex>1)
		{
			$pageIndex=$this->currentPageIndex-1;					
			echo "<a href='$self?page=1&$str'>[First]</a>&nbsp;";
			echo "<a href='$self?page=$pageIndex&$str'>[Prev]</a>&nbsp;";							
		}

		else

		{}								

		/********************************************************************/
		// print the link to access each page

		$b=false;

		for($i=1;$i<=$this->maxPage;$i++)
		{
			if ($i==$this->currentPageIndex)
			{
				echo $i . "&nbsp;";
			}

			else
			{
				
			}
		}

		/********************************************************************/

		// "Next" and "Last" page link
		if ($this->currentPageIndex<$this->maxPage)
		{
			$pageIndex=$this->currentPageIndex+1;
			echo "<a href='$self?page=$pageIndex&$str'>[Next]</a>&nbsp;";
			echo "<a href='$self?page=$this->maxPage&$str'>[Last]</a>&nbsp;";
			echo " of total " . $this->maxPage;
		}

		else

		{}

		/********************************************************************/

	}
	/********************************************************************/

}	

?>