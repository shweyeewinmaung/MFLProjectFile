<?php
function Clean($String)
{
	$Str = stripslashes($String);
	return mysql_real_escape_string($String);
}

function GetRandomWord()
{
    $word = array_merge(range('a', 'z'), range('A', 'Z'), range('0', '9'));
    shuffle($word);
    return substr(implode($word), 0, 9);
}

function GetCurrentDate()
{
	date_default_timezone_set("Asia/Rangoon");
	return date("Y-M-d");
}

function GetCurrentTime()
{
	date_default_timezone_set("Asia/Rangoon");
	return date('h:i:s');
}
?>