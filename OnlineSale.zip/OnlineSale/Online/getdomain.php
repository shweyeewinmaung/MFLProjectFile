<?php

function get_domain($url)
{
  $pieces = parse_url($url);
  $domain = isset($pieces['host']) ? $pieces['host'] : '';
  if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
    return $regs['domain'];
  }
  return false;
}

print get_domain("http://mail.somedomain.co.uk") . "<br><br>"; // outputs 'somedomain.co.uk'
print get_domain("http://www.mfl-itsolution.com/product/Product.php") . "<br><br>"; // outputs 'somedomain.co.uk'

?>