<html>
	<head>
		<link href="css/style.css" type="text/css" media="all" rel="stylesheet" />
	</head>
	<body>
		<div id="wrapper">
			<div id="logobox">
				
			</div>
			<div id="bodythree">
				<div id="left">
					<div id="leftone">
						<h1 style="width:100%; margin:0; padding:5px 0 5px 0; font-size:14px; color:#666; background-color:#f3f3f3; border:1px solid #CCC;">&nbsp;&nbsp;&nbsp;&nbsp;Shipment Infromation</h1>
						<div id="deliverinfo">
							</br>
							<p1 style="width:100%; margin:0px; padding:0 0 0 22px; font-size:11px; font-weight:bold;">Deliver to:</p1></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px">Minn Minn</p1>
							</br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px">999A Aung Ta Mar Di Road, Kyauk Kone</p1></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px">097007007</p1></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px">Yangon 097007007</p1></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px">YGN</p1></br></br>
						</div>
					</div>
					<div id="lefttwo">
						<div id="deliverinfo2">
							</br>
							<p1 style="width:100%; margin:0px; padding:0 0 0 22px; font-size:11px; font-weight:bold;">Carrier:</p1></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px">i-parcel</p1></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px; font-weight:bold;">Tracking #;</p1></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px">AEIPHX</p1></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px">6002564568</p1></br>
							</br>
						</div>
					</div>
					<div id="leftthree">
						<div id="deliverinfo3">
							</br>
							<p1 style="width:100%; margin:0px; padding:0 0 0 22px; font-size:11px; font-weight:bold;">Order #;</p1></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px">105-0088314-5415422</p1></br></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px; font-weight:bold;">Package Contain:</p1></br>
							</br>
						</div>
					</div>
					<div id="leftfour">
						<div id="deliverinfo4">
							</br>
							<img src="#" style="width:80px; height:60px; padding:0 0 0 22px; "></br>
							<p1 style="width:100%; margin:0px; padding:0 0 0 22px; font-size:11px;">"M-Audio Axiom AIR"</p1></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px">Mini 32 Ultra-Portable</p1></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px;">32-Key USB MIDI</p1></br>
							<p1 style="margin:0px; padding:0 0 0 22px; font-size:11px;">KeyBoard Controller</p1></br>
							</br>
						</div>
					</div>
				</div>
				<div id="right">
					<div id="deliverydetail">
						<table style="width:90%; margin:0 0 0 20px; border-top:1px solid #CCC; border-bottom:1px solid #CCC;">
							<tr>
								<td align="left" style="width:300px; border-right:1px solid #CCC; padding:10px;">
									<h1 style="font-size:15px;">Delivered</h1>
									<p1 style="font-size:11px;">Delivered on:</p1> <p1 style="color:green; font-size:11px;"">Tuesday, July 9, 2013</p1></br>
									<p1 style="font-size:11px;">Thanks for shopping at amazon</p1>
								</td>
								<td>
									<p1 style="font-size:11px; margin:10px;">Your Package was delivered</p1>
								</td>
							</tr>
						</table>
					</div>
					<div id="graph">
						
					</div>
					<div id="selectdetail">
						<h1 style="color:red; font-size:15px; margin:4px 0 0 20px;">Tracking Details:</h1>
						<table style="margin:4px 0 0 20px; font-size:8px;">
							<tr>
								<td style="width:90px; border-top:1px solid #CCC; border-left:1px solid #CCC; font-weight:bold;">Date</td>
								<td style="width:90px; border-top:1px solid #CCC; border-left:1px solid #CCC; font-weight:bold;">Time</td>
								<td style="width:90px; border-top:1px solid #CCC; border-left:1px solid #CCC; font-weight:bold;">Location</td>
								<td style="width:180px; border-top:1px solid #CCC; border-left:1px solid #CCC; border-right:1px solid #CCC; font-weight:bold;">Event Details</td>
							</tr>
							<tr>
								<td style="width:100px; border-top:1px solid #CCC; border-left:1px solid #CCC;">July 9,2013</td>
								<td style="width:100px; border-top:1px solid #CCC; border-left:1px solid #CCC;">04:54:45 AM</td>
								<td style="width:100px; border-top:1px solid #CCC; border-left:1px solid #CCC;">SG</td>
								<td style="width:100px; border-top:1px solid #CCC; border-left:1px solid #CCC; border-right:1px solid #CCC;">Deliver</td>
							</tr>
							<tr>
								<td style="width:100px; border-top:1px solid #CCC; border-left:1px solid #CCC; border-bottom:1px solid #CCC;">July 9,2013</td>
								<td style="width:100px; border-top:1px solid #CCC; border-left:1px solid #CCC; border-bottom:1px solid #CCC;">08:04:25 PM</td>
								<td style="width:100px; border-top:1px solid #CCC; border-left:1px solid #CCC;  border-bottom:1px solid #CCC;">SG</td>
								<td style="width:100px; border:1px solid #CCC;">Transfer to local carrier for the final delivery</td>
							</tr>
						</table>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>