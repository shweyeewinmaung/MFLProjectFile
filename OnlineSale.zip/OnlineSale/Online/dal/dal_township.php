<?php
function getAllTownshipData(){
	$sql="Select * from tbl_township order by TownshipID";
	$ret=mysql_query($sql);
	return $ret;
}

function GetTownshipDataBy_TownshipID($TownshipID){
	$sql="SELECT * FROM tbl_township WHERE TownshipID='$TownshipID'";
	$ret=mysql_query($sql);
	return $ret;
}

function GetTownshipData_byTownshipName($TownshipName){
	$sql="Select * from tbl_township where TownshipName='$TownshipName'";
	$ret=mysql_query($sql);
	return $ret;
}

function InsertTownship($TownshipID,$CityID,$TownshipName){
	$sql="Insert into tbl_township(TownshipID,CityID,TownshipName)values('$TownshipID','$CityID','$TownshipName')";
	$ret=mysql_query($sql);
	return $ret;
}

function UpdateTownship($TownshipID,$CityID,$TownshipName){
	$sql="update tbl_township set TownshipName=$TownshipName where TownshipID='$TownshipID'";
	$ret=mysql_query($sql);
	return $ret;
}

function DeleteTownship($TownshipID,$CityID,$TownshipName){
	$sql="delete tbl_township where TownshipID=$TownshipID";
	$ret=mysql_query($sql);
	return $ret;
}
?>