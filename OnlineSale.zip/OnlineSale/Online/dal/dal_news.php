<?php
function GetAllNewsDataASC()
{
	$sql="SELECT * FROM tbl_news ORDER BY NewsID";
	return mysql_query($sql);
}

function GetAllNewsDataDESC()
{
	$sql="SELECT * FROM tbl_news ORDER BY NewsID DESC";
	return mysql_query($sql);
}

function GetNewsDataByNewsID($NewsID)
{
	$sql="SELECT * FROM tbl_news WHERE NewsID='$NewsID'";
	return mysql_query($sql);
}

function InsertNews($Title, $Description, $NewsDate, $NewsTime, $Status, $UserID)
{
	$sql="INSERT INTO tbl_news(Title, Description, NewsDate, NewsTime, Status, UserID) 
			VALUES('$Title', '$Description', '$NewsDate', '$NewsTime', '$Status', '$UserID')";
	mysql_query($sql);
}

function UpdateNews($NewsID, $Title, $Description, $Status)
{
	$sql="UPDATE tbl_news SET Title='$Title', 
								Description='$Description', 
								Status='$Status' 
							WHERE NewsID='$NewsID'";
	mysql_query($sql);
}

function DeleteNews($NewsID)
{
	$sql="DELETE FROM tbl_news WHERE NewsID='$NewsID'";
	mysql_query($sql);
}
?>