<?php

function ItemAutoID()
{
	return AutoID('tbl_item', 'ItemCode', 'Itm-', 7);
}

function GetItemAllData()
{
	$sql="SELECT * FROM tbl_item ORDER BY ItemCode AND Process";
	return mysql_query($sql);
}

function GetItemDataByDeliveryStaff($DeliveryStaff)
{
	$sql="SELECT * FROM tbl_item WHERE DeliveryStaff='$DeliveryStaff'";
	return mysql_query($sql);
}

function GetItemDataByDeliveryStaffAndProcess($DeliveryStaff, $Process)
{
	$sql="SELECT * FROM tbl_item WHERE DeliveryStaff='$DeliveryStaff' AND Process='$Process'";
	return mysql_query($sql);
}

function GetItemDataByCustomerID($CustomerID)
{
	$sql="SELECT * FROM tbl_item WHERE FCustomer='$CustomerID'";
	return mysql_query($sql);
}

function GetItemDataByCustomerIDAndDeliveryStaff($CustomerID, $DeliveryStaff)
{
	$sql="SELECT * FROM tbl_item WHERE FCustomer='$CustomerID' AND DeliveryStaff='$DeliveryStaff'";
	return mysql_query($sql);
}

function GetItemDataByItemCode($ItemCode)
{
	$sql="SELECT * FROM tbl_item WHERE ItemCode='$ItemCode'";
	return mysql_query($sql);
}

function GetItemDataByProcess($Process)
{
	$sql="SELECT * FROM tbl_item WHERE Process='$Process'";
	return mysql_query($sql);
}

function InsertItem($FCustomerID, $TCustomerID, $AdminID, $ItemCode, $ItemName, $ItemDetail, $TrackNo, $DeliveryStaff, $Process)
{
	$sql="INSERT INTO tbl_item(FCustomer, TCustomer, AdminID, ItemCode, ItemName, ItemDetail, TrackNo, DeliveryStaff, Process) 
			VALUES('$FCustomerID', '$TCustomerID', '$AdminID', '$ItemCode', '$ItemName', '$ItemDetail', '$TrackNo', '$DeliveryStaff', '$Process')";
	mysql_query($sql);
}

function UpdateItem($ItemNo, $AdminID, $ItemCode, $ItemName, $ItemDetail, $TrackNo, $DeliveryStaff, $Process)
{
	$sql="UPDATE tbl_item SET AdminID='$AdminID', 
								  ItemCode='$ItemCode', 
								  ItemName='$Phone', 
								  ItemDetail='$ItemDetail', 
								  TrackNo='$TrackNo', 
								  DeliveryStaff='$DeliveryStaff', 
								  Process='$Process' 
								WHERE ItemNo='$ItemNo'";
	mysql_query($sql);
}

function UpdateItemProcess($Process, $ItemNo)
{
	$sql="UPDATE tbl_item SET Process='$Process' WHERE ItemNo='$ItemNo'";
	mysql_query($sql);
}

function RemoveItem($ItemNo)
{
	$sql="DELETE FROM tbl_item WHERE ItemNo='$ItemNo'";
	mysql_query($sql);
}
?>