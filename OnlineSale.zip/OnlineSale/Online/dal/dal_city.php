<?php
function getAllCityData()
{
	$sql="Select * from tbl_city order by CityID";
	$ret=mysql_query($sql);
	return $ret;
}

function GetCityDataBy_CityID($CityID)
{
	$sql="SELECT * FROM tbl_city WHERE CityID='$CityID'";
	$ret=mysql_query($sql);
	return $ret;
}

function GetCityDataBy_CityName($CityName)
{
	$sql="SELECT * FROM tbl_city WHERE CityName='$CityName'";
	$ret=mysql_query($sql);
	return $ret;
}

function InsertCity($CityID, $CityName)
{
	$sql="Insert into tbl_city(CityID,CityName) values('$CityID','$CityName')";
	$ret=mysql_query($sql);
	return $ret;	
}

function UpdateCity($CityID, $CityName)
{
	$sql="update tbl_city set CountryID=$CountryID,CityName=$CityName where CityID=$CityID";
	$ret=mysql_query($sql);
	return $ret;	
}

function DeleteCity($CityID,$CountryID,$CityName)
{
	$sql="delete from tbl_city where $CityID=$CityID";
	$ret=mysql_query($sql);
	return $ret;	
}

?>