<?php
function GetAllAdmin()
{
	$sql="SELECT * FROM tbl_admin ORDER BY Role";
	return mysql_query($sql);
}

function GetAdminDataByAdminID($AdminID)
{
	$sql="SELECT * FROM tbl_admin WHERE AdminID='$AdminID'";
	return mysql_query($sql);
}

function GetAdminDataByFullName($FullName)
{
	$sql="SELECT * FROM tbl_admin WHERE FullName='$FullName'";
	return mysql_query($sql);
}

function GetAdminDataByUserName($UserName)
{
	$sql="SELECT * FROM tbl_admin WHERE UserName='$UserName'";
	return mysql_query($sql);
}

function GetAdminDataByUserNameAndPassword($UserName, $Password)
{
	$sql="SELECT * FROM tbl_admin WHERE UserName='$UserName' AND Password='" . md5($Password) . "'";
	return mysql_query($sql);
}

function GetAdminDataByRole($Role)
{
	$sql="SELECT * FROM tbl_admin WHERE Role='$Role'";
	return mysql_query($sql);
}

function InsertAdmin($FullName, $Gender, $Email, $Phone, $Address, $UserName, $Password, $Role)
{
	$sql="INSERT INTO tbl_admin(FullName, Gender, Email, Phone, Address, UserName, Password, Role) 
			VALUES('$FullName', '$Gender', '$Email', '$Phone', '$Address', '$UserName', '" . md5($Password) . "', '$Role')";
	mysql_query($sql);
}

function UpdateAdmin($AdminID, $FullName, $Gender, $Email, $Phone, $Address, $Role)
{
	$sql="UPDATE tbl_admin SET FullName='$FullName', 
							  Gender='$Gender', 
							  Email='$Email', 
							  Phone='$Phone', 
							  Address='$Address', 
							  Role='$Role' 
							WHERE AdminID='$AdminID'";
	mysql_query($sql);
}

function RemoveAdmin($AdminID)
{
	$sql="DELETE FROM tbl_admin WHERE AdminID='$AdminID'";
	mysql_query($sql);
}
?>