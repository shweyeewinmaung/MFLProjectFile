<?php

function CustomerAutoID()
{
	return AutoID('tbl_customer', 'CustomerID', 'C-', 7);
}

function GetCustomerAllData()
{
	$sql="SELECT * FROM tbl_customer ORDER BY CustomerID AND Status DESC";
	return mysql_query($sql);
}

function GetCustomerDataByCustomerID($CustomerID)
{
	$sql="SELECT * FROM tbl_customer WHERE CustomerID='$CustomerID'";
	return mysql_query($sql);
}

function GetCustomerDataByEntryDate($EntryDate)
{
	$sql="SELECT * FROM tbl_customer WHERE EntryDate='$EntryDate'";
	return mysql_query($sql);
}

function GetCustomerDataByCustomerName($CustomerName)
{
	$sql="SELECT * FROM tbl_customer WHERE CustomerName='$CustomerName'";
	return mysql_query($sql);
}

function GetCustomerDataByStatus($Status)
{
	$sql="SELECT * FROM tbl_customer WHERE Status='$Status'";
	return mysql_query($sql);
}

function GetCustomerNameByCustomerID($CustomerID)
{
	$sql="SELECT * FROM tbl_customer WHERE CustomerID='$CustomerID'";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);

	return $row['CustomerName'];
}

function InsertCustomer($CustomerID, $AdminID, $EntryDate, $CustomerName, $Gender, $Phone, $Email, $Address, $Status)
{
	$sql="INSERT INTO tbl_customer(CustomerID, AdminID, EntryDate, CustomerName, Gender, Phone, Email, Address, Status) 
			VALUES('$CustomerID', '$AdminID', '$EntryDate', '$CustomerName', '$Gender', '$Phone', '$Email', '$Address', '$Status')";
	mysql_query($sql);
}

function UpdateCustomer($CustomerID, $EntryDate, $CustomerName, $Gender, $Phone, $Email, $Address, $Status)
{
	$sql="UPDATE tbl_customer SET CustomerName='$CustomerName', 
									  Gender='$Gender', 
									  Phone='$Phone', 
									  Email='$Email', 
									  Address='$Address', 
									  Status='$Status' 
									WHERE CustomerID='$CustomerID'";
	mysql_query($sql);
}

function UpdateCustomerStatus($Status, $CustomerID)
{
	$sql="UPDATE tbl_customer SET Status='$Status' WHERE CustomerID='$CustomerID'";
	mysql_query($sql);
}

?>