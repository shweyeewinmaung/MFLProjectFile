<?php
session_start();
require_once("library/db.php");
require_once("dal/dal_admin.php");
require_once("library/globalfunction.php");
//require_once("library/permission.php");

if(isset($_POST['UserName']) && isset($_POST['Password']))
{
	$UserName=Clean($_POST['UserName']);
	$Password=Clean($_POST['Password']);
	
	$ret=GetAdminDataByUserNameAndPassword($UserName, $Password);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
		$_SESSION['SESS']['User']['UserID']=$row['AdminID'];
		$_SESSION['SESS']['User']['Role']=$row['Role'];
		echo $_SESSION['SESS']['User']['UserID'];
	}
	else
	{
		
	}
}
?>
<html>
<head>
</head>
<title>
</title>
<body>
<form method="post">
	<table>
    	<tr>
        	<td>User Name</td>
            <td><input type="text" name="UserName" required /></td>
        </tr>
        <tr>
        	<td>Password</td>
            <td><input type="text" name="Password" required /></td>
        </tr>
        <tr>
        	<td></td>
            <td><input type="submit" value="LogIn" /></td>
        </tr>
    </table>
</form>
</body>
</html>


