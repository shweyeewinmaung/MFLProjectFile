<html>
	<head>
		<link href="css/style.css" type="text/css" media="all" rel="stylesheet" />
	</head>
	<body>
		<div id="wrapper">
			<div id="logobox">
				
			</div>
			<div id="divpricetracking">
				<h1 style="font-size:31px; margin:10px 0 0 50px;">Price Tracking</h1>
				<table style="width:1200px; margin:10px 0 0 50px; ">
					<tr>
						<td align="left" style="width:700px; border:1px solid #CCC;">
							<h1 style="color:red; font-size:18px; margin:5px; padding:0;">Weight</h1>
							<h1 style="color:black; font-size:12px; margin:5px; padding:0; float:left;">Delivery Weight: &nbsp;<p1 style="color:green;">18g</p1></h1>
						</td>
						<td style="width:700px; border:1px solid #CCC;">
							<h1 style="color:red; font-size:18px; margin:5px; padding:0;">Township</h1>
							<h1 style="color:black; font-size:12px; margin:5px; padding:0;">Delivery Township: &nbsp;<p1 style="color:green;">Kamayut Township</p1></h1>
						</td>
					</tr>
				</table>
				<div style="width:100%: border:1px solid black; margin:5px 0 0 0;">
					<h1 style="color:black; font-size:18px; margin:60px 0 0 300; padding:0;">Delivery Charges to your home&nbsp;<input type="label" style="width:130px; font-size:20px; color:white; background-color:black; padding:40px; border-radius:400px; border:2px solid #CCC;" value="6000 Kyats">Kyats</label></h1>
				</div>
			</div>
			<div id="offerdiv">
				<table style="width:80%; margin:20px auto;">
					<tr>
						<td style="padding-right:20px;"><input type="submit" value="Track a Shipment" style="background-color:black; color:white; border:1px solid #CCC; width:240px;"/></td>
						<td style="padding-right:20px;"><input type="submit" value="Get a Quck Rate" style="background-color:black; color:white; border:1px solid #CCC; width:240px;"/></td>
						<td style="padding-right:20px;"><input type="submit" value="See Our Offer" style="background-color:black; color:white; border:1px solid #CCC; width:240px;"/></td>
					</tr>
				</table>
			</div>
		</div>
	</body>
</html>