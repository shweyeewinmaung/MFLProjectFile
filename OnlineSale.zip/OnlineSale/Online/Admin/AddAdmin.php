<?php
require_once("../library/db.php");
require_once("../dal/dal_admin.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");
//require_once("../library/permission.php");


if (isset($_POST['FullName']) && isset($_POST['Phone']) && isset($_POST['Email']))
{	
	$FullName=Clean($_POST['FullName']);
	$Gender=Clean($_POST['Gender']);
	$Phone=Clean($_POST['Phone']);
	$Email=Clean($_POST['Email']);
	$Address=Clean($_POST['Address']);
	$UserName=Clean($_POST['UserName']);
	$Password=Clean($_POST['Password']);
	$Role=Clean($_POST['Role']);
	
	InsertAdmin($FullName, $Gender, $Email, $Phone, $Address, $UserName, $Password, $Role);
}
?>
<html>
<head>
</head>
<title>
</title>
<body>



<form method="POST" enctype="multipart/form-data">
	<div style="width:100%">
	<table style="margin:0 auto;">
		<tr>
        	<th colspan="3"><h1>Add New Admin</h1></th>
        </tr>
        <tr>
            <td>Full Name</td>
            <td>:</td>
            <td><input type="text" name="FullName" style="width:75%" required/></td>
        </tr>
        <tr>
            <td>Gender</td>
            <td>:</td>
            <td><select name="Gender" style="width:75%" >
                <option>Male</option>
                <option>Female</option>
            </select></td>
        </tr>
        <tr>
            <td>Phone</td>
            <td>:</td>
            <td><input type="text" name="Phone" style="width:75%" required/></td>
        </tr>
        <tr>
            <td>Email</td>
            <td>:</td>
            <td><input type="text" name="Email" style="width:75%" required/></td>
        </tr>
        <tr>
            <td valign="top">Address</td>
            <td valign="top">:</td>
            <td><textarea name="Address" rows="7" cols="27"></textarea></td>
        </tr>
        <tr>
            <td>UserName</td>
            <td>:</td>
            <td><input type="text" name="UserName" style="width:75%" required/></td>
        </tr>
        <tr>
            <td>Password</td>
            <td>:</td>
            <td><input type="Password" name="Password" style="width:75%" required/></td>
        </tr>
        <tr>
            <td>Role</td>
            <td>:</td>
            <td><select name="Role" style="width:75%">
                <option>Delivery</option>
                <option>Admin</option>
                <option>Owner</option>
            </select></td>
        </tr>
        <tr>
        	<td colspan="2"><br /></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td><input type="submit" value="Add Admin" style="background-color:#144cda;"/></td>
        </tr>
        </table>
        </div>
    </form>
</body>
</html>


