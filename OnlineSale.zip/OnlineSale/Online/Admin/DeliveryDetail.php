<?php
require_once("../library/db.php");
require_once("../dal/dal_customer.php");
require_once("../dal/dal_item.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");
//require_once("../library/permission.php");

if(isset($_POST['ItemNo']) && isset($_POST['btnUpdate']))
{
	$ItemNo=Clean($_POST['ItemNo']);
	$Process=Clean($_POST['Process']);
	
	UpdateItemProcess($Process, $ItemNo);
}

if(isset($_POST['ItemNo']) && isset($_POST['btnRemove']))
{
	$ItemNo=Clean($_POST['ItemNo']);
	RemoveItem($ItemNo);
}

$CustomerID=Clean($_GET['CustomerID']);
$StaffID=2;

$retc=GetCustomerDataByCustomerID($CustomerID);

$reti=GetItemDataByCustomerIDAndDeliveryStaff($CustomerID,$StaffID);
$numi=mysql_num_rows($reti);
?>
<html>
<head>
</head>
<title>
</title>
<body>
<?php
if($numi>0)
{
	$rowc=mysql_fetch_array($retc);
	?>
    <div style="width:100%; margin:0 auto;">
    
    	<table style="margin:0 auto;">
        	<tr>
            	<td>Name</td>
            	<td><?php echo $rowc['CustomerName']; ?></td>
            </tr>
            <tr>
            	<td>Gender</td>
            	<td><?php echo $rowc['Gender']; ?></td>
            </tr>
            <tr>
            	<td>Phone</td>
            	<td><?php echo $rowc['Phone']; ?></td>
            </tr>
            <tr>
            	<td>Email</td>
            	<td><?php echo $rowc['Email']; ?></td>
            </tr>
            <tr>
            	<td valign="top">Address</td>
            	<td><?php echo $rowc['Address']; ?></td>
            </tr>
		</table>   
        <br /><br />
        <center>
        <table>
        	<tr>
            	<td></td>
            	<td>Item Code</td>
                <td>Item Name</td>
                <td>Item Detail</td>
                <td>Track No</td>
                <td>Process</td>
                <td></td>
                <td></td>
            </tr>
           <?php
				$i=1;
				while($rowi=mysql_fetch_array($reti))
				{
					?>
                    	<tr>
                        <form method="post">
                        	<td><?php echo $i; ?><input type="hidden" name="ItemNo" value="<?php echo $rowi['ItemNo']; ?>" required></td>
                        	<td><?php echo $rowi['ItemCode']; ?></td>
                            <td><?php echo $rowi['ItemName']; ?></td>
                            <td><?php echo $rowi['ItemDetail']; ?></td>
                            <td><?php echo $rowi['TrackNo']; ?></td>
                            <td><?php echo $rowi['Process']; ?></td>
                            <td><select name="Process">
                            	<option>Pending</option>
                                <option>Received</option>
                                <option>Out for delivery</option>
                                <option>Delivered</option>
                            </select> <input type="submit" name="btnUpdate" value="Update" /></td>
                            <td><input type="submit" name="btnRemove" value="Remove Item" /></td>
						</form>
                        </tr>
                    <?php
					$i=$i+1;
				}
			?>
        </table>
        </center>
	</div>
    <?php
}
?>
</body>
</html>


