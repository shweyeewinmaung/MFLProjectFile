<?php
require_once("../library/db.php");
require_once("../dal/dal_customer.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");
//require_once("../library/permission.php");

if (isset($_POST['CustomerName']) && isset($_POST['Phone']) && isset($_POST['TCustomerName']) && isset($_POST['TPhone']))
{	
	$AdminID=$_SESSION['SESS']['User']['UserID'];
	$EntryDate=GetCurrentDate();
	
	
	$CustomerID=CustomerAutoID();
	$CustomerName=Clean($_POST['CustomerName']);
	$Gender=Clean($_POST['Gender']);
	$Phone=Clean($_POST['Phone']);
	$Email=Clean($_POST['Email']);
	$Address=Clean($_POST['Address']);
	$Status="From";
	
	InsertCustomer($CustomerID, $AdminID, $EntryDate, $CustomerName, $Gender, $Phone, $Email, $Address, $Status);
	
	
	$TCustomerID=CustomerAutoID();
	$CustomerName=Clean($_POST['TCustomerName']);
	$Gender=Clean($_POST['TGender']);
	$Phone=Clean($_POST['TPhone']);
	$Email=Clean($_POST['TEmail']);
	$Address=Clean($_POST['TAddress']);
	$Status="To";
	
	InsertCustomer($TCustomerID, $AdminID, $EntryDate, $CustomerName, $Gender, $Phone, $Email, $Address, $Status);
	
	header("Location:AddItem.php?F=$CustomerID?&T=$TCustomerID");
}
?>
<html>
<head>
</head>
<title>
</title>
<body>



<form method="POST" enctype="multipart/form-data">
	<div style="width:50%; float:left;">
        <table style="margin:0 auto;">
        	<th colspan="3"><h3>Delivery From</h3></th>
            <tr>
                <td>Customer Name</td>
                <td>:</td>
                <td><input type="text" name="CustomerName" style="width:75%" required/></td>
            </tr>
            <tr>
                <td>Gender</td>
                <td>:</td>
                <td><select name="Gender" style="width:75%" >
                    <option>Male</option>
                    <option>Female</option>
                </select></td>
            </tr>
            <tr>
                <td>Phone</td>
                <td>:</td>
                <td><input type="text" name="Phone" style="width:75%" required/></td>
            </tr>
            <tr>
                <td>Email</td>
                <td>:</td>
                <td><input type="text" name="Email" style="width:75%" required/></td>
            </tr>
            <tr>
                <td valign="top">Address</td>
                <td valign="top">:</td>
                <td><textarea name="Address" rows="7" cols="27"></textarea></td>
            </tr>
            <tr>
                <td colspan="2"><br /></td>
            </tr>
            </table>
        </div>
        
        
        <div style="width:50%; float:left;">
            <table style="margin:0 auto;">
                <th colspan="3"><h3>Delivery To</h3></th>
                <tr>
                    <td>Customer Name</td>
                    <td>:</td>
                    <td><input type="text" name="TCustomerName" style="width:75%" required/></td>
                </tr>
                <tr>
                    <td>Gender</td>
                    <td>:</td>
                    <td><select name="TGender" style="width:75%" >
                        <option>Male</option>
                        <option>Female</option>
                    </select></td>
                </tr>
                <tr>
                    <td>Phone</td>
                    <td>:</td>
                    <td><input type="text" name="TPhone" style="width:75%" required/></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td>:</td>
                    <td><input type="text" name="TEmail" style="width:75%" required/></td>
                </tr>
                <tr>
                    <td valign="top">Address</td>
                    <td valign="top">:</td>
                    <td><textarea name="TAddress" rows="7" cols="27"></textarea></td>
                </tr>
                <tr>
                    <td colspan="2"><br /></td>
                </tr>
			</table>
        </div>
        <div style="width:100%;">
        	<center><input type="submit" value="Submit"></center>
        </div>
    </form>
</body>
</html>


