<?php
require_once("../library/db.php");
require_once("../dal/dal_admin.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");
//require_once("../library/permission.php");

$ret=GetAllAdmin();
$num=mysql_num_rows($ret);
?>
<html>
<head>
</head>
<title>
</title>
<body>
<?php
if($num>0)
{
	?>
    	<table style="margin:0 auto;">
        	<tr>
            	<td></td>
            	<td>Name</td>
                <td>Gender</td>
                <td>Email</td>
                <td>Phone</td>
                <td>Role</td>
                <td></td>
                <td></td>
            </tr>
            
            <?php
				$i=1;
				while($row=mysql_fetch_array($ret))
				{
					?>
                    	<tr>
                        	<td><?php echo $i; ?></td>
                        	<td><?php echo $row['FullName']; ?></td>
                            <td><?php echo $row['Gender']; ?></td>
                            <td><?php echo $row['Email']; ?></td>
                            <td><?php echo $row['Phone']; ?></td>
                            <td><?php echo $row['Role']; ?></td>
                            <td><a href="EditAdmin.php?AdminID=<?php echo $row['AdminID']; ?>">Edit</a></td>
                            <td><a href="RemoveAdmin.php?AdminID=<?php echo $row['AdminID']; ?>">Remove</a></td>
                        </tr>
                    <?php
					$i=$i+1;
				}
			?>
        </table>
    <?php
}
else
{
	
}
?>
</body>
</html>


