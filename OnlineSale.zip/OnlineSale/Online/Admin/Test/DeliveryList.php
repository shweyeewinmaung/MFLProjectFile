<?php
session_start();
require_once("../../library/db.php");
require_once("../../dal/dal_customer.php");
require_once("../../dal/dal_item.php");
require_once("../../library/function.php");
require_once("../../library/globalfunction.php");
//require_once("../library/permission.php");

$retc=GetCustomerDataByStatus("From");
$numc=mysql_num_rows($retc);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home</title>
<link href="../../css/style2.css" type="text/css" media="all" rel="stylesheet" />
<script src="../../javascript/jquery-1.6.2.min.js" type="text/javascript"></script>
<script src="../../javascript/cufon-yui.js" type="text/javascript"></script>
<script src="../../javascript/Myriad_Pro_700.font.js" type="text/javascript"></script>
<script src="../../javascript/jquery.jcarousel.min.js" type="text/javascript" charset="utf-8"></script>
<script src="../../javascript/functions.js" type="text/javascript" charset="utf-8"></script>
</head>

<body>
<div id="wapper">
    <div id="header">
        <img src="../../images/logo2.jpg" style="width:18%; height:20%; margin-left:7%; margin-top:0.5%; float:left;" />
        <img src="../../images/phone1.jpg" style="width:10%; height:20%; margin-left:45%; margin-top:0.5%; float:left;" />
        <div style="width:15%; height:20%; margin-left:1%; margin-top:0.5%; float:left; display:table-cell; vertical-align:middle;">
        	09-123456789
        </div>
        <div style="width:100%; height:79.5%; float:left;">
        	<img src="../../images/delivery_banner.jpg" width="100%;" height="100%;" style="-webkit-border-radius: 10px; -moz-border-radius: 10px;	border-radius: 10px;" />
            
            <div class="calcualte">
				<input type="text" placeholder="weight 10kg..." style="background: white; border: 1px double #DDD; border-radius: 5px; box-shadow: 0 0 5px #333; color: #666; outline: none; height:50%; width:25%; top:22.5%; left:15%; position:absolute; font-size:18px;" />
                <select style="background: white; border: 1px double #DDD; border-radius: 5px; box-shadow: 0 0 5px #333; color: #666; outline: none; height:50%; width:25%; top:22.5%; left:45%; position:absolute; font-size:18px;">
                	<option>   Township...</option>
                </select>
                <input type="submit" value="Quote" style="background: white; border: 1px double #DDD; border-radius: 5px; box-shadow: 0 0 5px #333; color: #666; outline: none; height:50%; width:20%; top:22.5%; left:75%; position:absolute; font-size:18px; background-color:#DC143C; color:White;" />
            </div>
        </div>
    </div>
    
    <div id="middle">
    <div style="width:auto; height:auto;">
    	<?php
			if($numc>0)
			{
				?>
					<table style="margin:0 auto;">
						<tr>
							<td></td>
							<td>From</td>
							<td>To</td>
							<td>Item</td>
							<td>Remain</td>
							<td>Finished</td>
							<td></td>
							<td></td>
						</tr>
						
						<?php
							$i=1;
							while($rowc=mysql_fetch_array($retc))
							{
								$reti=GetItemDataByCustomerID($rowc['CustomerID']);
								$rowi=mysql_fetch_array($reti);
								$numi=mysql_num_rows($reti);
			
								
								$retR=GetItemDataByProcess("Delivered");
								$numF=mysql_num_rows($retR);
								?>
									<tr>
										<td><?php echo $i; ?></td>
										<td><?php echo $rowc['CustomerName']; ?></td>
										<td><?php echo GetCustomerNameByCustomerID($rowi['TCustomer']); ?></td>
										<td><?php echo $numi; ?></td>
										<td><?php echo ($numi - $numF); ?></td>
										<td><?php echo $numF ?></td>
										<td><a href="AddItem.php?F=<?php echo $rowi['FCustomer']; ?>&T=<?php echo $rowi['TCustomer']; ?>">Add Item</a></td>
										<td><a href="DeliveryDetail.php?CustomerID=<?php echo $rowc['CustomerID']; ?>">Check</a></td>
									</tr>
								<?php
								$i=$i+1;
							}
						?>
					</table>
				<?php
			}
			else
			{
				
			}
			?>
    </div>
        
    </div>
    
    <div id="footer">
        
    </div>
</div>
</body>
</html>