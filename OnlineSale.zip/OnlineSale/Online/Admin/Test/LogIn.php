<?php
session_start();
require_once("../../library/db.php");
require_once("../../dal/dal_admin.php");
require_once("../../library/globalfunction.php");
//require_once("library/permission.php");

if(isset($_POST['UserName']) && isset($_POST['Password']))
{
	$UserName=Clean($_POST['UserName']);
	$Password=Clean($_POST['Password']);
	
	$ret=GetAdminDataByUserNameAndPassword($UserName, $Password);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
		$_SESSION['SESS']['User']['UserID']=$row['AdminID'];
		$_SESSION['SESS']['User']['Role']=$row['Role'];
		//echo $_SESSION['SESS']['User']['UserID'];
		header("Location:DeliveryList.php");
	}
	else
	{
		
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home</title>
<link href="../../css/style2.css" type="text/css" media="all" rel="stylesheet" />
<script src="../../javascript/jquery-1.6.2.min.js" type="text/javascript"></script>
<script src="../../javascript/cufon-yui.js" type="text/javascript"></script>
<script src="../../javascript/Myriad_Pro_700.font.js" type="text/javascript"></script>
<script src="../../javascript/jquery.jcarousel.min.js" type="text/javascript" charset="utf-8"></script>
<script src="../../javascript/functions.js" type="text/javascript" charset="utf-8"></script>
</head>

<body>
<div id="wapper">
    <div id="header">
        <img src="../../images/logo2.jpg" style="width:18%; height:20%; margin-left:7%; margin-top:0.5%; float:left;" />
        <img src="../../images/phone1.jpg" style="width:10%; height:20%; margin-left:45%; margin-top:0.5%; float:left;" />
        <div style="width:15%; height:20%; margin-left:1%; margin-top:0.5%; float:left; display:table-cell; vertical-align:middle;">
        	09-123456789
        </div>
        <div style="width:100%; height:79.5%; float:left;">
        	<img src="../../images/delivery_banner.jpg" width="100%;" height="100%;" style="-webkit-border-radius: 10px; -moz-border-radius: 10px;	border-radius: 10px;" />
            
            <div class="calcualte">
				<input type="text" placeholder="weight 10kg..." style="background: white; border: 1px double #DDD; border-radius: 5px; box-shadow: 0 0 5px #333; color: #666; outline: none; height:50%; width:25%; top:22.5%; left:15%; position:absolute; font-size:18px;" />
                <select style="background: white; border: 1px double #DDD; border-radius: 5px; box-shadow: 0 0 5px #333; color: #666; outline: none; height:50%; width:25%; top:22.5%; left:45%; position:absolute; font-size:18px;">
                	<option>   Township...</option>
                </select>
                <input type="submit" value="Quote" style="background: white; border: 1px double #DDD; border-radius: 5px; box-shadow: 0 0 5px #333; color: #666; outline: none; height:50%; width:20%; top:22.5%; left:75%; position:absolute; font-size:18px; background-color:#DC143C; color:White;" />
            </div>
        </div>
    </div>
    
    <div id="middle">
        <form method="post">
        	
            <div style="width:100%; height:auto; float:left;">
            <label style="margin-left:17%; margin-top:11%; float:left;">User Name</label><label style="margin-right:57%; margin-top:11%; float:right;"><input type="text" name="UserName" required /></label><br />
            </div>
            <div style="width:100%; height:auto; float:left;">
            <label style="margin-left:17%; margin-top:4%; float:left;">Password</label><label style="margin-right:57%; margin-top:4%; float:right;"><input type="text" name="Password" required /></label><br />
            </div>
            <div style="width:100%; height:auto; float:left;">
            <label style="margin-left:17%; margin-top:4%; float:left;"></label><label style="margin-left:7%; margin-top:4%; float:left;"><input type="submit" value="LogIn" /></label>
            </div>

        </form>
    </div>
    
    <div id="footer">
        
    </div>
</div>
</body>
</html>