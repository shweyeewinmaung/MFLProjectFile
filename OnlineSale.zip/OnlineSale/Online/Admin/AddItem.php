<?php
require_once("../library/db.php");
require_once("../dal/dal_admin.php");
require_once("../dal/dal_customer.php");
require_once("../dal/dal_item.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");
//require_once("../library/permission.php");


if (isset($_POST['FCustomerID']) && isset($_POST['ItemCode']) && isset($_POST['DeliveryAddress']))
{	
	$AdminID=$_SESSION['SESS']['User']['UserID'];
	$From=Clean($_POST['FCustomerID']);
	$To=Clean($_POST['TCustomerID']);
	
	$ItemCode=Clean($_POST['ItemCode']);
	$ItemName=Clean($_POST['ItemName']);
	$ItemDetail=Clean($_POST['ItemDetail']);
	$DeliveryAddress=Clean($_POST['DeliveryAddress']);
	$TrackNo=Clean($_POST['TrackNo']);
	$DeliveryStaff=Clean($_POST['DeliveryStaff']);
	$DeliveryDate=Clean($_POST['DeliveryDate']);
	$Process="Received";
	
	InsertItem($From, $To, $AdminID, $ItemCode, $ItemName, $ItemDetail, $TrackNo, $DeliveryStaff, $Process);
}

if(isset($_GET['F']) && $_GET['F']!="" && isset($_GET['T']) && $_GET['T']!="")
{
	$From=Clean($_GET['F']);
	$retf=GetCustomerDataByCustomerID($From);
	$numf=mysql_num_rows($retf);
	
	if($numf<=0)
	{
		header("Location:DeliveryList.php");
	}
	
	$To=Clean($_GET['T']);
	$retc=GetCustomerDataByCustomerID($To);
	$numc=mysql_num_rows($retc);

	if($numc<=0)
	{
		header("Location:AddCustomer.php");
	}
	
	if($numc>0)
	{
		$rowc=mysql_fetch_array($retc);
		if($rowc['Status']=="From")
		{
			header("Location:AddCustomer.php");
		}
	}
}
?>
<html>
<head>
</head>
<title>
</title>
<body>



<form method="POST" enctype="multipart/form-data">
	<div style="width:100%">
	<table style="margin:0 auto;">
		<tr>
        	<th colspan="3"><h1>Add Customer's Item</h1></th>
        </tr>
        <tr>
            <td>CustomerID</td>
            <td>:</td>
            <td><input type="hidden" name="FCustomerID" value="<?php echo Clean($_GET['F']); ?>"><input type="text" name="TCustomerID" value="<?php echo $rowc['CustomerID']; ?>" style="width:75%" readonly/></td>
        </tr>
        <tr>
            <td>Customer Name</td>
            <td>:</td>
            <td><input type="text" name="CustomerName" value="<?php echo $rowc['CustomerName']; ?>" style="width:75%" readonly/></td>
        </tr>
        <tr>
            <td>Item Code</td>
            <td>:</td>
            <td><input type="text" name="ItemCode" style="width:75%" required/></td>
        </tr>
        <tr>
            <td>Item Name</td>
            <td>:</td>
            <td><input type="text" name="ItemName" style="width:75%" required/></td>
        </tr>
        <tr>
            <td valign="top">Item Detail</td>
            <td valign="top">:</td>
            <td><textarea name="ItemDetail" rows="7" cols="27"></textarea></td>
        </tr>
        <tr>
            <td valign="top">Delivery Address</td>
            <td valign="top">:</td>
            <td><textarea name="DeliveryAddress" rows="7" cols="27" required></textarea></td>
        </tr>
        <tr>
            <td>Track Number</td>
            <td>:</td>
            <td><input type="text" name="TrackNo" value="<?php echo time() . "-" . mt_rand(); ?>" style="width:75%" required/></td>
        </tr>
        <tr>
            <td>Delivery Staff</td>
            <td>:</td>
            <td><select name="DeliveryStaff" style="width:75%">
                <?php
					$rets=GetAdminDataByRole("Delivery");
					while($rows=mysql_fetch_array($rets))
					{
						?>
	                        <option value="<?php echo $rows['AdminID']; ?>"><?php echo $rows['FullName']; ?></option>
                        <?php
					}
				?>
            </select></td>
        </tr>
        <tr>
        	<td colspan="2"><br /></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td><input type="submit" value="Add Item" style="background-color:#144cda;"/></td>
        </tr>
        </table>
        <br /><br />
        <?php
			$reti=GetItemDataByCustomerID($CustomerID);
			$numi=mysql_num_rows($reti);
			
			if($numi>0)
			{
				?>
                	<table width="100%">
                    	<tr>
                        	<th>Item List</th>
                        </tr>
                        <tr>
                        	<td>Item Code</td>
                            <td>Item Name</td>
                            <td>Track No</td>
                            <td>Delivery Staff</td>
                            <td>Process</td>
                            <td></td>
                        </tr>
                        <?php
							$i=1;
							while($rowi=mysql_fetch_array($reti))
							{
								?>
                                	<tr>
                                    	<td><?php echo $rowi['ItemCode']; ?></td>
                                        <td><?php echo $rowi['ItemName']; ?></td>
                                        <td><?php echo $rowi['TrackNo']; ?></td>
                                        <td><?php echo $rowi['DeliveryStaff']; ?></td>
                                        <td><?php echo $rowi['Process']; ?></td>
                                    </tr>
                                <?php
							}
						?>
                    </table>
                <?php
			}
		?>
        </div>
    </form>
</body>
</html>


