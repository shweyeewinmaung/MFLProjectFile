<?php
require_once("../library/db.php");
require_once("../dal/dal_customer.php");
require_once("../dal/dal_item.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");
//require_once("../library/permission.php");

$retc=GetCustomerDataByStatus("From");
$numc=mysql_num_rows($retc);
?>
<html>
<head>
</head>
<title>
</title>
<body>
<?php
if($numc>0)
{
	?>
    	<table style="margin:0 auto;">
        	<tr>
            	<td></td>
            	<td>From</td>
                <td>To</td>
                <td>Item</td>
                <td>Remain</td>
                <td>Finished</td>
                <td></td>
                <td></td>
            </tr>
            
            <?php
				$i=1;
				while($rowc=mysql_fetch_array($retc))
				{
					$reti=GetItemDataByCustomerID($rowc['CustomerID']);
					$rowi=mysql_fetch_array($reti);
					$numi=mysql_num_rows($reti);

					
					$retR=GetItemDataByProcess("Delivered");
					$numF=mysql_num_rows($retR);
					?>
                    	<tr>
                        	<td><?php echo $i; ?></td>
                        	<td><?php echo $rowc['CustomerName']; ?></td>
                            <td><?php echo GetCustomerNameByCustomerID($rowi['TCustomer']); ?></td>
                            <td><?php echo $numi; ?></td>
                            <td><?php echo ($numi - $numF); ?></td>
                            <td><?php echo $numF ?></td>
                            <td><a href="AddItem.php?F=<?php echo $rowi['FCustomer']; ?>&T=<?php echo $rowi['TCustomer']; ?>">Add Item</a></td>
                            <td><a href="DeliveryDetail.php?CustomerID=<?php echo $rowc['CustomerID']; ?>">Check</a></td>
                        </tr>
                    <?php
					$i=$i+1;
				}
			?>
        </table>
    <?php
}
else
{
	
}
?>
</body>
</html>


