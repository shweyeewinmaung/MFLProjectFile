<?php
require_once("../library/db.php");
require_once("../dal/dal_admin.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");
//require_once("../library/permission.php");


if(isset($_POST['AdminID']) && isset($_POST['btnRemove']))
{	
	$AdminID=Clean($_POST['AdminID']);
	
	RemoveAdmin($AdminID);
	header("Location:AdminList.php");
}

if(isset($_GET['AdminID']) && $_GET['AdminID']!="")
{
	$AdminID=Clean($_GET['AdminID']);
	$ret=GetAdminDataByAdminID($AdminID);
	$num=mysql_num_rows($ret);
}

?>
<html>
<head>
</head>
<title>
</title>
<body>

<form method="POST" enctype="multipart/form-data">
	<?php
		if($num>0)
		{
			$row=mysql_fetch_array($ret);
			?>
            	<div style="width:100%">
                <table style="margin:0 auto;">
                    <tr>
                        <th colspan="3"><h1>Add New Admin</h1></th>
                    </tr>
                    <tr>
                    	<td>AdminID</td>
                        <td>:</td>
                        <td><input type="text" name="AdminID" value="<?php echo $row['AdminID']; ?>" style="width:75%" required readonly/></td>
                    </tr>
                    <tr>
                        <td>Full Name</td>
                        <td>:</td>
                        <td><input type="text" name="FullName" value="<?php echo $row['FullName']; ?>" style="width:75%" required readonly/></td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td>:</td>
                        <td><input type="text" name="Gender" value="<?php echo $row['Gender']; ?>" style="width:75%" required readonly/></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td>:</td>
                        <td><input type="text" name="Phone" value="<?php echo $row['Phone']; ?>" style="width:75%" required readonly/></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>:</td>
                        <td><input type="text" name="Email" value="<?php echo $row['Email']; ?>" style="width:75%" required readonly/></td>
                    </tr>
                    <tr>
                        <td valign="top">Address</td>
                        <td valign="top">:</td>
                        <td><textarea name="Address" rows="7" cols="27" readonly><?php echo $row['Address']; ?></textarea></td>
                    </tr>
                    <tr>
                        <td>UserName</td>
                        <td>:</td>
                        <td><input type="text" name="UserName" value="<?php echo $row['UserName']; ?>" style="width:75%" required readonly/></td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td>:</td>
                        <td><input type="Password" name="Password" value="<?php echo $row['Password']; ?>" style="width:75%" required readonly/></td>
                    </tr>
                    <tr>
                        <td>Role</td>
                        <td>:</td>
                        <td><input type="text" name="Role" value="<?php echo $row['Role']; ?>" style="width:75%" required readonly/></td>
                    </tr>
                    <tr>
                        <td colspan="2"><br /></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td><input type="submit" value="Remove Admin" style="background-color:#144cda;"/></td>
                    </tr>
                    </table>
                    </div>
            <?php
		}
		else
		{
			
		}
	?>
</form>
</body>
</html>


