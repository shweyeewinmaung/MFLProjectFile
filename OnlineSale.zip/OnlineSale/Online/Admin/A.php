<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home</title>
<link href="../css/style2.css" type="text/css" media="all" rel="stylesheet" />
<script src="../javascript/jquery-1.6.2.min.js" type="text/javascript"></script>
<script src="../javascript/cufon-yui.js" type="text/javascript"></script>
<script src="../javascript/Myriad_Pro_700.font.js" type="text/javascript"></script>
<script src="../javascript/jquery.jcarousel.min.js" type="text/javascript" charset="utf-8"></script>
<script src="../javascript/functions.js" type="text/javascript" charset="utf-8"></script>
</head>

<body>
<div id="wapper">
    <div id="header">
        <img src="../images/logo2.jpg" style="width:18%; height:20%; margin-left:7%; margin-top:0.5%; float:left;" />
        <img src="../images/phone1.jpg" style="width:10%; height:20%; margin-left:45%; margin-top:0.5%; float:left;" />
        <div style="width:15%; height:20%; margin-left:1%; margin-top:0.5%; float:left; display:table-cell; vertical-align:middle;">
        	09-123456789
        </div>
        <div style="width:100%; height:79.5%; float:left;">
        	<img src="../images/delivery_banner.jpg" width="100%;" height="100%;" style="-webkit-border-radius: 10px; -moz-border-radius: 10px;	border-radius: 10px;" />
            
            <div class="calcualte">
				<input type="text" placeholder="weight 10kg..." style="background: white; border: 1px double #DDD; border-radius: 5px; box-shadow: 0 0 5px #333; color: #666; outline: none; height:50%; width:25%; top:22.5%; left:15%; position:absolute; font-size:18px;" />
                <select style="background: white; border: 1px double #DDD; border-radius: 5px; box-shadow: 0 0 5px #333; color: #666; outline: none; height:50%; width:25%; top:22.5%; left:45%; position:absolute; font-size:18px;">
                	<option>   Township...</option>
                </select>
                <input type="submit" value="Quote" style="background: white; border: 1px double #DDD; border-radius: 5px; box-shadow: 0 0 5px #333; color: #666; outline: none; height:50%; width:20%; top:22.5%; left:75%; position:absolute; font-size:18px; background-color:#DC143C; color:White;" />
            </div>
        </div>
    </div>
    
    <div id="body">
        <div style="width:98%; height:30%; margin-left:1%;">
        	<label style="color:#DC143C; font-size:36px; margin-left:5%;"><b>Track a shipment</b></label>
        </div>
        
        <div style="width:20%; height:69%; margin-left:1%; float:left;">
        	<img src="../images/delivery3d2.png" width="100%;" height="100%;" />
        </div>
        
        <div style="width:59%; height:69%; float:left;">
        	<label style="color:#DC143C; font-size:140%; margin-left:3%;"><b>Enter your track no here..</b></label>
            
            <input type="text" style="background: white; border: 1px double #DDD; border-radius: 5px; box-shadow: 0 0 5px #333; color: #666; outline: none; height:20%; width:70%; margin-left:3%; margin-top:5%; font-size:18px;" />
            
            <input type="submit" value="Track" style="background: white; border: 1px double #DDD; border-radius: 5px; box-shadow: 0 0 5px #333; color: #666; outline: none; height:20%; width:20%; margin-left:3%; font-size:23px; background-color:#DC143C; color:White;" />
        </div>
    </div>
    
    <div id="slider">
        <div style="width:48%; height:100%; margin-left:1%; float:left; background-color:#CCC;">
        	<img src="../images/s1.jpg" width="100%;" height="100%;" />
        </div>
        
        <div style="width:48%; height:100%; margin-left:2%; float:left; background-color:#CCC;">
			<img src="../images/s4.jpg" width="100%;" height="100%;" />
        </div>
    </div>
    
    <div id="footer">
        
    </div>
</div>
</body>
</html>