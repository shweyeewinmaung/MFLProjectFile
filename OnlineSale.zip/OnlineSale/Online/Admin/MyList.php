<?php
require_once("../library/db.php");
require_once("../dal/dal_customer.php");
require_once("../dal/dal_item.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");
//require_once("../library/permission.php");

$StaffID=2;
$rets=GetItemDataByDeliveryStaff($StaffID);
$nums=mysql_num_rows($rets);
?>
<html>
<head>
</head>
<title>
</title>
<body>
<?php
if($nums>0)
{
	?>
    	<table style="margin:0 auto;">
        	<tr>
            	<td></td>
            	<td>Name</td>
                <td>Phone</td>
                <td>Item</td>
                <td>Remain</td>
                <td>Finished</td>
                <td></td>
            </tr>
            
            <?php
				$i=1;
				while($rows=mysql_fetch_array($rets))
				{
					
					
					$retR=GetItemDataByDeliveryStaffAndProcess($StaffID, "Delivered");
					
					$retc=GetCustomerDataByCustomerID($rows['TCustomer']);
					$rowc=mysql_fetch_array($retc);
					
					$numF=mysql_num_rows($retR);
					
					?>
                    	<tr>
                        	<td><?php echo $i; ?></td>
                        	<td><?php echo $rowc['CustomerName']; ?></td>
                            <td><?php echo $rowc['Phone']; ?></td>
                            <td><?php echo $nums; ?></td>
                            <td><?php echo ($nums - $numF); ?></td>
                            <td><?php echo $numF ?></td>
                            <td><a href="DeliveryDetail.php?CustomerID=<?php echo $rows['FCustomer']; ?>">Check</a></td>
                        </tr>
                    <?php
					$i=$i+1;
				}
			?>
        </table>
    <?php
}
else
{
	
}
?>
</body>
</html>


