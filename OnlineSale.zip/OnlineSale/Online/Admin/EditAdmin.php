<?php
require_once("../library/db.php");
require_once("../dal/dal_admin.php");
require_once("../library/function.php");
require_once("../library/globalfunction.php");
//require_once("../library/permission.php");


if(isset($_POST['FullName']) && isset($_POST['Phone']) && isset($_POST['Email']))
{	
	$AdminID=Clean($_POST['AdminID']);
	$FullName=Clean($_POST['FullName']);
	$Gender=Clean($_POST['Gender']);
	$Phone=Clean($_POST['Phone']);
	$Email=Clean($_POST['Email']);
	$Address=Clean($_POST['Address']);
	$UserName=Clean($_POST['UserName']);
	$Password=Clean($_POST['Password']);
	$Role=Clean($_POST['Role']);
	
	UpdateAdmin($AdminID, $FullName, $Gender, $Email, $Phone, $Address, $Role);
}

if(isset($_GET['AdminID']) && $_GET['AdminID']!="")
{
	$AdminID=Clean($_GET['AdminID']);
	$ret=GetAdminDataByAdminID($AdminID);
	$num=mysql_num_rows($ret);
}
?>
<html>
<head>
</head>
<title>
</title>
<body>

<form method="POST" enctype="multipart/form-data">
	<?php
		if($num>0)
		{
			$row=mysql_fetch_array($ret);
			?>
            	<div style="width:100%">
                <table style="margin:0 auto;">
                    <tr>
                        <th colspan="3"><h1>Add New Admin</h1></th>
                    </tr>
                    <tr>
                    	<td>AdminID</td>
                        <td>:</td>
                        <td><input type="text" name="AdminID" value="<?php echo $row['AdminID']; ?>" style="width:75%" required/></td>
                    </tr>
                    <tr>
                        <td>Full Name</td>
                        <td>:</td>
                        <td><input type="text" name="FullName" value="<?php echo $row['FullName']; ?>" style="width:75%" required/></td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td>:</td>
                        <td><select name="Gender" style="width:75%" >
                            <?php
								if($row['Gender']=="Male")
								{
									?>
                                    	<option>Male</option>
                                        <option>Female</option>
                                    <?php
								}
								else
								{
									?>
                                    	<option>Female</option>
                                        <option>Male</option>
                                    <?php
								}
							?>
                        </select></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td>:</td>
                        <td><input type="text" name="Phone" value="<?php echo $row['Phone']; ?>" style="width:75%" required/></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>:</td>
                        <td><input type="text" name="Email" value="<?php echo $row['Email']; ?>" style="width:75%" required/></td>
                    </tr>
                    <tr>
                        <td valign="top">Address</td>
                        <td valign="top">:</td>
                        <td><textarea name="Address" rows="7" cols="27"><?php echo $row['Address']; ?></textarea></td>
                    </tr>
                    <tr>
                        <td>UserName</td>
                        <td>:</td>
                        <td><input type="text" name="UserName" value="<?php echo $row['UserName']; ?>" style="width:75%" required/></td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td>:</td>
                        <td><input type="Password" name="Password" value="<?php echo $row['Password']; ?>" style="width:75%" required/></td>
                    </tr>
                    <tr>
                        <td>Role</td>
                        <td>:</td>
                        <td><select name="Role" style="width:75%">
                        	<?php
								if($row['Role']=="Delivery")
								{
									?>
                                    	<option>Delivery</option>
                                        <option>Admin</option>
                                        <option>Owner</option>
                                    <?php
								}
								elseif($row['Role']=="Admin")
								{
									?>
                                    	<option>Admin</option>
                                    	<option>Delivery</option>
                                        <option>Owner</option>
                                    <?php
								}
								elseif($row['Role']=="Owner")
								{
									?>
                                    	<option>Owner</option>
                                    	<option>Delivery</option>
                                        <option>Admin</option>
                                    <?php
								}
							?>
                        </select></td>
                    </tr>
                    <tr>
                        <td colspan="2"><br /></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td><input type="submit" value="Update Admin" style="background-color:#144cda;"/></td>
                    </tr>
                    </table>
                    </div>
            <?php
		}
		else
		{
			
		}
	?>
</form>
</body>
</html>


