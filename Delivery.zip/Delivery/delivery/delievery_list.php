<?php
session_start();

require_once("library/connection.php");
require_once("dal/dal_delivery.php");
require_once("dal/dal_receive.php");
require_once("dal/dal_staff.php");
require_once("dal/dal_customer.php");
require_once("dal/dal_deliveryman.php");
require_once("library/autoidfunction.php");
require_once("library/globalfunction.php");
require_once("library/pager_delivery.php");

include("Permission.php");

$UserID=$_SESSION['SESS']['User']['UserID'];



$pageSize=5;



if(isset($_GET['page']))
{
	$currentPageIndex=Clean($_GET['page']);
}
else
{
	$currentPageIndex=1;
}
$objPager=new pager($pageSize,$currentPageIndex);


if(isset($_POST['btnSearch']) )
{
	$Status=Clean($_POST['Status']);
	$FromDate=Clean($_POST['FromDate']);
	$ToDate=Clean($_POST['ToDate']);
	$Keyword=Clean($_POST['Keyword']);
	
	
	$sql=$objPager->SearchData_DeliverySearch($_POST['Status'], $_POST['FromDate'], $_POST['ToDate'], $_POST['Keyword']);
	$ret=$objPager->Search_Data($sql);
	$num=mysql_num_rows($ret)or die(mysql_error());
}

if(!isset($_POST['btnSearch']) )
{
	$Status=Clean($_POST['Status']);
	$FromDate=Clean($_POST['FromDate']);
	$ToDate=Clean($_POST['ToDate']);
	$Keyword=Clean($_POST['Keyword']);
	
	
	$sql=$objPager->SearchData_GetAllDelivery();
	$ret=$objPager->Search_Data($sql);
	$num=mysql_num_rows($ret)or die(mysql_error());
}


?>
<html> 
 <head>
        <title>Delievery</title>
        <meta charset="UTF-8">
      
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width">
        <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
    </head>
    <body>
        <div class="container-fluid bar">
        </div>
        <div class="container">
            <div class="row">
            
                <?php require_once('template/left.php'); ?>
                <font style="color:#006; float:right;"><?php echo "Welcome : ".$_SESSION['SESS']['User']['UserName']; ?> &nbsp; &nbsp;
                      <?php echo $_SESSION['SESS']['User']['Role']; ?></font>
                <div class="col-xs-10">
                
                <form method="post">
                    <div>
                        <div class="col-xs-2">
                            <label>Status</label>
                            <select class="form-control" name="Status">
                            	<option></option>
                                <option>Pending</option>
                                <option>Active</option>
                            </select>
                        </div>

                        <div class="col-xs-3">
                            <label>From Date(Y/M/D)</label>
                            <input type="text" class="form-control pull-left" name="FromDate">
                        </div>
                        <div class="col-xs-3">
                            <label>To Date(Y/M/D)</label>
                            <input type="text" class="form-control" name="ToDate">
                        </div>
                        <div class="col-xs-3">
                            <label>&nbsp;</label>
                            <input type="text" class="form-control" placeholder="keyword.." name="Keyword">
                        </div>
                        <div class="col-xs-1">
                            <button type="submit" class="btn btn-info" style="margin-top:25px;" name="btnSearch">Search</button>
                        </div>
                    </div></form>
                    <div class="clearfix"></div>
                    <table class="table table-bordered table-condensed" style="margin-top:30px;">
                     <?php
					if($num>0)
					{
						?>
                        <tr>
                            <th>No</th>
                            <th>Delivery Code</th>
                            <th>To Customer</th>
                            <th>Address</th>
                            <th>Phone No</th>
                            <th>Qty</th>
                            <th>Cost</th>
                            <th>Delivery Man</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                         <?php
						 $i=1;
						while($row=mysql_fetch_array($ret))
						{
							
						
							?>
                        <tr>
                            <td><?php echo $i ?></td> 
                            <td><?php echo $row['DeliveryCode']; ?></td>
                            <td><?php echo GetCustomerNameByCustomerID($row['6']); ?></td>
                            <td><?php echo $row['Address']; ?></td>
                            <td><?php echo $row['Phone']; ?></td>
                          
                             <?php			
							
							$ret1=GetReceiveDataByCustomerID($row['CustomerID']);
							$row1=mysql_fetch_array($ret1);
															
							?>
                          
                            <td><?php echo $row1['DeliverQty']; ?></td> 
                            <td><?php echo $row['Cost']; ?></td>
                            <td><?php echo GetDeliveryManNameByDeliveryManID($row['8']); ?></td>
                            <td><?php echo $row['Status']; ?></td>
                            <td>
                                <a href="DeliveryUpdate.php?DeliveryCode=<?php echo $row['DeliveryCode']; ?>" class="btn btn-success btn-xs">Edit</a>
                                <a href="DeliveryDelete.php?DeliveryCode=<?php echo $row['DeliveryCode']; ?>" class="btn btn-danger btn-xs">Remove</a>
                                <a href="#" class="btn btn-info btn-xs">Add Keyword</a>

                            </td>
                        </tr>
                          <?php
					$i=$i+1;	}
						
					}
					 else
					{
						?>
                        	<center>Not available!</center>
                        <?php
					}
					
				?>
                       
               
                        
                    </table>
                     <?php
                	$objPager->Generate_Pager($str);
                ?>
            
                </div>
            </div>
        </div>
    </body>
</html>
