<?php
session_start();

require_once("library/connection.php");

require_once("dal/dal_cargate.php");
require_once("library/autoidfunction.php");
require_once("library/globalfunction.php");

include("Permission.php");

$UserID=$_SESSION['SESS']['User']['UserID'];



if (isset($_POST['btnSaveCarGate']) )

{	
	
	$CarGateName=Clean($_POST['CarGateName']);
	$CarGateAddress=Clean($_POST['CarGateAddress']);
	$CarGatePhone=Clean($_POST['CarGatePhone']);
	
	
	
	InsertCarGate($CarGateName, $CarGateAddress,$CarGatePhone);
	
}
?>

 <meta charset="UTF-8">
    <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
        <style>
        .btnstyle1
{
	width:100px;
	background-color:#054f8c;
	color:#000;
	height:30px;
	border: 2px solid#054f8c;
	border-radius:5px;
}
.btnstyle1:hover
{
	background:#95cbf7;
	color:#fff;
	
}

        </style>
   <form method="post">
       <div >
            <div class="modal-dialog" >
                <div class="modal-content">
                    <div class="modal-header">
                  
                       
                        <h4 class="modal-title" id="myModalLabel">Create New Car Gate</h4>
                    </div>
                    <div class="modal-body" style="overflow:hidden">
						
                        <div class="form-group" >
                        <table width="550" style="margin-left:30px;">
                        		<tr height="50" >
                                	<td>Name : </td>
                                    <td><input type="text"  name="CarGateName" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                
                                <tr height="50" >
                                	<td>Phone : </td>
                                    <td><input type="text"  name="CarGatePhone" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr height="110">
                                	<td>Address : </td>
                                    <td><textarea  name="CarGateAddress" style=" height:100px; width:300px; border-radius:5px; border:1px solid#ccc;"></textarea></td>
                                </tr>
                                <tr>
                                <td ></td>
                                <td><div class="modal-footer">
                       <input name="btnSaveCarGate" type="submit" id="submit"  value="Save" class="btnstyle1">
                       <a href = "javascript:void(0)" onclick = "document.getElementById('light1').style.display='none';document.getElementById('fade1').style.display='none'"><input type="reset" id="button" value="Close" class="btnstyle1"></a><br><br>
                        
                    </div></td>
                                </tr>
                        </table>
                       
                            </div>
                        </div>
						
                       
                    </div>
                    
                </div>
            </div>
        </div></form>
       
      
        