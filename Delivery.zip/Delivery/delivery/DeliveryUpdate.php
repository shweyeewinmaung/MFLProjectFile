<?php
session_start();

require_once("library/connection.php");
require_once("dal/dal_delivery.php");
require_once("dal/dal_staff.php");
require_once("dal/dal_shop.php");
require_once("dal/dal_customer.php");
require_once("dal/dal_deliveryman.php");
require_once("dal/dal_cargate.php");
require_once("library/autoidfunction.php");
require_once("library/globalfunction.php");

include("Permission.php");

$UserID=$_SESSION['SESS']['User']['UserID'];


if (isset($_POST['btnUpdate']) )

{	
	
	$DeliveryCode=Clean($_POST['DeliveryCode']);
	$DeliveryEntry=date("Y/m/d");
	
	$ToD=Clean($_POST['ToD']);
	$Address=Clean($_POST['Address']);
	$Keyword=Clean($_POST['Keyword']);
	$DeliveryType=Clean($_POST['DeliveryType']);
	$StaffName=Clean($_POST['Staff']);
	
	$retS=GetStaffDataByStaffName($StaffName);
	$rowS=mysql_fetch_array($retS);
	$StaffID=$rowS['0'];
	
	
	
	
	$CustomerName=Clean($_POST['Customer']);
	
	$retC=GetCustomerDataByCustomerName($CustomerName);
	$rowC=mysql_fetch_array($retC);
	$CustomerID=$rowC['0'];
	
	
	$DeliveryManName=Clean($_POST['DeliveryMan']);
	
	
	
	$retD=GetDeliveryManDataByDeliveryManName($DeliveryManName);
	$rowD=mysql_fetch_array($retD);
	$DeliveryManID=$rowD['0'];
	
	$CarGateName=Clean($_POST['CarGate']);
	
	$retCG=GetCarGateDataByCarGateName($CarGateName);
	$rowCG=mysql_fetch_array($retCG);
	$CarGateID=$rowCG['0'];
	
	$ShopName=Clean($_POST['Shop']);
	
	$retH=GetShopDataByShopName($ShopName);
	$rowH=mysql_fetch_array($retH);
	$ShopID=$rowH['0'];
	
	$Phone=Clean($_POST['Phone']);
	$VoucherNo=Clean($_POST['VoucherNo']);
	$Cost=Clean($_POST['Cost']);
	$Status=Clean($_POST['Status']);
	$Remark=Clean($_POST['Remark']);
	
	
	UpdateDelivery($DeliveryCode,$DeliveryEntry,$ToD, $Address, $Keyword, $DeliveryType, $StaffID,$CustomerID,$DeliveryManID, $CarGateID,$ShopID,$Phone,$VoucherNo,$Cost,$Status,$Remark);
	$msg="Successfully Delivery Updated";
}
if (isset($_GET['DeliveryCode']) && $_GET['DeliveryCode']!="")
{
	$DeliveryCode=Clean($_GET['DeliveryCode']);
	$ret=GetDeliveryDataByDeliveryCode($DeliveryCode);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
}


?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Delivery</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
       
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
       <style>
       .black_overlay{
        display: none;
        position: fixed;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: black;
        z-index:1001;
        -moz-opacity: 0.8;
        opacity:.80;
        filter: alpha(opacity=80);
    }
	
    .white_content {
        display: none;
        position: fixed;
        top: 25%;
        left: 25%;
        width: 800px;
        height: 400px;
        padding: 16px;
        border:10px solid #054f8c;
        background-color: white;
        z-index:1002;
        overflow: auto;
    }
	 .black_overlay1{
        display: none;
        position: fixed;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: black;
        z-index:1001;
        -moz-opacity: 0.8;
        opacity:.80;
        filter: alpha(opacity=80);
    }
	
    .white_content1 {
        display: none;
        position: fixed;
        top: 6%;
        left: 25%;
        width: 800px;
        height: 550px;
        padding: 16px;
        border:10px solid #054f8c;
        background-color: white;
        z-index:1002;
        overflow: auto;
    }
	 .black_overlay2{
        display: none;
        position: fixed;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: black;
        z-index:1001;
        -moz-opacity: 0.8;
        opacity:.80;
        filter: alpha(opacity=80);
    }
	
    .white_content2 {
        display: none;
        position: fixed;
        top: 6%;
        left: 25%;
        width: 800px;
        height: 550px;
        padding: 16px;
        border:10px solid #054f8c;
        background-color: white;
        z-index:1002;
        overflow: auto;
    }
	 .black_overlay3{
        display: none;
        position: fixed;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: black;
        z-index:1001;
        -moz-opacity: 0.8;
        opacity:.80;
        filter: alpha(opacity=80);
    }
	
    .white_content3 {
        display: none;
        position: fixed;
        top: 6%;
        left: 25%;
        width: 800px;
        height: 550px;
        padding: 16px;
        border:10px solid #054f8c;
        background-color: white;
        z-index:1002;
        overflow: auto;
    }
	.black_overlay4{
        display: none;
        position: fixed;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: black;
        z-index:1001;
        -moz-opacity: 0.8;
        opacity:.80;
        filter: alpha(opacity=80);
    }
	
    .white_content4 {
        display: none;
        position: fixed;
        top: 5%;
        left: 25%;
        width: 800px;
        height: 550px;
        padding: 16px;
        border:10px solid #054f8c;
        background-color: white;
        z-index:1002;
        overflow: auto;
    }
	
	
       </style> 
    </head>
    <body>
        <div class="container-fluid bar">
        </div>
        <div class="container">

            <div class="row">
                <?php require_once('template/left.php'); ?>
                <font style="color:#006; margin-left:-180px;"><?php echo "Welcome : ".$_SESSION['SESS']['User']['UserName']; ?> &nbsp; &nbsp;
                      <?php echo $_SESSION['SESS']['User']['Role']; ?></font>
                <form class="form-horizontal col-xs-6" method="post">
                    <h4>Update Delivery Form</h4>
                    <div class="panel panel-default">
                        <div class="panel-body">
						<font style="color:red;"><?php echo $msg; ?></font>
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Code</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" value="<?php echo $row['DeliveryCode']; ?>"  name="DeliveryCode" readonly >
                                </div>
                            </div>
                               <!-- if customer -->
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Customer</label>
                                <div class="col-xs-5">
                                                              
                                
                                 
                                    
                                      <select class="form-control" name="Customer" style="width:210px; ">
	  								
	   									<option><?php echo GetCustomerNameByCustomerID($row['6']); ?></option>
	  									 <?php 
	   										$sql="select * from tbl_customer";
											echo $sql;
			
           								  $ret= mysql_query($sql);
            							 while($rowsd=mysql_fetch_array($ret)){?>
          							<option ><?php echo $rowsd['CustomerName'];?></option>
          <?php }?>
	   
		   </select>
                                </div>
                                <div class="col-xs-1">
                                
                                <a  href="javascript:void(0)" class="btn btn-success" data-toggle="modal" data-target="#staffpopup" onclick = "document.getElementById('light2').style.display='block';document.getElementById('fade2').style.display='block'"  >Create Customer</a> 
								    <div id="light2" class="white_content2"> <?php require_once('CustomerEntry.php'); ?>  
                                                                   
                                    </div>
    <div id="fade2" class="black_overlay2"></div>



                       
                        
                   
            
                                    
                                           
                                        
                             
                            </div>
                            <!-- end if delivery Man-->
                            
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">To</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="ToD" value="<?php echo $row['ToD']; ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-xs-3">Address</label>
                                <div class="col-xs-8">
                                    <textarea class="form-control" name="Address"><?php echo $row['Address']; ?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Keywords</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="Keyword" value="<?php echo $row['Keyword']; ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Delivery Type</label>
                                <div class="col-xs-8">
                                    <select class="form-control" name="DeliveryType">
                                        <option><?php echo $row['DeliveryType']; ?></option>
                                        <option>Staff</option>
                                        <option>Car</option>
                                    </select>
                                </div>
                            </div>

                            <!-- if staff -->
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Staff</label>
                                <div class="col-xs-5">
                                                              
                                
                                 
                                    
                                      <select class="form-control" name="Staff" style="width:210px;">
                                      <option><?php echo GetStaffNameByStaffID($row['5']); ?></option>
                                       <?php
                                        $ret1=getAllStaffData();
                                        
                                        while($row1=mysql_fetch_array($ret1))
                                        {
                                            echo "<option>" . $row1['StaffName'] . "</option>";
                                        }
                                    ?>
	  								
	   									
	   
		   </select>
                                </div>
                                <div class="col-xs-1">
                                
                                <a  href="javascript:void(0)" class="btn btn-success" data-toggle="modal" data-target="#staffpopup" onclick = "document.getElementById('light').style.display='block';document.getElementById('fade').style.display='block'" >Create New Staff</a> 
								    <div id="light" class="white_content"> <?php require_once('StaffEntry.php'); ?>  
                                                                   
                                    </div>
    <div id="fade" class="black_overlay"></div>



                       
                        
                   
            
                                    
                                           
                                        
                                     
                                </div>
                            </div>
                            <!-- end if staff -->
                            
                           
                            
                             <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">DeliveryMan</label>
                                <div class="col-xs-5">
                                                              
                                
                                 
                                    
                                      <select class="form-control" name="DeliveryMan" style="width:210px; margin-left:10px;">
	  									<option><?php echo GetDeliveryManNameByDeliveryManID($row['7']); ?></option>
	   
	  									 <?php 
	   										$sql="select * from tbl_deliveryman";
											echo $sql;			
           								  $ret2= mysql_query($sql);
            							 while($rowsd2=mysql_fetch_array($ret2)){?>
          							<option  ><?php echo $rowsd2['DeliveryManName'];?></option>
          <?php }?>
	   
		   </select>
                                </div>
                                <div class="col-xs-1">
                                
                                <a  href="javascript:void(0)" class="btn btn-success" data-toggle="modal" data-target="#staffpopup" onclick = "document.getElementById('light3').style.display='block';document.getElementById('fade3').style.display='block'"  >Create DeliveryMan</a> 
								    <div id="light3" class="white_content3"> <?php require_once('DeliveryManEntry.php'); ?>  
                                                                   
                                    </div>
    <div id="fade3" class="black_overlay3"></div>



                       
                        
                   
            
                                    
                                           
                                        
                             
                            </div>
                            <!-- end if delivery Man -->
                            <!-- start if car -->
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Car Gate</label>
                                <div class="col-xs-5">
                                 
                                    
                                    
                                 <select class="form-control" name="CarGate" style="margin-left:10px;">
	  								
	   								<option><?php echo GetCarGateNameByCarGate($row['7']); ?></option>
	  									 <?php 
	   										$sql="select * from tbl_cargate";
											echo $sql;
           								  $ret3= mysql_query($sql);
            							 while($rowsd3=mysql_fetch_array($ret3)){?>
          							<option ><?php echo $rowsd3['CarGateName'];?></option>
          <?php }?>
	   
		   </select>
                                </div>
                                
                                
                                <div class="col-xs-1">
                                    
                                 	<a  href="javascript:void(0)" class="btn btn-success" data-toggle="modal" data-target="#carpopup" onclick = "document.getElementById('light1').style.display='block';document.getElementById('fade1').style.display='block'" >Create New Gate</a> 
								    <div id="light1" class="white_content1"> <?php require_once('CarGateEntry.php'); ?></div>
    								<div id="fade1" class="black_overlay1"></div>


                                    
                                    
                              
                                
                                
                                
                                
                                
                                
                                
                                
                                
                            </div>
                             <!-- if shop start -->
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Shop</label>
                                <div class="col-xs-5">
                                                              
                                
                                 
                                    
                                      <select class="form-control" name="Shop" style="width:210px; margin-left:10px;">
	  								
	   									<option><?php echo GetShopNameByShopID($row['8']); ?></option>
	  									 <?php 
	   										$sql="select * from tbl_shop";
											echo $sql;
			
           								  $ret4= mysql_query($sql);
            							 while($rowsd4=mysql_fetch_array($ret4)){?>
          							<option ><?php echo $rowsd4['ShopName'];?></option>
          <?php }?>
	   
		   </select>
                                </div>
                                <div class="col-xs-1">
                                
                                <a  href="javascript:void(0)" class="btn btn-success" data-toggle="modal" data-target="#staffpopup" onclick = "document.getElementById('light4').style.display='block';document.getElementById('fade4').style.display='block'" >Create New Shop</a> 
								    <div id="light4" class="white_content4"> <?php require_once('ShopEntry.php'); ?>  
                                                                   
                                    </div>
    <div id="fade4" class="black_overlay4"></div>



                       
                        
                   
            
                                    
                                           
                                        
                                     
                                
                            </div>
                            <!-- end shop end -->
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Contact Ph:</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="Phone" value="<?php echo $row['Phone']; ?>"> 
                                </div>

                            </div>

                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Voucher No</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="VoucherNo" value="<?php echo $row['VoucherNo']; ?>"> 
                                </div>

                            </div>
                            <!-- end car -->


                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Cost</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="Cost" value="<?php echo $row['Cost']; ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Status</label>
                                <div class="col-xs-8">
                                    <select class="form-control" name="Status" >
                                    	<option><?php echo $row['Status']; ?></option>
                                        <option>Pending</option>
                                        <option>Active</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Remark</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="Remark" value="<?php echo $row['Remark']; ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-xs-offset-3 col-xs-8">
                                    <button type="submit" class="btn btn-primary" name="btnUpdate">Update</button>
                                    <button type="reset" class="btn btn-default">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    
    </body>
</html>
