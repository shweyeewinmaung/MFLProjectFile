<?php
session_start();

require_once("library/connection.php");
require_once("dal/dal_delivery.php");
require_once("dal/dal_receive.php");
require_once("dal/dal_staff.php");
require_once("dal/dal_shop.php");
require_once("dal/dal_customer.php");
require_once("dal/dal_deliveryman.php");
require_once("library/autoidfunction.php");
require_once("library/globalfunction.php");
require_once("library/pager_delivery.php");

include("Permission.php");

$UserID=$_SESSION['SESS']['User']['UserID'];

$pageSize=5;



if(isset($_GET['page']))
{
	$currentPageIndex=Clean($_GET['page']);
}
else
{
	$currentPageIndex=1;
}
$objPager=new pager($pageSize,$currentPageIndex);

if(isset($_POST['btnShopSearch']) )
{
	
	$Shop=Clean($_POST['Shop']);
	
	$Keyword=Clean($_POST['Keyword']);
	
	
	$sql=$objPager->SearchData_ShopSearch($_POST['Shop'], $_POST['Keyword']);
	
	$ret=$objPager->Search_Data($sql);
	
	$num=mysql_num_rows($ret)or die(mysql_error());
	
}

if(!isset($_POST['btnShopSearch']) )
{
	
	$Shop=Clean($_POST['Shop']);
	
	$Keyword=Clean($_POST['Keyword']);
	
	
	
	$sql=$objPager->SearchData_GetAllShop();
	$ret=$objPager->Search_Data($sql);

	$num=mysql_num_rows($ret)or die(mysql_error());
	
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Delivery</title>
        <meta charset="UTF-8">
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width">
        <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
    </head>
    <body>
        <div class="container-fluid bar">
        </div>
        <div class="container">
            <div class="row">
                <?php require_once('template/left.php'); ?>
                <font style="color:#006; float:right;"><?php echo "Welcome : ".$_SESSION['SESS']['User']['UserName']; ?> &nbsp; &nbsp;
                      <?php echo $_SESSION['SESS']['User']['Role']; ?></font>
                <div class="col-xs-10">
                 <form method="post">
                    <div>
                        <div class="col-xs-2">
                            <label>Shop</label>
                            <select class="form-control" name="Shop" >
                               <option></option>
                		<?php
						$retS=getAllShopData();
						
						while($rowS=mysql_fetch_array($retS))
						{
							echo "<option>" . $rowS['ShopName'] . "</option>";
						}
					?>
                            </select>
                        </div>
                        <div class="col-xs-3">
                            <label>&nbsp;</label>
                            <input type="text" class="form-control" placeholder="keyword.." name="Keyword">
                        </div>
                        <div class="col-xs-1">
                            <button type="submit" class="btn btn-info" style="margin-top:25px;" name="btnShopSearch">Search</button>
                        </div>
                    </div>
                    </form>
                    <div class="clearfix"></div>
                    <table class="table table-bordered table-condensed" style="margin-top:30px;">
                       <?php
					if($num>0)
					{
						?>
                        <tr>
                            <th>No</th>
                            <th>Delivery Code</th>
                            <th>To Customer</th>
                            <th>Address</th>
                            <th>Phone No</th>
                            <th>Qty</th>
                            <th>Cost</th>
                            <th>Dev Man</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        <?php
						
                        while($row=mysql_fetch_array($ret))
                        {
							 ?> 
                              <tr>
                            	<td colspan="10">
                                	<label><?php echo $row['ShopName']; ?></label>
                            	</td>
                       		</tr>
                             <?php			
							 $i=1;
							 $ret1=GetDeliveryDataByShopID($row['ShopID']);
							
							?>
							<?php if($_POST['Shop']=="" && $_POST['Keyword']=="")
								{	
									
								
								
									while($rowd=mysql_fetch_array($ret1))
									{	
							?>
                                    	                                 
										<tr>
											<td><?php echo $i; ?></td>
											<td><?php echo $rowd['DeliveryCode']; ?></td>
                                        
											<td><?php echo GetCustomerNameByCustomerID($rowd['CustomerID']); ?></td>
											<td><?php echo $rowd['Address']; ?></td>
											<td><?php echo $rowd['Phone']; ?></td>
											<?php			
												$ret2=GetReceiveDataByCustomerID($rowd['CustomerID']);
												$row2=mysql_fetch_array($ret2);
											?>
											<td><?php echo $row2['DeliverQty']; ?></td>
											<td><?php echo $rowd['Cost']; ?></td>
											<td><?php echo GetDeliveryManNameByDeliveryManID($rowd['DeliveryManID']);?></td>
											<td><?php echo $rowd['Status']; ?></td>
											<td>
												<a href="ShopUpdate.php?ShopID=<?php echo $rowd['ShopID']; ?>" class="btn btn-success btn-xs">Edit</a>
												<a href="ShopDelete.php?ShopID=<?php echo $rowd['ShopID']; ?>" class="btn btn-danger btn-xs">Remove</a>
												<a href="#" class="btn btn-info btn-xs">Add Keyword</a>
											</td>
										 </tr>
										<?php
										$i+=1;
									}
								// }
							 
								}
							
							if($_POST['Shop']!="" && $_POST['Keyword']=="")
							{
								
								$sqld="SELECT * FROM tbl_delivery WHERE ShopID='" . $row['ShopID'] . "'";
								$retd=mysql_query($sqld);
								$i=1;
								while($rowd=mysql_fetch_array($retd))
								{
									?>
                                    	
										<tr>
											<td><?php echo $i ?></td>
											<td><?php echo $rowd['DeliveryCode']; ?></td>
											<td><?php echo GetCustomerNameByCustomerID($rowd['6']); ?></td>
											<td><?php echo $rowd['Address']; ?></td>
											<td><?php echo $rowd['Phone']; ?></td>
											<?php			
												$ret2=GetReceiveDataByCustomerID($rowd['CustomerID']);
												$row2=mysql_fetch_array($ret2);
											?>
											<td><?php echo $row2['DeliverQty']; ?></td>
											<td><?php echo $rowd['Cost']; ?></td>
											<td><?php echo GetDeliveryManNameByDeliveryManID($rowd['DeliveryManID']); ?></td>
											<td><?php echo $rowd['Status']; ?></td>
											<td>
												<a href="ShopUpdate.php?ShopID=<?php echo $rowd['ShopID']; ?>" class="btn btn-success btn-xs">Edit</a>
												<a href="ShopDelete.php?ShopID=<?php echo $rowd['ShopID']; ?>" class="btn btn-danger btn-xs">Remove</a>
												<a href="#" class="btn btn-info btn-xs">Add Keyword</a>
											</td>
										</tr>
									<?php $i+=1;
								}
								
							}
							
							
							if($_POST['Shop']=="" && $_POST['Keyword']!="")
							{
								$sqld="SELECT * FROM tbl_delivery WHERE Keyword='" . $row['Keyword'] . "'";
								
								$retd=mysql_query($sqld);
								$i=1;
								while($rowd=mysql_fetch_array($retd))
								{
									?>
										<tr>
											<td><?php echo $i ?></td>
											<td><?php echo $rowd['DeliveryCode']; ?></td>
											<td><?php echo GetCustomerNameByCustomerID($rowd['6']); ?></td>
											<td><?php echo $rowd['Address']; ?></td>
											<td><?php echo $rowd['Phone']; ?></td>
											<?php			
												$ret2=GetReceiveDataByCustomerID($rowd['CustomerID']);
												$row2=mysql_fetch_array($ret2);
											?>
											<td><?php echo $row2['DeliverQty']; ?></td>
											<td><?php echo $rowd['Cost']; ?></td>
											<td><?php echo GetDeliveryManNameByDeliveryManID($rowd['DeliveryManID']); ?></td>
											<td><?php echo $rowd['Status']; ?></td>
											<td>
												<a href="ShopUpdate.php?ShopID=<?php echo $rowd['ShopID']; ?>" class="btn btn-success btn-xs">Edit</a>
												<a href="ShopDelete.php?ShopID=<?php echo $rowd['ShopID']; ?>" class="btn btn-danger btn-xs">Remove</a>
												<a href="#" class="btn btn-info btn-xs">Add Keyword</a>
											</td>
										</tr>
									<?php $i+=1;
								}
								
							}
							
							
							
							if($_POST['Shop']!="" && $_POST['Keyword']!="")
							{
								
								$sqld="SELECT sh.* ,d.* FROM `tbl_shop` sh, `tbl_delivery` d WHERE sh.ShopID=d.ShopID AND sh.ShopName LIKE '%" . $row['ShopName'] . "%' AND d.Keyword = '" . $row['Keyword'] . "'";
								
								$retd=mysql_query($sqld);
								$i=1;
								while($rowd=mysql_fetch_array($retd))
								{
									?>
										<tr>
											<td><?php echo $i ?></td>
											<td><?php echo $rowd['DeliveryCode']; ?></td>
											<td><?php echo GetCustomerNameByCustomerID($rowd['CustomerID']); ?></td>
											<td><?php echo $rowd['Address']; ?></td>
											<td><?php echo $rowd['Phone']; ?></td>
											<?php			
												$ret2=GetReceiveDataByCustomerID($rowd['CustomerID']);
												$row2=mysql_fetch_array($ret2);
											?>
											<td><?php echo $row2['DeliverQty']; ?></td>
											<td><?php echo $rowd['Cost']; ?></td>
											<td><?php echo GetDeliveryManNameByDeliveryManID($rowd['DeliveryManID']); ?></td>
											<td><?php echo $rowd['Status']; ?></td>
											<td>
												<a href="ShopUpdate.php?ShopID=<?php echo $rowd['ShopID']; ?>" class="btn btn-success btn-xs">Edit</a>
												<a href="ShopDelete.php?ShopID=<?php echo $rowd['ShopID']; ?>" class="btn btn-danger btn-xs">Remove</a>
												<a href="#" class="btn btn-info btn-xs">Add Keyword</a>
											</td>
										</tr>
									<?php $i+=1;
								}
								
							} 
							
							
					
					
						
					
				
                     
                        }
						
					}
						
						    
						
						 
						?>
                          
							
                    </table>
                      <?php
                	$objPager->Generate_Pager($str);
                ?>
                </div>
            </div>
        </div>
    </body>
</html>
