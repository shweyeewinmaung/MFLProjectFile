<?php
session_start();

require_once("library/connection.php");

require_once("dal/dal_shop.php");
require_once("library/autoidfunction.php");
require_once("library/globalfunction.php");

include("Permission.php");

$UserID=$_SESSION['SESS']['User']['UserID'];



if(isset($_POST['btnDelete']) && isset($_POST['ShopID']) !="")
{	 
	$ShopID=Clean($_POST['ShopID']);
	$ShopName=Clean($_POST['ShopName']);
	$Phone=Clean($_POST['Phone']);
	$Email=Clean($_POST['Email']);
	$ShopAddress=Clean($_POST['ShopAddress']);
	
	DeleteShop($ShopID,$ShopName, $Phone,$Email,$ShopAddress);
	print "<script language=\"JavaScript\">window.location.href=\"shop_list.php \";</script>";
	
}
if (isset($_GET['ShopID']) && $_GET['ShopID']!="")
{
	$ShopID=Clean($_GET['ShopID']);
	$ret=GetShopDataByShopID($ShopID);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
}
?>

<html>
    <head>
        <title>Delievery</title>
        <meta charset="UTF-8">
       <!-- <script type="text/javascript" src="js/jquery.min.js"></script>-->
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width">
        <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
          <style>
       <meta charset="UTF-8">
    <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
        <style>
        .btnstyle
{
	width:100px;
	background-color:#054f8c;
	color:#000;
	height:30px;
	border: 2px solid#054f8c;
	border-radius:5px;
}
.btnstyle:hover
{
	background:#95cbf7;
	color:#fff;
	
}

        </style>

    </head>
    <body>
        <div class="container-fluid bar">
        </div>
        <div class="container">

            <div class="row">
                <?php require_once('template/left.php'); ?>
                <font style="color:#006; margin-left:-180px;"><?php echo "Welcome : ".$_SESSION['SESS']['User']['UserName']; ?> &nbsp; &nbsp;
                      <?php echo $_SESSION['SESS']['User']['Role']; ?></font>
                <form class="form-horizontal col-xs-6" method="post">
                    <h4>Shop Delete</h4>
                    <div class="panel panel-default" style="width: 570px;">
                        <div class="panel-body">
				
								<font style="color:red;"><?php echo $msg; ?></font>
                            
                             <table width="550" style="margin-left:5px;">
                        		<tr height="50"  >
                                	<td>ID : </td>
                                    <td><input type="text"  readonly value="<?php echo $row['ShopID']; ?>" name="ShopID" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                        		 	<td>Name : </td>
                                    <td><input type="text"  name="ShopName" value="<?php echo $row['ShopName']; ?>" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                  <tr height="50" >
                                	<td>Phone : </td>
                                    <td><input type="text"  name="Phone" value="<?php echo $row['Phone']; ?>" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr height="50" >
                                	<td>Email : </td>
                                    <td><input type="text"  name="Email" value="<?php echo $row['Email']; ?>" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr height="100" >
                                	<td>Address : </td>
                                    <td><textarea name="ShopAddress" style="height:55px; width:300px; border-radius:5px; border:1px solid#ccc;"><?php echo $row['ShopAddress']; ?></textarea></td>
                                </tr>
                                <tr>
                                <td ></td>
                                <td><div class="modal-footer">
                       <input name="btnDelete" type="submit" value="Delete" class="btnstyle">
                       <input type="reset" id="button" value="Cancel" class="btnstyle"><br><br>
                        
                    </div></td>
                                </tr>
                        </table>
                           


                            
                            
                        </div>
                    </div>
                </form>
            </div>
        </div>

      
    </body>
</html>
