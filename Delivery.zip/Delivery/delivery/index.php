<?php
session_start();
require_once("library/connection.php");
require_once("dal/dal_receive.php");
require_once("library/autoidfunction.php");
require_once("library/globalfunction.php");

include("Permission.php");

$UserID=$_SESSION['SESS']['User']['UserID'];

if (isset($_POST['submit']) )

{	
	$ReceiveID=AutoID('tbl_receive','ReceiveID','R-',6);
	$Customer=Clean($_POST['Customer']);
	$Address=Clean($_POST['Address']);
	$TotalQty=Clean($_POST['TotalQty']);
	$DeliverQty=Clean($_POST['DeliverQty']);
	$TakingQty=Clean($_POST['TakingQty']);
	
	
	
	InsertReceive($ReceiveID, $Customer, $Address, $TotalQty, $DeliverQty, $TakingQty);
	$msg="Successfully Receive Save";
}
?>
<html>
 <head>
        <title>Delievery</title>
        <meta charset="UTF-8">
      
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width">
        <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
        

        <style>
       .black_overlay2{
        display: none;
        position: fixed;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: black;
        z-index:1001;
        -moz-opacity: 0.8;
        opacity:.80;
        filter: alpha(opacity=80);
    }
	
    .white_content2 {
        display: none;
        position: fixed;
        top: 10%;
        left: 25%;
        width: 800px;
        height: 470px;
        padding: 16px;
        border:10px solid #054f8c;
        background-color: white;
        z-index:1002;
        overflow: auto;
    }</style>
     </head>
    <body>
        <div class="container-fluid bar">
        </div>
        <div class="container">

            <div class="row">
                 <?php require_once('template/left.php'); ?>
                <font style="color:#006; margin-left:-180px;"><?php echo "Welcome : ".$_SESSION['SESS']['User']['UserName']; ?> &nbsp; &nbsp;
                      <?php echo $_SESSION['SESS']['User']['Role']; ?></font>
                <form class="form-horizontal col-xs-6" method="post">
                    <h4>Received Form</h4>
                 
                    <div class="panel panel-default">
                        <div class="panel-body">
				
								<font style="color:red;"><?php echo $msg; ?></font>
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">From</label>
                                <div class="col-xs-5">
                                 
                                    
                                    
                                        <select class="form-control" name="Customer" style="width:220px; margin-left:-10px; ">
	  								
	   
	  									 <?php 
	   										$sql="select * from tbl_customer";
											echo $sql;
			
           								  $ret= mysql_query($sql);
            							 while($rowsd=mysql_fetch_array($ret)){?>
          							<option value="<?php echo $rowsd['CustomerID'];?>" ><?php echo $rowsd['CustomerName'];?></option>
          <?php }?>
	   
		   </select>
                                </div>
                                <div class="col-xs-1">
                                
                                <a  href="javascript:void(0)" class="btn btn-success" data-toggle="modal" data-target="#staffpopup" onclick = "document.getElementById('light2').style.display='block';document.getElementById('fade2').style.display='block'"  >Create Customer</a> 
								    <div id="light2" class="white_content2"> <?php require_once('CustomerEntry.php'); ?>  
                                                                   
                                    </div>
    <div id="fade2" class="black_overlay2"></div>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-xs-3">Address</label>
                                <div class="col-xs-8">
                                    <textarea class="form-control" name="Address"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Total Qty</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="TotalQty">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Deliever Qty</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="DeliverQty">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Taking Qty</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="TakingQty">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-xs-offset-3 col-xs-8">
                                    <button type="submit" class="btn btn-primary" name="submit">Save</button>
                                    <button  class="btn btn-default"  type="reset">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- start from popup -->
        <div class="modal fade" id="frommodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Create From</h4>
                    </div>
                    <div class="modal-body" style="overflow:hidden">

                        <div class="form-group" style="overflow:hidden">
                            <label for="inputEmail" class="control-label col-xs-3">Name</label>
                            <div class="col-xs-8">
                                <input type="text" class="form-control">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputEmail" class="control-label col-xs-3">Address</label>
                            <div class="col-xs-8">
                                <textarea class="form-control"></textarea>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" name="submit">Save</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- end from popup -->
    </body>

</html>