<?php
class pager
{
	public $pageSize,$currentPageIndex;
	public $offset,$maxPage;
	public $totalRecordCount;
	
	//Constructor
	function __construct($pageSize,$currentPageIndex)
	{
		//Page Size
		$this->pageSize=$pageSize;
		//by default we show first page
		$this->currentPageIndex=$currentPageIndex;		
		//counting the offset
		$this->offset=($currentPageIndex-1)*$pageSize;
	}	

	
	//////////////////////One Start///////////////////////////
/*	
	function SearchData_Status($Status)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE Status LIKE '%$Status%' ORDER BY DeliveryCode";
		return $sql;
	}
	
	function SearchData_FromDate($FromDate)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE DeliveryEntry LIKE '%$FromDate%' ORDER BY DeliveryCode";
		return $sql;
	}
	function SearchData_ToDate($ToDate)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE DeliveryEntry LIKE '%$ToDate%' ORDER BY DeliveryCode";
		return $sql;
	}
	function SearchData_AddKeyword($Keyword)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE Keyword LIKE '%$Keyword%' ORDER BY DeliveryCode";
		return $sql;
	}
	
		
		
	//////////////////////One End/////////////////////////////
	
	/////////////////////////// Two Start ///////////////////////////

	function SearchData_StatusAndFromDate($Status, $FromDate)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE Status LIKE '%$Status%' AND DeliveryEntry LIKE '%$FromDate%' ORDER BY DeliveryCode";
		return $sql;
	}
	function SearchData_StatusAndToDate($Status, $ToDate)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE Status LIKE '%$Status%' AND DeliveryEntry LIKE '%$ToDate%' ORDER BY DeliveryCode";
		return $sql;
	}
	function SearchData_StatusAndAddKeyword($Status, $Keyword)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE Status LIKE '%$Status%' AND Keyword LIKE '%$Keyword%' ORDER BY DeliveryCode";
		return $sql;
	}
	function SearchData_FromDateAndToDate($FromDate, $ToDate)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE DeliveryEntry LIKE '%$FromDate%' AND DeliveryEntry LIKE '%$ToDate%' ORDER BY DeliveryCode";
		return $sql;
	}
	function SearchData_FromDateAndAddKeyword($FromDate, $Keyword)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE DeliveryEntry LIKE '%$FromDate%' AND Keyword LIKE '%$Keyword%' ORDER BY DeliveryCode";
		return $sql;
	}
	function SearchData_ToDateAndAddKeyword($ToDate, $Keyword)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE DeliveryEntry LIKE '%$ToDate%' AND Keyword LIKE '%$Keyword%' ORDER BY DeliveryCode";
		return $sql;
	}
	/////////////////////////// Two End ///////////////////////////
	
	/////////////////////////// Three Start///////////////////////////

	function SearchData_StatusAndFromDateAndToDate($Status, $FromDate, $ToDate)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE Status LIKE '%$Status%' AND DeliveryEntry LIKE '%$FromDate%' AND DeliveryEntry LIKE '%$ToDate%' ORDER BY DeliveryCode";
		return $sql;
	}
	function SearchData_StatusAndFromDateAndAddKeyword($Status, $FromDate, $Keyword)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE Status LIKE '%$Status%' AND DeliveryEntry LIKE '%$FromDate%' AND Keyword LIKE '%$Keyword%' ORDER BY DeliveryCode";
		return $sql;
	}
	function SearchData_StatusAndToDateAndAddKeyword($Status, $ToDate, $Keyword)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE Status LIKE '%$Status%' AND DeliveryEntry LIKE '%$ToDate%' AND Keyword LIKE '%$Keyword%' ORDER BY DeliveryCode";
		return $sql;
	}
	function SearchData_FromDateAndToDateAndAddKeyword($FromDate, $ToDate, $Keyword)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE DeliveryEntry LIKE '%$FromDate%' AND DeliveryEntry LIKE '%$ToDate%' AND Keyword LIKE '%$Keyword%' ORDER BY DeliveryCode";
		return $sql;
	}
	/////////////////////////// Three End///////////////////////////
	
	/////////////////////////// Four Start///////////////////////////
	
	function SearchData_StatusAndFromDateAndToDateAndKeyword($Status, $FromDate, $ToDate, $Keyword)
	{
		$sql="SELECT * FROM `tbl_delivery` WHERE Status LIKE '%$Status%' AND DeliveryEntry LIKE '%$FromDate%' AND DeliveryEntry LIKE '%$ToDate%' AND Keyword LIKE '%$Keyword%' ORDER BY DeliveryCode";
		return $sql;
	}
	/////////////////////////// Four End///////////////////////////
	
	/////////////////////////// All Delivery Start///////////////////////////
	
	function SearchData_GetAllDelivery()
	{
		$sql="SELECT * FROM `tbl_delivery` ORDER BY DeliveryCode DESC ";
		return $sql;
	}
	
	/////////////////////////// All Delivery End ///////////////////////////
	
	
	/////////////////////////// Delivery Search Start ///////////////////////////*/
	
	function SearchData_DeliverySearch($Status, $FromDate, $ToDate, $Keyword)
	{
		$S="";
		$F="";
		$T="";
		$K="";
		
		$OrderBy=" ORDER BY DeliveryCode";
		
		if($Status!="")
		{
			$S="Status LIKE '%$Status%' ";
		}
	
		
		
		if($FromDate!="" )
		{	
			if($ToDate!="")
			{
				if($S!="" )
				{
					$F=" AND DeliveryEntry  BETWEEN '$FromDate' AND '$ToDate' ";
				}
				else
				{
					$F="  DeliveryEntry  BETWEEN '$FromDate' AND '$ToDate' ";
				}
			}
			elseif($ToDate=="")
			{
				if($S!="" )
				{
					$F=" AND DeliveryEntry LIKE '%$FromDate%' ";
				}
				else
				{
					$F="  DeliveryEntry LIKE '%$FromDate%' ";
				}
			}
		
		
		
		}
		
		
		if($Keyword!="")
		{
			if($S!="" || $F!="" || $T!="")
			{
				$K="AND Keyword LIKE '%$Keyword%' ";
			}
			elseif($S=="" && $F=="" && $T=="")
			{
				$K="Keyword LIKE '%$Keyword%' ";
			}
		}
		
		
		
		$sql="SELECT * FROM `tbl_delivery` WHERE $S $F $T $K ";
		return $sql;
	}
	
	/////////////////////////// Delivery Search End ///////////////////////////

	/////////////////////////// All Delivery Start///////////////////////////
	
	function SearchData_GetAllDelivery()
	{
		$sql="SELECT * FROM `tbl_delivery` ORDER BY DeliveryCode ASC ";
		return $sql;
	}
	
	/////////////////////////// All Delivery End ///////////////////////////
	
	
	
	/////////////////////////// Staff Search Start ///////////////////////////*/
	
	
	function SearchData_StaffSearch($Staff, $Keyword)
	{
		
		$St="";
		$K="";
		
		
		if($Staff!="" && $Keyword=="")
		{
			$sql="SELECT * FROM tbl_staff WHERE StaffName LIKE '%$Staff%' ";
		}
	
		
		if($Keyword!="" && $Staff=="")
		{	
			$sql="SELECT s.* ,d.* FROM `tbl_staff` s, `tbl_delivery` d WHERE s.StaffID=d.StaffID AND d.Keyword = '$Keyword' ";
		}
		
		if($Keyword!="" && $Staff!="")
		{
			$sql="SELECT s.* ,d.* FROM `tbl_staff` s, `tbl_delivery` d WHERE s.StaffID=d.StaffID AND s.StaffName LIKE '%$Staff%' AND d.Keyword = '$Keyword' ";
		}
		
		if($Keyword=="" && $Staff=="")
		{
			$sql="SELECT s.* ,d.* FROM `tbl_staff` s, `tbl_delivery` d WHERE s.StaffID=d.StaffID";
		}
	
		return $sql;
		
		/*
		$St="";
		$K="";
		
		$OrderBy=" ORDER BY s.StaffID";
		
		
		if($Staff!="")
		{
			$St="s.StaffName LIKE '%$Staff%' ";
		}
	
		
		if($Keyword!="" )
		{	
				if($St!="" )
				{
					$K=" AND d.Keyword = '$Keyword' AND s.StaffID = d.StaffID  ";
				}
				
				elseif($St=="")
				{
				
					$K="  d.Keyword = '$Keyword' AND s.StaffID = d.StaffID ";
				
			}

		}
		
	
	
		
		$sql=" SELECT s.* ,d.* FROM `tbl_staff` s, `tbl_delivery` d WHERE s.StaffID=d.StaffID $St $K";
		echo $sql;
		return $sql;
		*/
	}
	/////////////////////////// Staff Search End ///////////////////////////
	
	
	
	
	
	
	
	/////////////////////////// All Staff Search  Start ///////////////////////////
	function SearchData_GetAllStaff()
	{
		$sql="SELECT * FROM `tbl_staff` ORDER BY StaffID ASC ";
		return $sql;
	}
	/////////////////////////// All Staff Search  End ///////////////////////////
	////////////////////////// Shop Search Start////////////////////////////////
	
	function SearchData_ShopSearch($Shop, $Keyword)
	{
		
		
		
		if($Shop!="" && $Keyword=="")
		{
			$sql="SELECT * FROM tbl_shop WHERE ShopName LIKE '%$Shop%' ";
		}
	
		
		if($Keyword!="" && $Shop=="")
		{	
			$sql="SELECT sh.* ,d.* FROM `tbl_shop` sh, `tbl_delivery` d WHERE sh.ShopID=d.ShopID AND d.Keyword = '$Keyword' ";
		}
		
		if($Keyword!="" && $Shop!="")
		{
			$sql="SELECT sh.* ,d.* FROM `tbl_shop` sh, `tbl_delivery` d WHERE sh.ShopID=d.ShopID AND sh.ShopName LIKE '%$Shop%' AND d.Keyword = '$Keyword' ";
		}
		
		if($Keyword=="" && $Shop=="")
		{
			$sql="SELECT sh.* ,d.* FROM `tbl_shop` sh, `tbl_delivery` d WHERE sh.ShopID=d.ShopID";
		}
	
		return $sql;
	}
	
	////////////////////////// Shop Search End ////////////////////////////////
	
	
	/////////////////////////// All Shop Search  Start ///////////////////////////
	function SearchData_GetAllShop()
	{
		$sql="SELECT * FROM `tbl_shop` ORDER BY ShopID ASC ";
		return $sql;
	}
	/////////////////////////// All Shop Search  End ///////////////////////////
	
	
	
	
	
	
	
	
	
	
	
	
	
	//function Search_Data($tableName,$orderByFieldName)*/

	function Search_Data($str)
	{
		$sql= $str . " LIMIT $this->offset,$this->pageSize";
		
		$this->totalRecordCount=$this->Search_TotalRecordCount($str);
		//how many pages
		$this->maxPage=ceil($this->totalRecordCount/$this->pageSize);	
		$result=mysql_query($sql) or die(mysql_error());
		
		return $result;
	}

	/********************************************************************/	

	function Search_TotalRecordCount($sql)
	{
		//If no search key is defined
		$ret=mysql_query($sql);
		$num=mysql_num_rows($ret);
		
		if($num == 0){ ?> <center>  Not Avaliable!!!! </center> <?php } 
		return $num;
				
	}

	/********************************************************************/

	function Generate_Pager($str)
	{
		/********************************************************************/
		// creating previous and next link
		// plus the link to go straight to
		// the first and last page
		/********************************************************************/				
		
		//the name of the current page	
		//$self = $_SERVER['PHP_SELF'];
		/********************************************************************/
		// "Previous" and "First" page link

		if ($this->currentPageIndex>1)
		{
			$pageIndex=$this->currentPageIndex-1;					
			echo "<a href='$self?page=1&$str'>[First]</a>&nbsp;";
			echo "<a href='$self?page=$pageIndex&$str'>[Prev]</a>&nbsp;";							
		}

		else

		{
			
		}								

		/********************************************************************/
		// print the link to access each page

		$b=false;

		for($i=1;$i<=$this->maxPage;$i++)
		{
			if ($i==$this->currentPageIndex)
			{
				echo $i . "&nbsp;";
			}

			else
			{
				 
			}
		}

		/********************************************************************/

		// "Next" and "Last" page link
	
		if ($this->currentPageIndex<$this->maxPage)
		{
			$pageIndex=$this->currentPageIndex+1;
			echo "<a href='$self?page=$pageIndex&$str'>[Next]</a>&nbsp;";
			echo "<a href='$self?page=$this->maxPage&$str'>[Last]</a>&nbsp;";
			echo " of total " . $this->maxPage;
		}

		else

		{}

		/********************************************************************/

	}
	/********************************************************************/

}	

?>