<?php
session_start();

require_once("library/connection.php");

require_once("dal/dal_staff.php");
require_once("library/autoidfunction.php");
require_once("library/globalfunction.php");

include("Permission.php");

$UserID=$_SESSION['SESS']['User']['UserID'];



if (isset($_POST['btnSaveStaff']) )

{	
	
	$StaffName=Clean($_POST['StaffName']);
	$Password=Clean($_POST['Password']);
	
	
	
	InsertStaff($StaffName, $Password);
	$msg1="Successfully Staff Save";
}
?>

 <meta charset="UTF-8">
    <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
        <style>
        .btnstyle
{
	width:100px;
	background-color:#054f8c;
	color:#000;
	height:30px;
	border: 2px solid#054f8c;
	border-radius:5px;
}
.btnstyle:hover
{
	background:#95cbf7;
	color:#fff;
	
}

        </style>
   <form method="post">
       <div >
            <div class="modal-dialog" >
                <div class="modal-content">
                    <div class="modal-header">
                  
                       
                        <h4 class="modal-title" id="myModalLabel">Create New Staff</h4>
                    </div>
                    <div class="modal-body" style="overflow:hidden">
						
                        <div class="form-group" >
                        <table width="550" style="margin-left:50px;">
                        		<tr height="50" >
                                	<td>Name : </td>
                                    <td><input type="text"  name="StaffName" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr height="50" >
                                	<td>Password : </td>
                                    <td><input type="password"  name="Password" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr>
                                <td ></td>
                                <td><div class="modal-footer">
                       <input name="btnSaveStaff" type="submit" id="submit"  value="Save" class="btnstyle">
                       <a href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'"><input type="reset" id="button" value="Close" class="btnstyle"></a><br><br>
                        
                    </div></td>
                                </tr>
                        </table>
                       
                            </div>
                        </div>
						
                       
                    </div>
                    
                </div>
            </div>
        </div></form>
       
      
        