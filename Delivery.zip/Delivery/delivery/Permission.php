<?php
	if(!isset($_SESSION['SESS']['User']['UserID']))
	{
		print "<script language=\"JavaScript\">window.location.href=\"LogIn.php\";</script>";
	}
?>