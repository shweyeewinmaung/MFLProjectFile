<?php
session_start();

require_once("library/connection.php");
require_once("library/connection.php");
require_once("dal/dal_user.php");
require_once("library/autoidfunction.php");
require_once("library/globalfunction.php");

include("Permission.php");

$UserID=$_SESSION['SESS']['User']['UserID'];

if (isset($_POST['btnSave']))
{	
	
	$FullName=Clean($_POST['FullName']);
	$DOB=Clean($_POST['DOB']);
	$Gender=Clean($_POST['Gender']);
	$Address=Clean($_POST['Address']);
	$Phone=Clean($_POST['Phone']);
	$Email=Clean($_POST['Email']);
	$UserName=Clean($_POST['UserName']);
	$Password=Clean($_POST['Password']);
	$Role=Clean($_POST['Role']);
	
	InsertUser($FullName, $DOB, $Gender,$Address, $Phone, $Email, $UserName, $Password, $Role);
	$msg="Successfully Save User";
	
}




?>

<html>
    <head>
        <title>Delievery</title>
        <meta charset="UTF-8">
       <!-- <script type="text/javascript" src="js/jquery.min.js"></script>-->
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width">
        <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
          <style>
       <meta charset="UTF-8">
    <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
        <style>
        .btnstyle
{
	width:100px;
	background-color:#054f8c;
	color:#000;
	height:30px;
	border: 2px solid#054f8c;
	border-radius:5px;
}
.btnstyle:hover
{
	background:#95cbf7;
	color:#fff;
	
}

        </style>

    </head>
    <body>
        <div class="container-fluid bar">
        </div>
        <div class="container">

            <div class="row">
                <?php require_once('template/left.php'); ?>
                <font style="color:#006; margin-left:-180px;"><?php echo "Welcome : ".$_SESSION['SESS']['User']['UserName']; ?> &nbsp; &nbsp;
                      <?php echo $_SESSION['SESS']['User']['Role']; ?></font>
                <form class="form-horizontal col-xs-6" method="post">
                    <h4>Register</h4>
                    <div class="panel panel-default" style="width: 570px;">
                        <div class="panel-body">
				
								<font style="color:red;"><?php echo $msg; ?></font>
                            
                             <table width="450" style="margin-left:5px;">
                        		
                        		<tr height="50" >
                                	<td>FullName : </td>
                                    <td><input type="text"   name="FullName" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr height="50" >
                                	<td>DOB : </td>
                                    <td><input type="text"    name="DOB" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr height="50" >
                                	<td>Gender : </td>
                                    <td><input type="text"    name="Gender" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr height="85" >
                                	<td>Address : </td>
                                    <td>
                                    <textarea name="Address" style=" height:80px; width:300px; border-radius:5px; border:1px solid#ccc;"></textarea>
                                    </td>
                                </tr>
                                <tr height="50" >
                                	<td>Phone : </td>
                                    <td><input type="text"    name="Phone" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr height="50" >
                                	<td>Email : </td>
                                    <td><input type="text"    name="Email" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr height="50" >
                                	<td>UserName : </td>
                                    <td><input type="text"    name="UserName" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr height="50" >
                                	<td>Password : </td>
                                    <td><input type="password"    name="Password" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr height="50" >
                                	<td>Role : </td>
                                    <td>
                                    	<select class="form-control" name="Role" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;">
                                       		 <option>Admin</option>
                                       		 <option>Staff</option>
                                    	</select>
                                    </td>
                                </tr>
                                <tr>
                                <td ></td>
                                <td><div class="modal-footer">
                       <input name="btnSave" type="submit" id="submit"  value="Save" class="btnstyle">
                      <input type="reset" id="button" value="Cancel" class="btnstyle"><br><br>
                        
                    </div></td>
                                </tr>
                        </table>
                           


                            
                            
                        </div>
                    </div>
                </form>
            </div>
        </div>

      
    </body>
</html>
