<?php

session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Delivery</title>
<style>
.login_hd
{
  border-bottom:3px solid #000;
}
.hd
{
	color:#FFF;	
	padding-left:10px;
}
.button {
	display: inline-block;
	zoom: 1; /* zoom and *display = ie7 hack for display:inline-block */
	*display: inline;
	vertical-align: baseline;
	margin: 0 2px;
	outline: none;
	cursor: pointer;
	text-align: center;
	text-decoration: none;
	font: 14px/100% Arial, Helvetica, sans-serif;
	padding: .5em 2em .55em;
	text-shadow: 0 1px 1px rgba(0,0,0,.3);
	-webkit-border-radius: .5em; 
	-moz-border-radius: .5em;
	border-radius: .5em;
	-webkit-box-shadow: 0 1px 2px rgba(0,0,0,.2);
	-moz-box-shadow: 0 1px 2px rgba(0,0,0,.2);
	box-shadow: 0 1px 2px rgba(0,0,0,.2);
}
.button:hover {
	text-decoration: none;
}
.button:active {
	position: relative;
	top: 1px;
}
.medium {
	font-size: 12px;
	padding: .4em 1.5em .42em;
}
.blue {
	color: #fff;
	border: solid 1px #043743;
	background: #043743;
	background: -webkit-gradient(linear, left top, left bottom, from(#043743), to(#043743));
	background: -moz-linear-gradient(top, #043743,  #043743);
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#043743', endColorstr='#043743');
}
.blue:hover {
	background: #c3edf7;
	background: -webkit-gradient(linear, left top, left bottom, from(#c3edf7), to(#c3edf7));
	background: -moz-linear-gradient(top, #c3edf7,  #c3edf7);
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#c3edf7', endColorstr='#c3edf7');
	border: solid 1px #c3edf7;
	color:#000;
}
.blue:active {
	color: #043743;
	background: -webkit-gradient(linear, left top, left bottom, from(#043743), to(#043743));
	background: -moz-linear-gradient(top, #043743,  #043743);
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#043743', endColorstr='#043743');
}
.tblayout{
margin-left:430px;
color:#FFF;
font-size:15px;
}
.tbbk{
    background: #00bce8;
    background: -webkit-gradient(linear, left top, left bottom, from(#00bce8), to(#00bce8));
	background: -moz-linear-gradient(top,  #00bce8,  #00bce8);
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#00bce8', endColorstr='#00bce8');
	-moz-border-radius:5px;
	-moz-box-shadow: 0 1px 8px rgba(0,0,0,.2);
}
</style>

<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script language="javascript">	
function givevalue()
{
	if (document.getElementById("UserName").value == "")
	{
		window.alert("Please Enter Login Name");
		document.getElementById("UserName").focus();
		return false;
	
	}
	
	if(document.getElementById("Password").value == "")	
	{
		window.alert("Please Enter Password");
		document.getElementById("Password").focus();
		return false;
	}
	

	return true;
}
function setfocus()
{
	document.form1.UserName.focus();
}
</script>

</head>
 
<body onLoad="setfocus()">


<br /><br />
<form action="LogInVal.php" method="post" autocomplete="off" name="form1" style="
        
        position: absolute;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: #333;
        z-index:1001;
        -moz-opacity: 0.8;
        opacity:.80;
        filter: alpha(opacity=80);
    ">
  <table width="506" border="0" align="center" class="tblayout">
    <tr>
      <td width="500" height="69">
          
      </td>
    </tr>
    <tr>
      <td width="500" align="center">
        <table width="500px" border="0" align="center" cellpadding="0" cellspacing="0" class="tbbk">
          <tr>
            <td colspan="3" height="50" class="login_hd"><font class="hd" style="margin-left:150px;">Please Login Here!!!!!!!</font></td>
          </tr>
          <tr>
            <td width="152" class="tb_border">&nbsp;</td>
            <td width="149">&nbsp;</td>
            <td width="285" class="tb_border_4">&nbsp;</td>
          </tr>
          <tr>
          
             <?php
				if(isset($_SESSION['LogIn']) && $_SESSION['LogIn']="Fail")
				{
					?>
                    
	                    <th colspan="2" style="color:red; line-height:50px;" class="tb_border_5"><b>Invalid LogIn! Please Try Again!!!</b></th>
                    <?php
				}
			?>
           
          </tr>
          <tr>
            <td colspan="3" class="tb_border_5">&nbsp;</td>
          </tr>
          <tr>
            <td rowspan="3" align="center" class="tb_border"><img src="images/security1.png" width="102" height="98" /></td>
            <td height="40">User Name</td>
            <td class="tb_border_4">
            <input name="UserName" type="text" size="20" class="txtbox" /></td>
          </tr>
          <tr>
            <td height="40">Password</td>
            <td class="tb_border_4">
            <input name="Password" type="Password" size="20" class="txtbox"/></td>
          </tr>
          <tr>
            <td height="44">Role</td>
            <td class="tb_border_4">
              <select name="Role" style="width:150px;">
                <option>Admin</option>
                <option>Staff</option>
            </select></td>
          </tr>
          <tr>
            <td align="center" class="tb_border">&nbsp;</td>
            <td height="44">&nbsp;</td>
            <td class="tb_border_4">
            <input type="submit" name="LogIn"  value="LogIn" class="button blue" onClick="return givevalue();" style="width:100px;">
            <input type="reset" name="Cancel"  class="button blue" value="Cancel" style="width:100px;"/>
            </td>
          </tr>
          <tr>
            <td align="center" class="tb_border_1">&nbsp;</td>
            <td class="tb_border_2">&nbsp;</td>
            <td class="tb_border_3">&nbsp;</td>
          </tr>
        </table>
        
      </td>
    </tr>
  </table>
</form>
</body>
</html>