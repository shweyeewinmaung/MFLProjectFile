<?php
session_start();

require_once("library/connection.php");

require_once("dal/dal_staff.php");
require_once("library/autoidfunction.php");
require_once("library/globalfunction.php");


include("Permission.php");

$UserID=$_SESSION['SESS']['User']['UserID'];


if (isset($_POST['btnUpdateStaff']) )

{	
	$StaffID=Clean($_POST['StaffID']);
	$StaffName=Clean($_POST['StaffName']);
	$Password=Clean($_POST['Password']);
	
	
	
	UpdateStaff($StaffID,$StaffName, $Password);
	$msg1="Successfully Staff Update";
}
if (isset($_GET['StaffID']) && $_GET['StaffID']!="")
{
	$StaffID=Clean($_GET['StaffID']);
	$ret=GetStaffDataByStaffID($StaffID);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
}


?>

<html>
    <head>
        <title>Delievery</title>
        <meta charset="UTF-8">
       <!-- <script type="text/javascript" src="js/jquery.min.js"></script>-->
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width">
        <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
          <style>
       <meta charset="UTF-8">
    <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
        <style>
        .btnstyle
{
	width:100px;
	background-color:#054f8c;
	color:#000;
	height:30px;
	border: 2px solid#054f8c;
	border-radius:5px;
}
.btnstyle:hover
{
	background:#95cbf7;
	color:#fff;
	
}

        </style>

    </head>
    <body>
        <div class="container-fluid bar">
        </div>
        <div class="container">

            <div class="row">
                <?php require_once('template/left.php'); ?>
                <font style="color:#006; margin-left:-180px;"><?php echo "Welcome : ".$_SESSION['SESS']['User']['UserName']; ?> &nbsp; &nbsp;
                      <?php echo $_SESSION['SESS']['User']['Role']; ?></font>
                <form class="form-horizontal col-xs-6" method="post">
                    <h4>Update Staff</h4>
                    <div class="panel panel-default" style="width: 570px;">
                        <div class="panel-body">
				
								<font style="color:red;"><?php echo $msg; ?></font>
                            
                             <table width="550" style="margin-left:5px;">
                        		<tr height="50"  >
                                	<td>ID : </td>
                                    <td><input type="text"  readonly value="<?php echo $row['StaffID']; ?>" name="StaffID" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                        		<tr height="50" >
                                	<td>Name : </td>
                                    <td><input type="text"  value="<?php echo $row['StaffName']; ?>" name="StaffName" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr height="50" >
                                	<td>Password : </td>
                                    <td><input type="text"  value="<?php echo $row['Password']; ?>"  name="Password" style=" height:35px; width:300px; border-radius:5px; border:1px solid#ccc;"></td>
                                </tr>
                                <tr>
                                <td ></td>
                                <td><div class="modal-footer">
                       <input name="btnUpdateStaff" type="submit" id="submit"  value="Update" class="btnstyle">
                      <input type="reset" id="button" value="Cancel" class="btnstyle"><br><br>
                        
                    </div></td>
                                </tr>
                        </table>
                           


                            
                            
                        </div>
                    </div>
                </form>
            </div>
        </div>

      
    </body>
</html>
