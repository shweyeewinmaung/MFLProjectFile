<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Delivery</title>
        <meta charset="UTF-8">
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width">
        <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
    </head>
    <body>
        <div class="container-fluid bar">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xs-2">
                    <ul class="menu">
                        <li><a href="#">Dashboard</a></li>
                        <li><a href="index.php">Receiver Form</a></li>
                        <li><a href="insert_delievery.php">Insert Delivery</a></li>
                        <li><a href="delievery_list.php">Delivery List</a></li>
                        <li><a href="staff_list.php">Staffs</a></li>
                        <li><a href="shop_list.php">Shops</a></li>
                        <li><a href="report_amount.php">Report Amount</a></li>
                        <li><a href="Register.php">Register</a></li>
                        <li><a href="LogOut.php">Log Out</a></li>

                    </ul>
                </div>
                <div class="col-xs-10">
                    <div>
                        <div class="col-xs-2">
                            <label>From Date</label>
                            <input type="text" class="form-control">
                        </div>
                        <div class="col-xs-2">
                            <label>To Date</label>
                            <input type="text" class="form-control">
                        </div>
                        <div class="col-xs-2 np">
                            <label>Staff</label>
                            <select class="form-control">
                                <option>All</option>
                                <option>Staff One</option>
                                
                            </select>
                        </div>
                        <div class="col-xs-2">
                            <label>Shop</label>
                            <select class="form-control">
                                <option>All</option>
                                <option>Shop One</option>
                                <option>Shop Two</option>
                                
                            </select>
                        </div>
                        
                        <div class="col-xs-2 np">
                            <label>Status</label>
                            <select class="form-control">
                                <option>Pending</option>
                                <option>Finished</option>
                            </select>
                        </div>
                        <div class="col-xs-1">
                            <button type="submit" class="btn btn-info" style="margin-top:25px;">Search</button>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    
                    <div class="col-xs-10" style="margin-top:30px;">
                        <label> Amount: 70000 ks</label>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
