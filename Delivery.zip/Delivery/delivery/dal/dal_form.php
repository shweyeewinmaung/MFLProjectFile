<?php
function InsertForm($FormName, $FormAddress)
{
	$sql="INSERT INTO tbl_form(FormName, FormAddress)
	VALUES('$FormName', '$FormAddress')";
	
	mysql_query($sql);
}
?>