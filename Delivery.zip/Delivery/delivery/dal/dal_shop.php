<?php
function GetShopNameByShopID($ShopID)
{
	$sql="SELECT * FROM tbl_shop WHERE ShopID='$ShopID'";
	
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	return $row[1];
}
function GetShopDataByShopID($ShopID)
{
	$sql="SELECT * FROM tbl_shop order by ShopID asc";
	return mysql_query($sql);
}
function getAllShopData()
{
	$sql="Select * from tbl_shop order by ShopID";
	$ret=mysql_query($sql);
	return $ret;
}
function GetShopDataByShopName($ShopName)
{
	$sql="SELECT * FROM tbl_shop WHERE ShopName='$ShopName'";
	return mysql_query($sql);
}

function InsertShop($ShopName, $Phone,$Email,$ShopAddress)
{
	$sql="INSERT INTO tbl_shop(ShopName, Phone,Email,ShopAddress)
	VALUES('$ShopName', '$Phone','$Email','$ShopAddress')";
	
	mysql_query($sql);
}
function UpdateShop($ShopID,$ShopName, $Phone,$Email,$ShopAddress)


{
	$sql="UPDATE tbl_shop SET	ShopName='$ShopName',
								Phone='$Phone',
								Email='$Email',
								ShopAddress='$ShopAddress'
								
							WHERE ShopID='$ShopID'";
							echo $sql;
	 mysql_query($sql);
	 
}
function DeleteShop($ShopID,$ShopName, $Phone,$Email,$ShopAddress)

{
	$sql="Delete from tbl_shop where ShopID='$ShopID'";
	
	$ret=mysql_query($sql);
	return $ret;
}

?>