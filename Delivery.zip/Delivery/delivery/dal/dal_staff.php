<?php
function GetStaffNameByStaffID($StaffID)
{
	$sql="SELECT * FROM tbl_staff WHERE StaffID='$StaffID'";
	
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	return $row[1];
}

function GetStaffDataByStaffID($StaffID)
{
	$sql="SELECT * FROM tbl_staff order by StaffID asc";
	
	return mysql_query($sql);
}

function GetStaffDataByStaffName($StaffName)
{
	$sql="SELECT * FROM tbl_staff WHERE StaffName='$StaffName'";
	return mysql_query($sql);
}
function getAllStaffData()
{
	$sql="Select * from tbl_staff order by StaffID";
	$ret=mysql_query($sql);
	return $ret;
}




function InsertStaff($StaffName, $Password)
{
	$sql="INSERT INTO tbl_staff(StaffName, Password)
	VALUES('$StaffName', '" . md5($Password) . "')";
	
	mysql_query($sql);
}
function UpdateStaff($StaffID,$StaffName, $Password)

{
	$sql="UPDATE tbl_staff SET	StaffName='$StaffName',
								Password='" . md5($Password) . "' 
							WHERE StaffID='$StaffID'";
							
	 mysql_query($sql);
	 
}
function DeleteStaff($StaffID,$StaffName, $Password)

{
	$sql="delete from tbl_staff where StaffID='$StaffID'";
	$ret=mysql_query($sql);
	return $ret;
}


?>