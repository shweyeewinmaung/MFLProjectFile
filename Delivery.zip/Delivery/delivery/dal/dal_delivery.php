<?php
function GetDeliveryDataByDeliveryCode($DeliveryCode)
{
	$sql="SELECT * FROM tbl_delivery WHERE DeliveryCode='$DeliveryCode'";
	return mysql_query($sql);
}


function GetDeliveryDataByDelivery($DeliveryCode)
{
	$sql="SELECT * FROM tbl_delivery order by DeliveryCode asc";
	return mysql_query($sql);
}

function GetDeliveryDataByCustomerID($CustomerID)
{
	$sql="SELECT * FROM tbl_delivery WHERE CustomerID='$CustomerID'";
	
	return mysql_query($sql);
}


function GetDeliveryDataByStaffID($StaffID)
{
	$sql="SELECT * FROM tbl_delivery WHERE StaffID='$StaffID'";
	
	return mysql_query($sql);
}

function GetDeliveryDataByShopID($ShopID)
{
	$sql="SELECT * FROM tbl_delivery WHERE ShopID='$ShopID'";
	
	return mysql_query($sql);
}

function InsertDelivery($DeliveryCode,$DeliveryEntry,  $ToD, $Address, $Keyword, $DeliveryType, $Staff,$Customer,$DeliveryMan, $CarGate,$Shop,$Phone,$VoucherNo,$Cost,$Status,$Remark)
{
	$sql="INSERT INTO tbl_delivery(DeliveryCode,DeliveryEntry,  ToD, Address, Keyword, DeliveryType, StaffID,CustomerID, DeliveryManID, CarGateID,ShopID,Phone,VoucherNo,Cost,Status,Remark)
	VALUES('$DeliveryCode','$DeliveryEntry',  '$ToD', '$Address', '$Keyword', '$DeliveryType', '$Staff', '$Customer','$DeliveryMan', '$CarGate','$Shop','$Phone','$VoucherNo','$Cost','$Status','$Remark')";
	
	mysql_query($sql);
}
function UpdateDelivery($DeliveryCode,$DeliveryEntry,$ToD, $Address, $Keyword, $DeliveryType, $StaffID,$CustomerID,$DeliveryManID, $CarGateID,$ShopID,$Phone,$VoucherNo,$Cost,$Status,$Remark)

{
	$sql="UPDATE tbl_delivery SET DeliveryEntry='$DeliveryEntry', 
								
								ToD='$ToD', 
								Address='$Address', 
								Keyword='$Keyword', 
								DeliveryType='$DeliveryType', 
								StaffID='$StaffID',
								CustomerID='$CustomerID',
								DeliveryManID='$DeliveryManID',  
								CarGateID='$CarGateID',
								ShopID='$ShopID', 
								Phone='$Phone', 
								VoucherNo='$VoucherNo', 
								Cost='$Cost',						
								Status='$Status',
								Remark='$Remark' 
							WHERE DeliveryCode='$DeliveryCode'";
							echo $sql;
							
	 mysql_query($sql);
	 
}
function DeleteDelivery($DeliveryCode,$DeliveryEntry,  $ToD, $Address, $Keyword, $DeliveryType, $Staff,$Customer,$DeliveryMan, $CarGate,$Shop,$Phone,$VoucherNo,$Cost,$Status,$Remark)

{
	$sql="delete from tbl_delivery where DeliveryCode='$DeliveryCode'";
	$ret=mysql_query($sql);
	return $ret;
}

?>