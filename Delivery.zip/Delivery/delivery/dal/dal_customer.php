<?php
function GetCustomerNameByCustomerID($CustomerID)
{
	$sql="SELECT * FROM tbl_customer WHERE CustomerID='$CustomerID'";
	
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	return $row[1];
}
function GetCustomerDataByCustomerID($CustomerID)
{
	$sql="SELECT * FROM tbl_customer order by CustomerID asc";
	return mysql_query($sql);
}

function GetCustomerDataByCustomerName($CustomerName)
{
	$sql="SELECT * FROM tbl_customer WHERE CustomerName='$CustomerName'";
	return mysql_query($sql);
}

function InsertCustomer($CustomerName, $Phone,$Email,$CustomerAddress)
{
	$sql="INSERT INTO tbl_customer(CustomerName, Phone,Email,CustomerAddress)
	VALUES('$CustomerName', '$Phone','$Email','$CustomerAddress')";
	echo $sql;
	mysql_query($sql);
}
?>