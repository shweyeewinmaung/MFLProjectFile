<?php
function GetDeliveryManNameByDeliveryManID($DeliveryManID)
{
	$sql="SELECT * FROM tbl_deliveryman WHERE DeliveryManID = '$DeliveryManID'";
	
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	return $row[1];
}
function GetDeliveryManDataByDeliveryManName($DeliveryManName)
{
	$sql="SELECT * FROM tbl_deliveryman WHERE DeliveryManName='$DeliveryManName'";
	return mysql_query($sql);
}
function InsertDeliveryMan($DeliveryManName, $Phone,$Email,$Address)
{
	$sql="INSERT INTO tbl_deliveryman(DeliveryManName, Phone,Email,Address)
	VALUES('$DeliveryManName', '$Phone','$Email','$Address')";
	
	mysql_query($sql);
}
?>