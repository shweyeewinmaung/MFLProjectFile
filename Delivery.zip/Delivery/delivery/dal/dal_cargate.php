<?php
function GetCarGateNameByCarGate($CarGateID)
{
	$sql="SELECT * FROM tbl_cargate WHERE CarGateID='$CarGateID'";
	
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	return $row[1];
}
function GetCarGateDataByCarGateName($CarGateName)
{
	$sql="SELECT * FROM tbl_cargate WHERE CarGateName='$CarGateName'";
	return mysql_query($sql);
}
function InsertCarGate($CarGateName, $CarGateAddress,$CarGatePhone)
{
	$sql="INSERT INTO tbl_cargate(CarGateName, CarGateAddress,CarGatePhone)
	VALUES('$CarGateName', '$CarGateAddress','$CarGatePhone')";
	
	mysql_query($sql);
}
?>