<?php
function GetReceiveDataByReceive($ReceiveID)
{
	$sql="SELECT * FROM tbl_receive order by ReceiveID asc";
	return mysql_query($sql);
}
function GetReceiveDataByCustomerID($CustomerID)
{
	$sql="SELECT * FROM tbl_receive WHERE CustomerID='$CustomerID'";
	
	return mysql_query($sql);
}
function GetDeliverQtyByCustomerName($CustomerName)
{
	$sql="SELECT  SUM(DeliverQty) FROM tbl_receive WHERE `CustomerName` = '$CustomerName'";
	echo $sql;
	return mysql_query($sql);
}

function InsertReceive($ReceiveID, $Customer,$Address, $TotalQty, $DeliverQty, $TakingQty)
{
	$sql="INSERT INTO tbl_receive(ReceiveID, CustomerID, Address, TotalQty, DeliverQty, TakingQty)
	VALUES('$ReceiveID', '$Customer', '$Address', '$TotalQty', '$DeliverQty', '$TakingQty')";
	
	mysql_query($sql);
}
?>