<?php
function GetLogInData($UserName, $Password, $Role)
{
	$sql="SELECT * FROM tbl_user WHERE UserName='$UserName' AND Password='" . md5($Password) . "' AND Role='".$_REQUEST['Role']."'";
	echo $sql;
	return mysql_query($sql);
}

function InsertUser($FullName, $DOB, $Gender,$Address, $Phone, $Email, $UserName, $Password, $Role)
{
	$sql="INSERT INTO tbl_user( FullName, DOB, Gender, Address, Phone, Email, UserName, Password, Role) 
	VALUES('$FullName', '$DOB', '$Gender', '$Address', '$Phone', '$Email', '$UserName', '" . md5($Password) . "', '$Role')";
	mysql_query($sql);
}


?>