<?php
session_start();
include("library/connection.php");
include("library/globalfunction.php");
require_once("dal/dal_user.php");


//if(isset($_SESSION['SESS']['User']['UserID']))
//{
	//header("Location:index.php");
//}

	$UserName=Clean($_POST['UserName']);
	$Password=Clean($_POST['Password']);
	$Role=Clean($_POST['Role']);
	
	

	$ret=GetLogInData($UserName, $Password ,$Role);
	$num=mysql_num_rows($ret);
	echo $num;

	if($num>0)
	{ 
		$row=mysql_fetch_array($ret);
		$_SESSION['SESS']['User']['UserID']=$row['UserID'];
		$_SESSION['SESS']['User']['UserName']=$row['UserName'];
		$_SESSION['SESS']['User']['Role']=$row['Role'];
	
		print "<script language=\"JavaScript\">window.location.href=\"index.php\";</script>";
	}
	else
	{
		$_SESSION['LogIn']="Fail";
		print "<script language=\"JavaScript\">window.location.href=\"LogIn.php\";</script>";
	}












?>