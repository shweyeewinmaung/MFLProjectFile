<?php
session_start();

require_once("library/connection.php");
require_once("dal/dal_delivery.php");
require_once("dal/dal_staff.php");
require_once("dal/dal_shop.php");
require_once("dal/dal_customer.php");
require_once("dal/dal_deliveryman.php");
require_once("dal/dal_cargate.php");
require_once("library/autoidfunction.php");
require_once("library/globalfunction.php");

include("Permission.php");

$UserID=$_SESSION['SESS']['User']['UserID'];


if (isset($_POST['submit']) )

{	
	$DeliveryCode=AutoID('tbl_delivery','DeliveryCode','FEB032015-',4);
	//$DeliveryCode=Clean($_POST['DeliveryCode']);
	$DeliveryEntry=date("Y/m/d");
	
	$ToD=Clean($_POST['ToD']);
	$Address=Clean($_POST['Address']);
	$Keyword=Clean($_POST['Keyword']);
	$DeliveryType=Clean($_POST['DeliveryType']);
	$Staff=Clean($_POST['Staff']);
	$Customer=Clean($_POST['Customer']);
	$DeliveryMan=Clean($_POST['DeliveryMan']);
	$CarGate=Clean($_POST['CarGate']);
	$Shop=Clean($_POST['Shop']);
	$Phone=Clean($_POST['Phone']);
	$VoucherNo=Clean($_POST['VoucherNo']);
	$Cost=Clean($_POST['Cost']);
	$Status=Clean($_POST['Status']);
	$Remark=Clean($_POST['Remark']);
	
	
	
	InsertDelivery($DeliveryCode,$DeliveryEntry,$ToD, $Address, $Keyword, $DeliveryType, $Staff,$Customer,$DeliveryMan, $CarGate,$Shop,$Phone,$VoucherNo,$Cost,$Status,$Remark);
	$msg="Successfully Delivery Save";
}


?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Delivery</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
       
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <link type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="css/app.css" rel="stylesheet">
       <style>
       .black_overlay{
        display: none;
        position: fixed;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: black;
        z-index:1001;
        -moz-opacity: 0.8;
        opacity:.80;
        filter: alpha(opacity=80);
    }
	
    .white_content {
        display: none;
        position: fixed;
        top: 25%;
        left: 25%;
        width: 800px;
        height: 400px;
        padding: 16px;
        border:10px solid #054f8c;
        background-color: white;
        z-index:1002;
        overflow: auto;
    }
	 .black_overlay1{
        display: none;
        position: fixed;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: black;
        z-index:1001;
        -moz-opacity: 0.8;
        opacity:.80;
        filter: alpha(opacity=80);
    }
	
    .white_content1 {
        display: none;
        position: fixed;
        top: 6%;
        left: 25%;
        width: 800px;
        height: 550px;
        padding: 16px;
        border:10px solid #054f8c;
        background-color: white;
        z-index:1002;
        overflow: auto;
    }
	 .black_overlay2{
        display: none;
        position: fixed;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: black;
        z-index:1001;
        -moz-opacity: 0.8;
        opacity:.80;
        filter: alpha(opacity=80);
    }
	
    .white_content2 {
        display: none;
        position: fixed;
        top: 6%;
        left: 25%;
        width: 800px;
        height: 550px;
        padding: 16px;
        border:10px solid #054f8c;
        background-color: white;
        z-index:1002;
        overflow: auto;
    }
	 .black_overlay3{
        display: none;
        position: fixed;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: black;
        z-index:1001;
        -moz-opacity: 0.8;
        opacity:.80;
        filter: alpha(opacity=80);
    }
	
    .white_content3 {
        display: none;
        position: fixed;
        top: 6%;
        left: 25%;
        width: 800px;
        height: 550px;
        padding: 16px;
        border:10px solid #054f8c;
        background-color: white;
        z-index:1002;
        overflow: auto;
    }
	
 .black_overlay4{
        display: none;
        position: fixed;
        top: 0%;
        left: 0%;
        width: 100%;
        height: 100%;
        background-color: black;
        z-index:1001;
        -moz-opacity: 0.8;
        opacity:.80;
        filter: alpha(opacity=80);
    }
	
    .white_content4 {
        display: none;
        position: fixed;
        top: 5%;
        left: 25%;
        width: 800px;
        height: 550px;
        padding: 16px;
        border:10px solid #054f8c;
        background-color: white;
        z-index:1002;
        overflow: auto;
    }
	
	
       </style> 
    </head>
    <body>
        <div class="container-fluid bar">
        </div>
        <div class="container">

            <div class="row">
                <?php require_once('template/left.php'); ?>
                <font style="color:#006; margin-left:-180px;"><?php echo "Welcome : ".$_SESSION['SESS']['User']['UserName']; ?> &nbsp; &nbsp;
                      <?php echo $_SESSION['SESS']['User']['Role']; ?></font>
                <form class="form-horizontal col-xs-6" method="post">
                    <h4>New Delivery Form</h4>
                    <div class="panel panel-default">
                        <div class="panel-body">
						<font style="color:red;"><?php echo $msg; ?></font>
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Code</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" value="<?php echo AutoID('tbl_delivery','DeliveryCode','FEB032015-',4); ?>"  name="DeliveryCode">
                                </div>
                            </div>
                         <!--   <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">From</label>
                                <div class="col-xs-8">
                                    <select class="form-control" name="FromD">
                                        <option>From One</option>
                                        <option>From Two</option>
                                    </select>
                                </div>
                            </div>-->
                            
                                                         <!-- if customer -->
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Customer</label>
                                <div class="col-xs-5">
                                                              
                                
                                 
                                    
                                      <select class="form-control" name="Customer" style="width:210px; ">
	  								
	   
	  									 <?php 
	   										$sql="select * from tbl_customer";
											echo $sql;
			
           								  $ret= mysql_query($sql);
            							 while($rowsd=mysql_fetch_array($ret)){?>
          							<option value="<?php echo $rowsd['CustomerID'];?>" ><?php echo $rowsd['CustomerName'];?></option>
          <?php }?>
	   
		   </select>
                                </div>
                                <div class="col-xs-1">
                                
                                <a  href="javascript:void(0)" class="btn btn-success" data-toggle="modal" data-target="#staffpopup" onclick = "document.getElementById('light2').style.display='block';document.getElementById('fade2').style.display='block'"  >Create Customer</a> 
								    <div id="light2" class="white_content2"> <?php require_once('CustomerEntry.php'); ?>  
                                                                   
                                    </div>
    <div id="fade2" class="black_overlay2"></div>



                       
                        
                   
            
                                    
                                           
                                        
                             
                            </div>
                            <!-- end if delivery Man-->

                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">To</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="ToD">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-xs-3">Address</label>
                                <div class="col-xs-8">
                                    <textarea class="form-control" name="Address"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Keywords</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="Keyword">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Delivery Type</label>
                                <div class="col-xs-8">
                                    <select class="form-control" name="DeliveryType">
                                        <option>Staff</option>
                                        <option>Car</option>
                                    </select>
                                </div>
                            </div>

                            <!-- if staff -->
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Staff</label>
                                <div class="col-xs-5">
                                                              
                                
                                 
                                    
                                      <select class="form-control" name="Staff" style="width:210px;">
	  								
	   
	  									 <?php 
	   										$sql="select * from tbl_staff";
											echo $sql;
			
           								  $ret= mysql_query($sql);
            							 while($rowsd=mysql_fetch_array($ret)){?>
          							<option value="<?php echo $rowsd['StaffID'];?>" ><?php echo $rowsd['StaffName'];?></option>
          <?php }?>
	   
		   </select>
                                </div>
                                <div class="col-xs-1">
                                
                                <a  href="javascript:void(0)" class="btn btn-success" data-toggle="modal" data-target="#staffpopup" onclick = "document.getElementById('light').style.display='block';document.getElementById('fade').style.display='block'" >Create New Staff</a> 
								    <div id="light" class="white_content"> <?php require_once('StaffEntry.php'); ?>  
                                                                   
                                    </div>
    <div id="fade" class="black_overlay"></div>



                       
                        
                   
            
                                    
                                           
                                        
                                     
                                </div>
                            </div>
                            <!-- end if staff -->
                            
                            
                             <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">DeliveryMan</label>
                                <div class="col-xs-5">
                                                              
                                
                                 
                                    
                                      <select class="form-control" name="DeliveryMan" style="width:210px; margin-left:10px;">
	  								
	   
	  									 <?php 
	   										$sql="select * from tbl_deliveryman";
											echo $sql;
			
           								  $ret= mysql_query($sql);
            							 while($rowsd=mysql_fetch_array($ret)){?>
          							<option value="<?php echo $rowsd['DeliveryManID'];?>" ><?php echo $rowsd['DeliveryManName'];?></option>
          <?php }?>
	   
		   </select>
                                </div>
                                <div class="col-xs-1">
                                
                                <a  href="javascript:void(0)" class="btn btn-success" data-toggle="modal" data-target="#staffpopup" onclick = "document.getElementById('light3').style.display='block';document.getElementById('fade3').style.display='block'"  >Create DeliveryMan</a> 
								    <div id="light3" class="white_content3"> <?php require_once('DeliveryManEntry.php'); ?>  
                                                                   
                                    </div>
    <div id="fade3" class="black_overlay3"></div>



                       
                        
                   
            
                                    
                                           
                                        
                             
                            </div>
                            <!-- end if delivery Man -->

                            <!-- start if car -->
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Car Gate</label>
                                <div class="col-xs-5">
                                 
                                    
                                    
                                 <select class="form-control" name="CarGate" style="margin-left:10px;">
	  								
	   
	  									 <?php 
	   										$sql="select * from tbl_cargate";
											echo $sql;
			
           								  $ret= mysql_query($sql);
            							 while($rowsd=mysql_fetch_array($ret)){?>
          							<option value="<?php echo $rowsd['CarGateID'];?>" ><?php echo $rowsd['CarGateName'];?></option>
          <?php }?>
	   
		   </select>
                                </div>
                                
                                
                                <div class="col-xs-1">
                                    
                                 	<a  href="javascript:void(0)" class="btn btn-success" data-toggle="modal" data-target="#carpopup" onclick = "document.getElementById('light1').style.display='block';document.getElementById('fade1').style.display='block'" >Create New Gate</a> 
								    <div id="light1" class="white_content1"> <?php require_once('CarGateEntry.php'); ?></div>
    								<div id="fade1" class="black_overlay1"></div>


                                    
                                    
                              
                                
                                
                                
                                
                                
                                
                                
                                
                                
                            </div>
                            
                             <!-- if shop start -->
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Shop</label>
                                <div class="col-xs-5">
                                                              
                                
                                 
                                    
                                      <select class="form-control" name="Shop" style="width:210px; margin-left:10px;">
	  								
	   
	  									 <?php 
	   										$sql="select * from tbl_shop";
											echo $sql;
			
           								  $ret= mysql_query($sql);
            							 while($rowsd=mysql_fetch_array($ret)){?>
          							<option value="<?php echo $rowsd['ShopID'];?>" ><?php echo $rowsd['ShopName'];?></option>
          <?php }?>
	   
		   </select>
                                </div>
                                <div class="col-xs-1">
                                
                                <a  href="javascript:void(0)" class="btn btn-success" data-toggle="modal" data-target="#staffpopup" onclick = "document.getElementById('light4').style.display='block';document.getElementById('fade4').style.display='block'" >Create New Shop</a> 
								    <div id="light4" class="white_content4"> <?php require_once('ShopEntry.php'); ?>  
                                                                   
                                    </div>
    <div id="fade4" class="black_overlay4"></div>



                       
                        
                   
            
                                    
                                           
                                        
                                     
                                
                            </div>
                            <!-- end shop end -->
                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Contact Ph:</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="Phone"> 
                                </div>

                            </div>

                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Voucher No</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="VoucherNo"> 
                                </div>

                            </div>
                            <!-- end car -->


                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Cost</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="Cost">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Status</label>
                                <div class="col-xs-8">
                                    <select class="form-control" name="Status">
                                        <option>Pending</option>
                                        <option>Active</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail" class="control-label col-xs-3">Remark</label>
                                <div class="col-xs-8">
                                    <input type="text" class="form-control" name="Remark">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-xs-offset-3 col-xs-8">
                                    <button type="submit" class="btn btn-primary" name="submit">Save</button>
                                    <button class="btn btn-default"  type="reset">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- start staff popup -->
        <!-- start from popup -->
    <!--    <form method="post">
       <div class="modal fade" id="staffpopup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                  
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Create New Staff</h4>
                    </div>
                    <div class="modal-body" style="overflow:hidden">
						<font style="color:red;"><!--?php echo $msg1; ?></font>
                        <div class="form-group" style="overflow:hidden">
                            <label for="inputEmail" class="control-label col-xs-3">Name</label>
                            <div class="col-xs-8">
                                <input type="text" class="form-control" name="StaffName">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputEmail" class="control-label col-xs-3">Password</label>
                            <div class="col-xs-8">
                                <input type="text" class="form-control" name="Password">
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" name="btnSaveStaff">Save</button>
                        
                    </div>
                </div>
            </div>
        </div></form>
        <!-- end from popup -->
        <!-- end staff -->
        <!-- start car gate -->
        <!-- start from popup -->
  <!--   <div class="modal fade" id="carpopup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Create From</h4>
                    </div>
                    <div class="modal-body" style="overflow:hidden">

                        <div class="form-group" style="overflow:hidden">
                            <label for="inputEmail" class="control-label col-xs-3">Name</label>
                            <div class="col-xs-8">
                                <input type="text" class="form-control">
                            </div>
                        </div>

                        <div class="form-group" style="overflow:hidden">
                            <label for="inputEmail" class="control-label col-xs-3">Address</label>
                            <div class="col-xs-8">
                                <textarea class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputEmail" class="control-label col-xs-3">Phone</label>
                            <div class="col-xs-8">
                                <input type="text" class="form-control">
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" >Save</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- end from popup -->
        <!-- end car gate -->
    </body>
</html>
