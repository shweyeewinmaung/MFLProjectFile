   <div class="col-xs-2">
                    <ul class="menu">
                    	
                        
               
                        <li><a href="#">Dashboard</a></li>
                        <li><a href="index.php">Receiver Form</a></li>
                                   <?php
				if(isset($_SESSION['SESS']['User']['Role']) && $_SESSION['SESS']['User']['Role']=="Staff")
				{
					?>
                    	<li><a href="insert_delievery.php">Insert Delivery</a></li>
                    <?php
				}
				elseif(isset($_SESSION['SESS']['User']['Role']) && $_SESSION['SESS']['User']['Role']=="Admin")
				{
					?>
	                    <li><a href="insert_delievery.php">Insert Delivery</a></li>
                    <?php
				}
				
			?>
                        <li><a href="delievery_list.php">Delivery List</a></li>
                        <li><a href="staff_list.php">Staffs</a></li>
                        <li><a href="shop_list.php">Shops</a></li>
                        <li><a href="report_amount.php">Report Amount</a></li>
                        <li><a href="Register.php">Register</a></li>
                        <li><a href="LogOut.php">Log Out</a></li>

                    </ul>
                </div>
         