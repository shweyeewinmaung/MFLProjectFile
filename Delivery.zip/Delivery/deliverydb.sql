-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 30, 2015 at 07:50 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `deliverydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cargate`
--

CREATE TABLE IF NOT EXISTS `tbl_cargate` (
  `CarGateID` int(11) NOT NULL AUTO_INCREMENT,
  `CarGateName` varchar(50) NOT NULL,
  `CarGateAddress` varchar(255) NOT NULL,
  `CarGatePhone` varchar(50) NOT NULL,
  PRIMARY KEY (`CarGateID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_cargate`
--

INSERT INTO `tbl_cargate` (`CarGateID`, `CarGateName`, `CarGateAddress`, `CarGatePhone`) VALUES
(1, 'aa', 'aa', 'aa'),
(2, 'bb', 'bb', 'bb'),
(3, 'vv', 'vv', 'vv'),
(4, 'ttt', 'ttt', 'ttt');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `CustomerID` int(11) NOT NULL AUTO_INCREMENT,
  `CustomerName` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `CustomerAddress` varchar(255) NOT NULL,
  PRIMARY KEY (`CustomerID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`CustomerID`, `CustomerName`, `Phone`, `Email`, `CustomerAddress`) VALUES
(12, 'yy', 'bb', 'yy', 'yy'),
(11, 'dd', 'dd', 'dd', 'dd'),
(10, 'cc', 'cc', 'cc', 'cc'),
(9, 'bb', 'bb', 'bb', 'bb'),
(8, 'aa', 'aa', 'aa', 'aa');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_delivery`
--

CREATE TABLE IF NOT EXISTS `tbl_delivery` (
  `DeliveryCode` varchar(50) NOT NULL,
  `ToD` varchar(50) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Keyword` varchar(50) NOT NULL,
  `DeliveryType` varchar(50) NOT NULL,
  `StaffID` varchar(50) NOT NULL,
  `CustomerID` varchar(50) NOT NULL,
  `DeliveryManID` varchar(50) NOT NULL,
  `CarGateID` varchar(50) NOT NULL,
  `ShopID` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `VoucherNo` varchar(50) NOT NULL,
  `Cost` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Remark` varchar(255) NOT NULL,
  `DeliveryEntry` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_delivery`
--

INSERT INTO `tbl_delivery` (`DeliveryCode`, `ToD`, `Address`, `Keyword`, `DeliveryType`, `StaffID`, `CustomerID`, `DeliveryManID`, `CarGateID`, `ShopID`, `Phone`, `VoucherNo`, `Cost`, `Status`, `Remark`, `DeliveryEntry`) VALUES
('FEB032015-0001', 'aa', 'aa', 'aa', 'Staff', '11', '8', '1', '1', '3', 'aa', 'aa', 'aa', 'Pending', 'aa', '2015/04/09'),
('FEB032015-0002', 'bb', 'bb', 'bb', 'Car', '10', '11', '1', '1', '2', 'bb', 'bb', 'bb', 'Active', 'bb', '2015/04/09'),
('FEB032015-0003', 'cc', 'cc', 'cc', 'Staff', '11', '10', '1', '1', '2', 'cc', 'cc', 'cc', 'Pending', 'cc', '2015/04/09'),
('FEB032015-0004', 'dd', 'dd', 'dd', 'Staff', '11', '12', '1', '1', '2', 'dd', 'dd', 'dd', 'Active', 'dd', '2015/04/27');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_deliveryman`
--

CREATE TABLE IF NOT EXISTS `tbl_deliveryman` (
  `DeliveryManID` int(11) NOT NULL AUTO_INCREMENT,
  `DeliveryManName` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Address` varchar(255) NOT NULL,
  PRIMARY KEY (`DeliveryManID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_deliveryman`
--

INSERT INTO `tbl_deliveryman` (`DeliveryManID`, `DeliveryManName`, `Phone`, `Email`, `Address`) VALUES
(1, 'aa', 'aa', 'aa', 'aa'),
(2, 'bb', 'bb', 'bb', 'bb');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_form`
--

CREATE TABLE IF NOT EXISTS `tbl_form` (
  `FormID` int(11) NOT NULL AUTO_INCREMENT,
  `FormName` varchar(50) NOT NULL,
  `FormAddress` varchar(255) NOT NULL,
  PRIMARY KEY (`FormID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_form`
--

INSERT INTO `tbl_form` (`FormID`, `FormName`, `FormAddress`) VALUES
(1, 'aa', 'aa'),
(2, 'bb', 'bb'),
(3, 'vv', 'vv');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_receive`
--

CREATE TABLE IF NOT EXISTS `tbl_receive` (
  `ReceiveID` varchar(50) NOT NULL,
  `CustomerID` varchar(50) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `TotalQty` varchar(50) NOT NULL,
  `DeliverQty` varchar(50) NOT NULL,
  `TakingQty` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_receive`
--

INSERT INTO `tbl_receive` (`ReceiveID`, `CustomerID`, `Address`, `TotalQty`, `DeliverQty`, `TakingQty`) VALUES
('R-000003', '10', '3', '3', '3', '3'),
('R-000002', '9', 'bb', '2', '2', '2'),
('R-000001', '8', 'aa', '1', '1', '1'),
('R-000004', '11', 'dd', '4', '4', '4'),
('R-000005', '10', '5', '6', '7', '8'),
('R-000006', '10', '6', '6', '6', '6'),
('R-000007', '12', 'aaa', '5', '5', '5');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shop`
--

CREATE TABLE IF NOT EXISTS `tbl_shop` (
  `ShopID` int(11) NOT NULL AUTO_INCREMENT,
  `ShopName` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `ShopAddress` varchar(255) NOT NULL,
  PRIMARY KEY (`ShopID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_shop`
--

INSERT INTO `tbl_shop` (`ShopID`, `ShopName`, `Phone`, `Email`, `ShopAddress`) VALUES
(2, 'bb', 'bb', 'bb', 'bb'),
(3, 'vv', 'vv', 'vv', 'vv'),
(4, 'gg', 'gg', 'gg', 'gg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staff`
--

CREATE TABLE IF NOT EXISTS `tbl_staff` (
  `StaffID` int(11) NOT NULL AUTO_INCREMENT,
  `StaffName` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  PRIMARY KEY (`StaffID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_staff`
--

INSERT INTO `tbl_staff` (`StaffID`, `StaffName`, `Password`) VALUES
(11, 'cc', 'e0323a9039add2978bf5b49550572c7c'),
(10, 'bb', '21ad0bd836b90d08f4cf640b4c298e7c'),
(12, 'aa', '4124bc0a9335c27f086f24ba207a4912');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(50) NOT NULL,
  `DOB` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Role` varchar(50) NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`UserID`, `FullName`, `DOB`, `Gender`, `Address`, `Phone`, `Email`, `UserName`, `Password`, `Role`) VALUES
(1, 'aa', 'aa', 'aa', 'aa', 'aa', 'aa', 'aa', '4124bc0a9335c27f086f24ba207a4912', 'Admin'),
(2, 'bb', 'bb', 'bb', 'bb', 'bb', 'bb', 'bb', '21ad0bd836b90d08f4cf640b4c298e7c', 'Staff');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
