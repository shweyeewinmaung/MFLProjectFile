<?php
session_start();
include("connection.php");
include("function/globalfunction.php");

if(!$_SESSION['SESS']['UserID'])
{
	header("Location:login.php");
}


$ID=Clean($_POST['hid']);
$logno=Clean($_POST['LogNo']);
$companybrand=Clean($_POST['CompanyBrand']);
$carmarks=Clean($_POST['CarMarks']);
$Model=Clean($_POST['Model']);
$horsepower=Clean($_POST['HorsePower']);
$fuel=Clean($_POST['Fuel']);
$gear=Clean($_POST['Gear']);
$kilo=Clean($_POST['Kilo']);
$Chassis=Clean($_POST['Chassis']);
$Description=Clean($_POST['Description']);

$rank=Clean($_POST['Rank']);
$carprice=Clean($_POST['carprice']);

mysql_query("UPDATE `car` SET Logno='".$logno."', Company='".$companybrand."', CarMarks='".$carmarks."', Model='".$Model."', HorsePower='".$horsepower."', Fuel='".$fuel."', Gear='".$gear."', Kilo='".$kilo."',Chassis='".$Chassis."', Description='".$Description."', Rank='".$rank."', CarPrice='".$carprice."' WHERE ID='".$ID."'")or die("Update ERROR");


$allowed =  array('gif','png' ,'jpg', 'pdf');


$Photo1 = $_FILES['txtphoto1']['name'];
$Photo2 = $_FILES['txtphoto2']['name'];
$Photo3 = $_FILES['txtphoto3']['name'];
$Photo4 = $_FILES['txtphoto4']['name'];
$Photo5 = $_FILES['txtphoto5']['name'];

//$folder = "carphoto/";
	
if($Photo1)
{ 
	$ext = pathinfo($Photo1, PATHINFO_EXTENSION);
	if(in_array($ext,$allowed) )
	{
		$File1= $folder . time() . "_" . $Photo1;
		$copied = copy($_FILES['txtphoto1']['tmp_name'], "carphoto/" . $File1);
		
		$sqlP1="UPDATE `car` SET Photo1='$File1' WHERE ID='$ID'";
		mysql_query($sqlP1);
		
		if ($copied)
		{ 			  
			
		}
	}
	
}



if($Photo2)
{ 
	$ext = pathinfo($Photo2, PATHINFO_EXTENSION);
	if(in_array($ext,$allowed) )
	{
		$File2= $folder . time() . "_" . $Photo2;
		$copied = copy($_FILES['txtphoto2']['tmp_name'], "carphoto/" . $File2);
		
		$sqlP2="UPDATE `car` SET Photo2='$File2' WHERE ID='$ID'";
		mysql_query($sqlP2);
		
		if ($copied)
		{ 			  
			
		}
	}
	
}



if($Photo3)
{ 
	$ext = pathinfo($Photo3, PATHINFO_EXTENSION);
	if(in_array($ext,$allowed) )
	{
		$File3= $folder . time() . "_" . $Photo3;
		$copied = copy($_FILES['txtphoto3']['tmp_name'], "carphoto/" . $File3);
		
		$sqlP3="UPDATE `car` SET Photo3='$File3' WHERE ID='$ID'";
		mysql_query($sqlP3);
		
		if ($copied)
		{ 			  
			
		}
	}
	
}



if($Photo4)
{ 
	$ext = pathinfo($Photo4, PATHINFO_EXTENSION);
	if(in_array($ext,$allowed) )
	{
		$File4= $folder . time() . "_" . $Photo4;
		$copied = copy($_FILES['txtphoto4']['tmp_name'], "carphoto/" . $File4);
		
		$sqlP4="UPDATE `car` SET Photo4='$File4' WHERE ID='$ID'";
		mysql_query($sqlP4);
		
		if ($copied)
		{ 			  
			
		}
	}
	
}



if($Photo5)
{ 
	$ext = pathinfo($Photo5, PATHINFO_EXTENSION);
	if(in_array($ext,$allowed) )
	{
		$File5= $folder . time() . "_" . $Photo5;
		$copied = copy($_FILES['txtphoto5']['tmp_name'], "carphoto/" . $File5);
		
		$sqlP4="UPDATE `car` SET Photo5='$File5' WHERE ID='$ID'";
		mysql_query($sqlP4);
		
		if ($copied)
		{ 			  
			
		}
	}
	
}


header("location:editdelete.php");
?>