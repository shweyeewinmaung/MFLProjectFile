<?php
	session_start();
	include("connection.php");
	require_once("function/globalfunction.php");
	
	$username=Clean($_POST['username']);
	$password=Clean($_POST['password']);
	
	$query1=mysql_query("SELECT * FROM admin WHERE username='".$username."' and password='".$password."'")or die("SELECT ERROR");
					
	$rollnumber=mysql_num_rows($query1);
	
	if($rollnumber > 0)
	{
		while($row=mysql_fetch_assoc($query1))
		{
			$_SESSION['SESS']['UserID']=$row['ID'];
		}
		header("location:adminpage.php");
	}
	else
	{
		echo "<h1 id='eh1'>Wrong Password!! Please check your Email Address or Password</h1>";
	}
?>