<?php
session_start();
?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div>
					<form action="loginvalidate.php" method="POST">
						<table style="width:800px; margin:4% auto; padding:60px; background-color:#3b5998; border-radius:10px;">
							<tr>
								<td colspan="2" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
							</tr>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<tr align="center">
								<td style="width:290px; font-size:17px; color:white;" align="right">Admin's User Name</td>
								<td><input type="text" name="username" style="width:200px;"/></td>
							</tr>
							<tr align="center">
								<td style="font-size:17px; color:white; width:200px;" align="right">Admin's Password</td>
								<td><input type="password" name="password" style="width:200px;"/></td>
							</tr>
							<tr>
								<td></br></br></td>
								<td align="center"><input type="submit" value="Log In" style="width:120px; height:30px; background-color:#19d595;"/></td>
							</tr>
						</table>
					</form>
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>