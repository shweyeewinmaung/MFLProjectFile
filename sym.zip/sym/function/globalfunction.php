<?php
function Clean($String)
{
	$Str = stripslashes($String);
	return mysql_real_escape_string($String);
}

function getRandomWord()
{
    $word = array_merge(range('a', 'z'), range('A', 'Z'), range('0', '9'));
    shuffle($word);
    return substr(implode($word), 0, 9);
}

?>