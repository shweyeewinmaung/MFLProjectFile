<?php
class pager
{
	public $pageSize,$currentPageIndex;
	public $offset,$maxPage;
	public $totalRecordCount;
	
	//Constructor
	function __construct($pageSize,$currentPageIndex)
	{
		//Page Size
		$this->pageSize=$pageSize;
		//by default we show first page
		$this->currentPageIndex=$currentPageIndex;		
		//counting the offset
		$this->offset=($currentPageIndex-1)*$pageSize;
	}	
	
	/////////////////////////// One ///////////////////////////
	
	function SearchData_CarMark($CarMark)
	{
		$sql="SELECT * FROM `car` WHERE CarMarks LIKE '%$CarMark%' ORDER BY CarMarks";
		return $sql;
	}
	
	function SearchData_Model($Model)
	{
		$sql="SELECT * FROM `car` WHERE Model LIKE '%$Model%' ORDER BY Model";
		return $sql;
	}
	
	function SearchData_Company($Company)
	{
		$sql="SELECT * FROM `car` WHERE Company LIKE '%$Company%' ORDER BY Company";
		return $sql;
	}
	
	/////////////////////////// One ///////////////////////////
	
	
	/////////////////////////// Two ///////////////////////////
	
	function SearchData_CarMarkAndModel($CarMark, $Model)
	{
		$sql="SELECT * FROM `car` WHERE CarMarks LIKE '%$CarMark%' AND Model LIKE '%$Model%' ORDER BY CarMarks";
		return $sql;
	}
	
	function SearchData_CarMarkAndCompany($CarMark, $Company)
	{
		$sql="SELECT * FROM `car` WHERE CarMarks LIKE '%$CarMark%' AND Company LIKE '%$Company%' ORDER BY CarMarks";
		return $sql;
	}
	
	function SearchData_ModelAndCompany($Model, $Company)
	{
		$sql="SELECT * FROM `car` WHERE Model LIKE '%$Model%' AND Company LIKE '%$Company%' ORDER BY CarMarks";
		return $sql;
	}
	
	/////////////////////////// Two ///////////////////////////
	
	
	/////////////////////////// Three ///////////////////////////
	
	function SearchData_All($CarMark, $Model, $Company)
	{
		$sql="SELECT * FROM `car` WHERE CarMarks LIKE '%$CarMark%' AND Model LIKE '%$Model%' AND Company LIKE '%$Company%' ORDER BY CarMarks";
		return $sql;
	}
	
	/////////////////////////// Three ///////////////////////////
	
	function GetAllCarData()
	{
		$sql="SELECT * FROM `car` ORDER BY ID DESC";
		return $sql;
	}
	
	//function Search_Data($tableName,$orderByFieldName)
	function Search_Data($str)
	{
		$sql= $str . " LIMIT $this->offset,$this->pageSize";
		$this->totalRecordCount=$this->Search_TotalRecordCount($str);
		//how many pages
		$this->maxPage=ceil($this->totalRecordCount/$this->pageSize);	
		
		$result=mysql_query($sql) or die(mysql_error());
		return $result;
	}
	/********************************************************************/	
	function Search_TotalRecordCount($sql)
	{
		//If no search key is defined
		$ret=mysql_query($sql);
		$num=mysql_num_rows($ret);
		
		return $num;					
	}
	/********************************************************************/
	function Generate_Pager($str)
	{
		/********************************************************************/
		// creating previous and next link
		// plus the link to go straight to
		// the first and last page
		/********************************************************************/				
		//the name of the current page	
		$self = $_SERVER['PHP_SELF'];
		/********************************************************************/
		// "Previous" and "First" page link
		if ($this->currentPageIndex>1)
		{

			$pageIndex=$this->currentPageIndex-1;					
			echo "<a href='$self?page=1&$str'>[First]</a>&nbsp;";
			echo "<a href='$self?page=$pageIndex&$str'>[Prev]</a>&nbsp;";							
		}
		else
		{}								
		/********************************************************************/
		// print the link to access each page

		$b=false;
		for($i=1;$i<=$this->maxPage;$i++)
		{
			if ($i==$this->currentPageIndex)
			{
				echo $i . "&nbsp;";
			}
			else
			{
				
			}
		}
		/********************************************************************/
		// "Next" and "Last" page link
		if ($this->currentPageIndex<$this->maxPage)
		{
			$pageIndex=$this->currentPageIndex+1;
			echo "<a href='$self?page=$pageIndex&$str'>[Next]</a>&nbsp;";
			echo "<a href='$self?page=$this->maxPage&$str'>[Last]</a>&nbsp;";
			echo " of total " . $this->maxPage;
		}
		else
		{}
		/********************************************************************/
	}
	/********************************************************************/
}	
?>