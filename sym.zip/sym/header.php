<script src="slidejquery/jquery.min.js"></script>
<script>
		$(function(){
		 $('.fadein img:gt(0)').hide();
		 setInterval(function(){$('.fadein :first-child').fadeOut().next('img').fadeIn().end().appendTo('.fadein');}, 3000);
		});
</script>

<script>
function CheckError()
{
	var cm = document.getElementById('cm').value;
	var m = document.getElementById('m').value;
	var b = document.getElementById('b').value;
	//alert(cm + "-" + m + "-" + b);
	if(cm=="" && m=="Model" && b=="Brand")
	{
		alert("Please enter one search key");
		return false;
	}
	else if(m=="")
	{
		return true;
	}
}
</script>
<div style="width:100%; height:23px; background-color:black; margin:0; padding:0;">
	<table style="float:left; font-size:12px; color:white; font-weight:bold; margin-left:7px;">
		<tr>
			<td>Welcome From Shwe Ya Mone Car Showroom</td>
		</tr>
	</table>
	<table style="float:right; font-size:12px;">
		<tr>
        	<?php 
				if(isset($_SESSION['SESS']['UserID'])) 
				{
					?>
                    	<td><a style="font-weight:bold; color:white; text-decoration:none; margin-right:7px;" href="adminpage.php">Admin</a> || <a style="font-weight:bold; color:white; text-decoration:none; margin-right:7px;" href="LogOut.php">Log Out</a></td>
                    <?php
				}
				else
				{
					?>
                    	<td><a style="font-weight:bold; color:white; text-decoration:none; margin-right:7px;" href="Login.php">Admin Login</a></td>
                    <?php
				}
			?>
			
		</tr>
	</table>
</div>
<div style="width:100%; height:120px; background-color:#3b5998; overflow:hidden; border-top:2px solid white; border-bottom:2px solid white; ">
	<table style="margin:8px 0 0 4%; float:left;">
		<tr>
			<td><img src="images/shweyamonefinallogo1.png" style="width:200px; height:100px;" /></td>
		</tr>
	</table>
	
	<div style="width:600px; height:100px; background-color:white; margin:1% 9% 0 0; float:right;">
			<div class="fadein">
				<img src="headeradv/1.png" />
				<img src="headeradv/2.png" />
				<img src="headeradv/3.png" />
			</div>	
	</div>
</div>
<div style="width:100%; height:34px;  background-color:black; margin:0 0 5px 0; padding:0;">
	<form action="searchresult.php" method="GET">
		<table style="float:left; font-size:12px; color:#3b5998; font-weight:bold; margin:0 0 0 4%">
			<tr>
				<td><input type="text" id="cm" name="CarMark" style="color:#666;"/></td>
				<td>
					<select id="m" name="Model" style="width:140px; color:#666;">
						<option>Model</option>
						<option>2015</option>
						<option>2014</option>
						<option>2013</option>
						<option>2012</option>
						<option>2011</option>
						<option>2010</option>
						<option>2009</option>
						<option>2008</option>
						<option>2007</option>
						<option>2006</option>
						<option>2005</option>
						<option>2004</option>
						<option>2003</option>
						<option>2002</option>
						<option>2001</option>
						<option>2000</option>
						<option>1999</option>
						<option>1998</option>
						<option>1997</option>
						<option>1996</option>
						<option>1995</option>
						<option>1994</option>
						<option>1993</option>
						<option>1992</option>
						<option>1991</option>
						<option>1990</option>
						<option>1989</option>
						<option>1987</option>
						<option>1986</option>
						<option>1985</option>
						<option>1984</option>
						<option>1983</option>
						<option>1982</option>
						<option>1981</option>
						<option>1980</option>
					</select>
				</td>
				<td>
					<select id="b" name="Brand" style="color:#666;">
						<option>Brand</option>
						<option>Alfa Romeo</option>
						<option>Aston Martin</option>
						<option>Audi</option>
						<option>BMW</option>
						<option>Bently</option>
						<option>Cadillic</option>
						<option>Chana</option>
						<option>Chery</option>
						<option>Chevrolet</option>
						<option>Chrysler</option>
						<option>Citroen</option>
						<option>Daihatsu</option>
						<option>Dodge</option>
						<option>Ferrari</option>
						<option>Fiat</option>
						<option>Ford</option>
						<option>Geely</option>
						<option>General Motors</option>
						<option>GMC</option>
						<option>Hafei</option>
						<option>Honda</option>
						<option>Hyundai</option>
						<option>Isuzu</option>
						<option>Jaguar</option>
						<option>Jeep</option>
						<option>Kia</option>
						<option>Lamborghni</option>
						<option>Land Rover</option>
						<option>Lexus</option>
						<option>Lifan</option>
						<option>Lotus</option>
						<option>MG Rover</option>
						<option>Maserati</option>
						<option>Mazda</option>
						<option>Mercedes-Benz</option>
						<option>Mini</option>
						<option>Mitsubishi</option>
						<option>Mitsuoka</option>
						<option>Morris</option>
						<option>Naza</option>
						<option>Nissan</option>
						<option>Opel</option>
						<option>Pagani</option>
						<option>Panther</option>
						<option>Perodua</option>
						<option>Peugeot</option>
						<option>Porsche</option>
						<option>Proton</option>
						<option>Renault</option>
						<option>Rolls-Royce</option>
						<option>Saab</option>
						<option>Skoda</option>
						<option>Ssangyong</option>
						<option>Subaru</option>
						<option>Suzuki</option>
						<option>TA TA</option>
						<option>Tesla Mortos</option>
						<option>Toyota</option>
						<option>Vauxhall</option>
						<option>Volkswagen</option>
						<option>Volvo</option>
						<option>Zotye</option>	
					</select>
				</td>
				<td><input type="submit" onclick="return CheckError();" value="Search" style="color:#3b5998; background-color:#19d595;"/></td>
			</tr>
		</table>
	</form>
</div>