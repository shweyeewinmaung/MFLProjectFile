<div id="searchleft">
	 <center><h1 style="font-size:25px; color:#3b5998;" >Search Result</h1></center>
		 <?php
			if($numOfRows==0 || $numOfRows<0)
			{
				echo "
					<script>alert('Does not exist')</script>
				";
			}
			if($numOfRows>0)
			{
				for($i=0;$i<$numOfRows;$i++)
				{
					$row=mysql_fetch_array($result);	
		?>
					 <div style="border:1px solid #CCC; width:80%; overflow:hidden; margin:0 auto;">
						<table style="border:1px solid white; margin:4px; float:left;">
						<tr>
							<td>
								<img src="carphoto/<?php echo $row['Photo1']; ?>" style="width:90px; height:90px;">
							</td>
						</tr>
						</table>
						<table style="float:left;">
							<tr>
								<td style="font-size:11px; color:#123456;"><a href="#"><?php echo $row['Company']; ?> - <?php echo $row['CarMarks']; ?></a></td>
							</tr>
							<tr>
								<td style="font-size:11px; color:#123456;;">Model - <?php echo $row['Model']; ?></td>
							</tr>
							<tr>
								<td style="font-size:11px; color:#123456;;">Kilo - <?php echo $row['Kilo']; ?></td>
							</tr>
							<tr>
								<td style="font-size:11px; color:#123456;;"> <?php echo $row['Description']; ?></td>
							</tr>
						</table>
						<table style="float:right; margin:5px 7px 0 0; background-color:#3b5998; border-radius:5px;">
							<tr>
								<td style="font-size:11px; color:white;"><?php echo $row['CarPrice']; ?></td>
							</tr>
						</table>
					</div>
					</br>
					<center>
					 <?php
							}
						}
					echo "-<br />";
					$objPager->Generate_Pager($str);
					?>
					</center></br>
</div>