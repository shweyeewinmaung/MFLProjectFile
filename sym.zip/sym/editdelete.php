<?php
session_start();
require_once("function/globalfunction.php");

if(!$_SESSION['SESS']['UserID'])
{
	header("Location:login.php");
}
?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div>
					<form action="deletecar.php" method="POST">
						<table style="width:90%; margin:4% auto; padding:60px; background-color:#3b5998; border-radius:10px;">
							<tr>
								<td colspan="8" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
							</tr>
							<tr>
								<td colspan="8" align="center" style="font-size:20px; color:white; ">View All Car</td>
							</tr>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<tr>
								<td id="tdforshow">ID</td>
								<td id="tdforshow">Image</td>
								<td id="tdforshow">Log No</td>
								<td id="tdforshow">Car Marks</td>
								<td id="tdforshow">Price</td>
								<td id="tdforshow">Status</td>
								<td></td>
								<td></td>
							</tr>
							<?php
								include("connection.php");
							
								$query=mysql_query("SELECT * FROM `car` ORDER BY ID")or die("SELECT ERROR");
								$i=1;
								while($row=mysql_fetch_assoc($query))
								{
									echo "<tr>";
										echo "<td id='tdforshow1'>".$i."</td>";
										echo "<td id='tdforshow1'><img style='width:100px; height:70px; padding:4px;' src='carphoto/".$row['Photo1']."'/></td>";
										echo "<td id='tdforshow1'>".$row['LogNo']."</td>";
										echo "<td id='tdforshow1'>".$row['CarMarks']."</td>";
										echo "<td id='tdforshow1'>".$row['CarPrice']."</td>";
										echo "<td id='tdforshow1'>".$row['Rank']."</td>";
										echo "<td id='tdforshow1'><a href='editcar.php?ID=" . $row['ID'] . "'>Edit</a></td>";
										echo "<td id='tdforshow1'><a href='deletecar.php?ID=" . $row['ID'] . "'>Delete</a></td>";
									echo "</tr>";
									$i+=1;
								}
							?>
								<tr>
									<td></br></td>
									<td></br></td>
								</tr>
								<tr>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td></td>
									<td><a href="adminpage.php" style="color:white; float:right; text-decoration:none;">Back</a></td>
								</tr>
						</table>
					</form>
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>