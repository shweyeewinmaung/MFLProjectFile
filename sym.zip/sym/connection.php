<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "shweyamone";


/*
$host = "localhost";
$username = "dps_symcarcentre";
$password = "symcarcentre";
$database = "dps_shweyamone-carcentre";
*/


mysql_connect($host, $username, $password) or die(mysql_error());
mysql_select_db($database) or die(mysql_error());
?>