<?php
session_start();
include("connection.php");
require_once("function/globalfunction.php");

$ID=Clean($_POST['hid']);
$name=Clean($_POST['adminname']);
$password=Clean($_POST['adminpassword']);

mysql_query("UPDATE `admin` SET username='".$name."', password='".$password."' WHERE ID='".$ID."'");

header("location:manageadmin.php");
?>