<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div>
					<table style="width:90%; margin:4% auto; padding:60px; background-color:#3b5998; border-radius:10px;">
						<tr>
							<td colspan="6" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
						</tr>
						<tr>
							<td></br></td>
							<td></br></td>
						</tr>
						<tr>
							<td id="tdforshow">ID</td>
							<td id="tdforshow">Image</td>
							<td id="tdforshow">Log No</td>
							<td id="tdforshow">CarMarks</td>
							<td id="tdforshow">Price</td>
							<td id="tdforshow">Status</td>
						</tr>
						<?php
							include("connection.php");
						
							$query=mysql_query("SELECT * FROM `car`")or die("SELECT ERROR");
							$i=1;
							while($row=mysql_fetch_assoc($query))
							{
								echo "<tr>";
									echo "<td id='tdforshow1'>".$i."</td>";
									echo "<td id='tdforshow1'><img style='width:100px; height:70px; padding:4px;' src='carphoto/".$row['Photo1']."'/></td>";
									echo "<td id='tdforshow1'>".$row['LogNo']."</td>";
									echo "<td id='tdforshow1'>".$row['CarMarks']."</td>";
									echo "<td id='tdforshow1'>".$row['CarPrice']."</td>";
									echo "<td id='tdforshow1'>".$row['Rank']."</td>";
								echo "</tr>";
								$i+=1;
							}
						?>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<tr>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td><a href="adminpage.php" style="color:white; float:right; text-decoration:none;">Back</a></td>
							</tr>
					</table>
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>