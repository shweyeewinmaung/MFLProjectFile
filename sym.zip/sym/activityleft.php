<form enctype="multipart/form-data">
<div id="activityleft">
	
	<table style="width:97%; margin:1% 0 0 3%; padding:10px 0 10px 20px; border:1px solid #CCC;">
		<tr>
			<td colspan="2"><h2 style="color:#3b5998;">News Latest</h2></td>
		</tr>
		<?php
			include("connection.php");
							
			$news=mysql_query("SELECT * FROM `news` Order By ID DESC LIMIT 4")or die("SELECT ERROR");
			
			while($row3=mysql_fetch_assoc($news))
			{
		?>
		<tr>
			<td>Title</td>
			<td align="left"><?php echo $row3['Title']; ?></td>
		</tr>
		<tr>
			<td>Date</td>
			<td align="left"><?php echo $row3['Date']; ?></td>
		</tr>
		<tr>
			<td></td>
			<td align="left"><?php echo $row3['Description']; ?></td>
		</tr>
		
			
		<tr>
			<td></td>
			<td>--------------------------------------------------------</br></td>
		</tr>
		<?php
			}
		?>
	</table>
		<center><a style="text-decoration:none;" href="allactivity.php?Action=News"><h1>see more</h1></a></center>
</div>
</form>