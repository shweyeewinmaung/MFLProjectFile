<div id="activityleft">
	<div style="border:1px solid #CCC; width:95%; overflow:hidden; margin:5px auto;">
	 <center><h1 style="font-size:25px; color:#3b5998;" >Car List</h1></center>
		<?php
			for($i=0;$i<$numOfRows;$i++)
			{
				$row=mysql_fetch_array($result);
				
		?>
		<div style="border:1px solid #CCC; width:80%; overflow:hidden; margin:0 auto;">
		<a href="CarDetail.php?ID=<?php echo $row['ID']; ?>">
			<table style="border:1px solid white; float:left;">
				<tr>
					<td>
						<img src="carphoto/<?php echo $row['Photo1']; ?>" style="width:90px; height:90px;">
					</td>
				</tr>
			</table>
			<table style="float:left;">
				<tr>
					<td style="font-size:11px; color:#123456;"><a href="#"><?php echo $row['Company']; ?> - <?php echo $row['CarMarks']; ?></a></td>
				</tr>
				<tr>
					<td style="font-size:11px; color:#123456;">Model - <?php echo $row['Model']; ?></td>
				</tr>
				<tr>
					<td style="font-size:11px; color:#123456;">Kilo - <?php echo $row['Kilo']; ?></td>
				</tr>
				<tr>
					<td style="font-size:11px; color:#123456;"> <?php echo substr($row['Description'], 0, 600); ?></td>
				</tr>
			</table>
			<table style="float:right; margin:5px 7px 0 0; background-color:#3b5998; border-radius:5px;">
				<tr>
					<td style="font-size:11px; color:white;"><?php echo $row['CarPrice']; ?></td>
				</tr>
			</table>
			
		</div>
			</br>
			<?php
				}
			?>
		</div>
	<center>
	<?php
		$objPager->Generate_Pager($str);
	?>
      </center>
	  </br>
</div>