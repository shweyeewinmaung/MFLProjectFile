<?php
session_start();

if(!$_SESSION['SESS']['UserID'])
{
	header("Location:login.php");
}
?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div>
					<form action="saveadmin.php" method="POST">
						<table style="width:900px; margin:4% auto; padding:60px; background-color:#3b5998; border-radius:10px;">
							<tr>
								<td colspan="2" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
							</tr>
							<tr>
								<td colspan="2" align="center" style="font-size:20px; color:white; ">Add New Admin</td>
							</tr>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<tr align="center">
								<td style="width:290px; font-size:17px; color:white;" align="center">Admin User Name</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="text" name="adminname"/></td>
							</tr>
							<tr align="center">
								<td style="width:290px; font-size:17px; color:white;" align="center">Admin Password</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="password" name="adminpassword"/></td>
							</tr>
							<tr align="center">
								<td style="width:290px; font-size:17px; color:white;" align="center"></td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="submit" value="Add New Admin" style="background-color:#19d595; color:white;"/></td>
							</tr>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<tr>
								<td></td>
								<td><a href="adminpage.php" style="color:white; float:right; text-decoration:none;">Back</a></td>
							</tr>
						</table>
					</form>
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>