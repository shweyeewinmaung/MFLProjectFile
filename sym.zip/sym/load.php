<?php
	include("connection.php");
	$sql="ALTER TABLE  `news` CHANGE  `Description`  `Description` TEXT ";
	mysql_query($sql);
?>