<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div>
					<form action="saveadmin.php" method="POST">
						<table style="width:900px; margin:4% auto; padding:60px; background-color:#3b5998; border-radius:10px;">
							<tr>
								<td colspan="5" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
							</tr>
							<tr>
								<td colspan="5" align="center" style="font-size:20px; color:white; ">Add New Admin</td>
							</tr>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<tr>
									<td id="tdforshow">ID</td>
									<td id="tdforshow">Name</td>
									<td id="tdforshow">Password</td>
									<td></td>
									<td></td>
							<tr>
							<?php
								include("connection.php");
							
								$query=mysql_query("SELECT * FROM admin")or die("SELECT ERROR");
								$i=1;
								while($row=mysql_fetch_assoc($query))
								{
									?>
									<tr>
										<td id="tdforshow1"><?php echo $i;?></td>
										<td id="tdforshow1"><?php echo $row['username'];?></td>
										<td id="tdforshow1"><?php echo $row['password'];?></td>
										<td id="tdforshow1"><a href="editadmin.php?ID=<?php echo $row['ID']; ?>">Edit</a></td>
										<td id="tdforshow1"><a href="deleteadmin.php?ID=<?php echo $row['ID']; ?>">Delete</a></td>
									</tr>
									<?php
									$i+=1;
								}
							?>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<tr>
								<td colspan="4"></td>
								<td><a href="adminpage.php" style="color:white; float:right; text-decoration:none;">Back</a></td>
							</tr>
						</table>
					</form>
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>