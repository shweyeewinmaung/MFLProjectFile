<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div>
                <?php
					if($_GET['Action']=="Video" || $_GET['Action']=="video")
					{
						?>
                            <table style="width:90%; margin:4% auto; padding:60px; background-color:#3b5998; border-radius:10px;">
                            <tr>
                                <td colspan="5" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
                            </tr>
                            <tr>
                                <td></br></td>
                                <td></br></td>
                            </tr>
		                    <?php
								include("connection.php");
												
								$video=mysql_query("SELECT * FROM `video`")or die("SELECT ERROR");
								
								while($row=mysql_fetch_assoc($video))
								{
							?>
							<tr>
								<td>Title</td>
								<td><?php echo $row['Title']; ?></td>
							</tr>
							<tr>
								<td>Date</td>
								<td><?php echo $row['Date']; ?></td>
							</tr>
							<tr>
								<td >Description</td>
								<td align="left"><?php echo $row['Description']; ?></td>
							</tr>
							<tr>
								<td colspan="2"> 
									<video width="320" height="240" controls>
										 <source src="uploadvideo/Y.mp4">
									</video> 
								</td>
							</tr>
							<tr>
                                <td></br></td>
                                <td></br></td>
                            </tr>
						<?php
								}
						?>
                             
                        	</table>
                        <?php
					}
					elseif($_GET['Action']=="Image" || $_GET['Action']=="image")
					{
						?>
                        	<table style="width:90%; margin:4% auto; padding:60px; background-color:#3b5998; border-radius:10px;">
                            <tr>
                                <td colspan="5" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
                            </tr>
                            <tr>
                                <td></br></td>
                                <td></br></td>
                            </tr>
 
                             <?php
								include("connection.php");
												
								$video=mysql_query("SELECT * FROM `image`")or die("SELECT ERROR");
								
								while($row=mysql_fetch_assoc($video))
								{
							?>
							<tr>
								<td>Title</td>
								<td><?php echo $row['Title']; ?></td>
							</tr>
							<tr>
								<td>Date</td>
								<td><?php echo $row['Date']; ?></td>
							</tr>
							<tr>
								<td >Description</td>
								<td align="left"><?php echo $row['Description']; ?></td>
							</tr>
							<tr>
								<td colspan="2"> 
									<img src="uploadimage/<?php echo $row['img1']; ?>" width="150" height="150"/>
									<img src="uploadimage/<?php echo $row['img2']; ?>" width="150" height="150"/>
									<img src="uploadimage/<?php echo $row['img3']; ?>" width="150" height="150"/>
									<img src="uploadimage/<?php echo $row['img4']; ?>" width="150" height="150"/>
									<img src="uploadimage/<?php echo $row['img5']; ?>" width="150" height="150"/>
								</td>
							</tr>
							<tr>
                                <td></br></td>
                                <td></br></td>
                            </tr>
						<?php
								}
						?>
                               
                        	</table>
                        <?php
					}
					
					elseif($_GET['Action']=="News" || $_GET['Action']=="news")
					{
						?>
                        	<table style="width:90%; margin:4% auto; padding:60px; background-color:#3b5998; color:white; border-radius:10px;">
                            <tr>
                                <td colspan="5" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
                            </tr>
                            <tr>
                                <td></br></td>
                                <td></br></td>
                            </tr>
                            <?php
								include("connection.php");
												
								$video=mysql_query("SELECT * FROM `news`")or die("SELECT ERROR");
								
								while($row=mysql_fetch_assoc($video))
								{
							?>
							<tr>
								<td>Title</td>
								<td style="text-decoration:underline;"><?php echo $row['Title']; ?></td>
							</tr>
							<tr>
								<td>Date</td>
								<td><?php echo $row['Date']; ?></td>
							</tr>
							<tr>
								<td ></td>
								<td align="left"><?php echo $row['Description']; ?></td>
							</tr>
							<tr>
                                    <td></br></td>
                                    <td></br></td>
                            </tr>
						<?php
								}
						?>
                               
                        	</table>
                        <?php
					}
					else
					{
						?>
                        	<table style="width:90%; margin:4% auto; padding:60px; background-color:#3b5998; border-radius:10px;">
                                <tr>
                                    <td colspan="5" align="center" style="font-size:25px; color:white; ">Invalid</td>
                                </tr>
                        	</table>
                        <?php
					}
				
				?>
					
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>