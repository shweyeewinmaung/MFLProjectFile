<?php
session_start();

if(!$_SESSION['SESS']['UserID'])
{
	header("Location:login.php");
}
?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div>
					<table style="width:900px; margin:4% auto; padding:20px; background-color:#3b5998; border-radius:10px;">
						<tr>
							<td colspan="2" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
						</tr>
						<tr>
							<td></br></td>
							<td></br></td>
						</tr>
						<tr>
							<td style="padding-left:10%;"><a href="addnewcar.php" style="text-decoration:none; font-size:19px; color:white;">- Add New Car</a></td>
							<td style="padding-left:10%;"><a href="uploadvideoimagesnew.php" style="text-decoration:none; font-size:19px; color:white;">- Upload Video/Images/News</a></td>
						</tr>
						<tr>
							<td style="padding-left:10%;"><a href="viewallcar.php" style="text-decoration:none; font-size:19px; color:white;">- View All Car</a></td>
							<td style="padding-left:10%;"><a href="viewallactivity.php" style="text-decoration:none; font-size:19px; color:white;">- Delete Video/Images/News</a></td>
						</tr>
						<tr>
							<td style="padding-left:10%;"><a href="editdelete.php" style="text-decoration:none; font-size:19px; color:white;">- Edit/Delete Car </a></td>
							<td style="padding-left:10%;"><a href="#" style="text-decoration:none; font-size:19px; color:white;">- Logout</a></td>
						</tr>
						<tr>
							<td style="padding-left:10%;"><a href="addadmin.php" style="text-decoration:none; font-size:19px; color:white;">- Add New Admin</a></td>
							<td style="padding-left:10%;"><a href="#" style="text-decoration:none; font-size:19px; color:white;"></a></td>
						</tr>
						<tr>
							<td style="padding-left:10%;"><a href="manageadmin.php" style="text-decoration:none; font-size:19px; color:white;">- Manage Admin</a></td>
							<td style="padding-left:10%;"><a href="#" style="text-decoration:none; font-size:19px; color:white;"></a></td>
						</tr>
						<tr>
							<td style="padding-left:10%;"><a href="#" style="text-decoration:none; font-size:19px; color:white;"></a></td>
							<td style="padding-left:10%;"><a href="logout.php" style="text-decoration:none; font-size:19px; color:white;"></a></td>
						</tr>
					</table>
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>