<?php
	session_start();
	
	if(!$_SESSION['SESS']['UserID'])
	{
		header("Location:login.php");
	}
	
	include("connection.php");
	require_once("function/globalfunction.php");
	
	$title=Clean($_POST['title']);
	$description=Clean($_POST['description']);
	$date=Clean($_POST['date']);
	$news="-";
	
	mysql_query("INSERT INTO `news` (Title,Description,Date,news) VALUES ('".$title."','".$description."','".$date."','".$news."')")or die("INSERT ERROR");
	
	header("location:uploadvideoimagesnew.php");
?>