<div style="width:100%; height:70px; background-color:#3b5998; margin-top:6px; float:left; border-top:2px solid white; border-bottom:2px solid white;">
	<center>
		<ul id="navbarforfooter">
			<li><a href="home.php">Home</a></li>
			<li><a href="activity.php">Activity</a></li>
			<li><a href="service.php">Service</a></li>
			<li><a href="contactus.php">Contact US</a></li>
		</ul>
	</center>
</div>