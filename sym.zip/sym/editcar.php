<?php
session_start();
include("connection.php");
require_once("function/globalfunction.php");

if(!$_SESSION['SESS']['UserID'])
{
	header("Location:login.php");
}

$ID=Clean($_GET['ID']);	
?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div>
					<form action="updatecar.php" method="POST" enctype="multipart/form-data">
						<table style="width:900px; margin:10% auto; padding:20px; background-color:#3b5998; border-radius:10px;">
							<tr>
								<td colspan="2" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
							</tr>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<tr>
								<td colspan="2" align="center" style="font-size:20px; color:#19d595;">Edit Car</td>
							</tr>
							<?php
								
								$query=mysql_query("SELECT * FROM `car` WHERE ID='".$ID."'")or die("SELECT ERROR");
							
								while($row=mysql_fetch_assoc($query))
									{
							?>
							<tr>
								<td align="right" style="color:white;"></td>
								<td><input type="hidden" name="hid" value="<?php echo $ID ?>"/></td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Log No</td>
								<td><input type="text" name="LogNo" value="<?php echo $row['LogNo']; ?>"/></td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Company Brand</td>
								<td>
									<select name="CompanyBrand">
										<option value="<?php echo $row['Company']; ?>"><?php echo $row['Company']; ?></option>
										<option value="Alfa Romeo">Alfa Romeo</option>
										<option value="Aston Martin">Aston Martin</option>
										<option value="Audi">Audi</option>
										<option value="BMW">BMW</option>
										<option value="Bently">Bently</option>
										<option value="Cadillic">Cadillic</option>
										<option value="Chana">Chana</option>
										<option value="Chery">Chery</option>
										<option value="Chevrolet">Chevrolet</option>
										<option value="Chrysler">Chrysler</option>
										<option value="Citroen">Citroen</option>
										<option value="Daihatsu">Daihatsu</option>
										<option value="Dodge">Dodge</option>
										<option value="Fiat">Fiat</option>
										<option value="Ford">Ford</option>
										<option value="Geely">Geely</option>
										<option value="General Motors">General Motors</option>
										<option value="GMC">GMC</option>
										<option value="Hafei">Hafei</option>
										<option value="Honda">Honda</option>
										<option value="Hyundai">Hyundai</option>
										<option value="Isuzu">Isuzu</option>
										<option value="Jaguar">Jaguar</option>
										<option value="Jeep">Jeep</option>
										<option value="Kia">Kia</option>
										<option value="Lamborghni">Lamborghni</option>
										<option value="Land Rover">Land Rover</option>
										<option value="Lexus">Lexus</option>
										<option value="Lifan">Lifan</option>
										<option value="Lotus">Lotus</option>
										<option value="MG Rover">MG Rover</option>
										<option value="Maserati">Maserati</option>
										<option value="Mazda">Mazda</option>
										<option value="ercedes-Benz">Mercedes-Benz</option>
										<option value="Mini">Mini</option>
										<option value="Mitsubishi">Mitsubishi</option>
										<option value="Mitsuoka">Mitsuoka</option>
										<option value="Morris">Morris</option>
										<option value="Naza">Naza</option>
										<option value="Nissan">Nissan</option>
										<option value="Opel">Opel</option>
										<option value="Pagani">Pagani</option>
										<option value="Panther">Panther</option>
										<option value="Perodua">Perodua</option>
										<option value="Peugeot">Peugeot</option>
										<option value="Porsche">Porsche</option>
										<option value="Proton">Proton</option>
										<option value="Renault">Renault</option>
										<option value="Rolls">Rolls-Royce</option>
										<option value="Saab">Saab</option>
										<option value="Skoda">Skoda</option>
										<option value="Ssangyong">Ssangyong</option>
										<option value="Subaru">Subaru</option>
										<option value="Suzuki">Suzuki</option>
										<option value="TA TA">TA TA</option>
										<option value="Tesla Mortos">Tesla Mortos</option>
										<option value="Toyota">Toyota</option>
										<option value="Vauxhall">Vauxhall</option>
										<option value="Volkswagen">Volkswagen</option>
										<option value="Volvo">Volvo</option>
										<option value="Zotye">Zotye</option>	
									</select>
								</td>
							</tr>
							<tr>
								<td align="right" style="color:white;">CarMarks</td>
								<td><input type="text" name="CarMarks" value="<?php echo $row['CarMarks']; ?>"/></td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Model</td>
								<td><input type="text" name="Model" value="<?php echo $row['Model']; ?>"/></td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Engine Power</td>
								<td><input type="text" name="HorsePower" value="<?php echo $row['HorsePower']; ?>"/></td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Fuel</td>
								<td><input type="text" name="Fuel" value="<?php echo $row['Fuel']; ?>"/></td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Gear</td>
								<td><input type="text" name="Gear" value="<?php echo $row['Gear']; ?>"/></td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Kilo</td>
								<td><input type="text" name="Kilo" value="<?php echo $row['Kilo']; ?>"/></td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Chassis</td>
								<td><input type="text" name="Chassis" value="<?php echo $row['Chassis']; ?>"/></td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Description</td>
								<td>
									<textarea name="Description" rows="6" cols="60"><?php echo $row['Description']; ?></textarea>
								</td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Car Photo 1</td>
								<td>
									<img src="carphoto/<?php echo $row['Photo1']; ?>" width="120" height="80" />
									<input type="file" name="txtphoto1" />
								</td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Car Photo 2</td>
								<td>
									<img src="carphoto/<?php echo $row['Photo2']; ?>" width="120" height="80" />
									<input type="file" name="txtphoto2" />
								</td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Car Photo 3</td>
								<td>
									<img src="carphoto/<?php echo $row['Photo3']; ?>" width="120" height="80" />
									<input type="file" name="txtphoto3" />
								</td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Car Photo 4</td>
								<td>
									<img src="carphoto/<?php echo $row['Photo4']; ?>" width="120" height="80" />
									<input type="file" name="txtphoto4" />
								</td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Car Photo 5</td>
								<td>
									<img src="carphoto/<?php echo $row['Photo5']; ?>" width="120" height="80" />
									<input type="file" name="txtphoto5" />
								</td>
							</tr>
							<tr>
								<td align="right" style="color:white;">Rank</td>
								<td>
									<select name="Rank">
										<?php
											if($row['Rank']=="Popular")
											{
												?>
													<option value="<?php echo $row['Rank']; ?>"><?php echo $row['Rank']; ?></option>
													<option value="Favourite">Favourite</option>
													<option value="Normal">Normal</option>
												<?php
											}
											
											else if ($row['Rank']=="Favourite") 
											{
												?>
													<option value="<?php echo $row['Rank']; ?>"><?php echo $row['Rank']; ?></option>
													<option value="Popular">Popular</option>
													<option value="Normal">Normal</option>
												<?php
											}
											else if ($row['Rank']=="Normal")
											{
												?>
													<option value="<?php echo $row['Rank']; ?>"><?php echo $row['Rank']; ?></option>
													<option value="Popular">Popular</option>
													<option value="Favourite">Favourite</option>
												<?php
											}
										?>
									</select>
								</td>
							</tr>
							<tr>
								<td align="right" style="color:white;" >Price</td>
								<td><input type="text" name="carprice" value="<?php echo $row['CarPrice']; ?>"/></td>
							</tr>
							<tr>
								<td></td>
								<td><input type="submit" value="Update" style="width:130px; background-color:#19d595;"/></td>
							</tr>
							<tr>
								<td></td>
								<td><a href="adminpage.php" style="color:white; float:right; text-decoration:none;">Back</a></td>
							</tr>
							<?php
								}
							?>
						</table>
					</form>
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>