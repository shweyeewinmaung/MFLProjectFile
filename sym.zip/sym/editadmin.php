<?php
session_start();
include("connection.php");
require_once("function/globalfunction.php");

if(!$_SESSION['SESS']['UserID'])
{
	header("Location:login.php");
}

$ID=Clean($_GET['ID']);	

?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div>
					<form action="updateadmin.php" method="POST">
						<table style="width:900px; margin:10% auto; padding:60px; background-color:#3b5998; border-radius:10px;">
							<tr>
								<td colspan="2" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
							</tr>
							<tr>
								<td colspan="2" align="center" style="font-size:20px; color:white; ">Add New Admin</td>
							</tr>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<?php
								
								$query=mysql_query("SELECT * FROM `admin` WHERE ID='".$ID."'")or die("SELECT ERROR");
							
								while($row=mysql_fetch_assoc($query))
									{
							?>
							<tr align="center">
								<td style="width:290px; font-size:17px; color:white;" align="center"></td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="hidden" name="hid" value="<?php echo $row['ID']; ?>"/></td>
							</tr>
							<tr align="center">
								<td style="width:290px; font-size:17px; color:white;" align="center">Admin User Name</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="text" name="adminname" value="<?php echo $row['username']; ?>"/></td>
							</tr>
							<tr align="center">
								<td style="width:290px; font-size:17px; color:white;" align="center">Admin Password</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="password" name="adminpassword" value="<?php echo $row['password']; ?>"/></td>
							</tr>
							<tr align="center">
								<td style="width:290px; font-size:17px; color:white;" align="center"></td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="submit" value="Edit  Admin" style="background-color:#19d595; color:white;"/></td>
							</tr>
							<?php
									}
							?>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<tr>
								<td></td>
								<td><a href="adminpage.php" style="color:white; float:right; text-decoration:none;">Back</a></td>
							</tr>
						</table>
					</form>
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>