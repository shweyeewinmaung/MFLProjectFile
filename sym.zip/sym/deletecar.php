<?php
session_start();
include("connection.php");
require_once("function/globalfunction.php");

if(!$_SESSION['SESS']['UserID'])
{
	header("Location:login.php");
}

if($_GET['ID']=="")
{
	echo $_GET['ID'];
	header("Location:home.php");
}

$ID=Clean($_GET['ID']);	
$sql="SELECT * FROM `car` WHERE ID='$ID'";
$ret=mysql_query($sql);
$num=mysql_num_rows($ret);
if($num>0)
{
	$row=mysql_fetch_array($ret);
}
elseif($num<1)
{
	
}


if(isset($_POST['HiddenID']))
{
	$ID=Clean($_POST['HiddenID']);	
	$sql1="SELECT * FROM `car` WHERE ID='$ID'";
	$ret1=mysql_query($sql1);
	$num1=mysql_num_rows($ret1);
	if($num1>0)
	{
		$row1=mysql_fetch_array($ret1);
	
		if($row1['Photo1']!="")
		{
			unlink("carphoto/" . $row1['Photo1']);
		}
		
		if($row1['Photo2']!="")
		{
			unlink("carphoto/" . $row1['Photo2']);
		}
		
		if($row1['Photo3']!="")
		{
			unlink("carphoto/" . $row1['Photo3']);
		}
		
		if($row1['Photo4']!="")
		{
			unlink("carphoto/" . $row1['Photo4']);
		}
		
		if($row1['Photo5']!="")
		{
			unlink("carphoto/" . $row1['Photo5']);
		}
		
		$sql="DELETE FROM `car` WHERE ID='$ID'";
		
		mysql_query($sql);
		header("location:editdelete.php");
	}
	elseif($num<1)
	{
		header("Location:adminpage.php");
	}
}

?>

<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/photo.css" />
    <script src="img_files/jquery.js" type="text/javascript"></script>
    <script src="img_files/main.js" type="text/javascript"></script>
    <script src="img_files/pro.js" type="text/javascript" id="_adpacks_projs"></script>
    <script async="async" src="img_files/a" id="_bsaPRO_js" type="text/javascript"></script>
    <style id="bsa_css">.one{position:relative}.one .bsa_it_ad{display:block;padding:15px;border:1px solid #e1e1e1;background:#f9f9f9;font-family:helvetica,arial,sans-serif;line-height:100%;position:relative}.one .bsa_it_ad a{text-decoration:none}.one .bsa_it_ad a:hover{text-decoration:none}.one .bsa_it_ad .bsa_it_t{display:block;font-size:12px;font-weight:bold;color:#212121;line-height:125%;padding:0 0 5px 0}.one .bsa_it_ad .bsa_it_d{display:block;color:#434343;font-size:12px;line-height:135%}.one .bsa_it_ad .bsa_it_i{float:left;margin:0 15px 10px 0}.one .bsa_it_p{display:block;text-align:right;position:absolute;bottom:10px;right:15px}.one .bsa_it_p a{font-size:10px;color:#666;text-decoration:none}.one .bsa_it_ad .bsa_it_p a:hover{font-style:italic}
</style>
<title><?php if($num>0){ echo $row['CarMarks'] . " 's Detail";}else{ echo "Sorry! Not available"; } ?></title>

<script>
function FillImg(v, no)
{
	document.getElementById('PIC').innerHTML="";
	
	document.getElementById("PIC").style.backgroundColor="gray";
	//alert(no);
	var img = document.createElement("IMG");
	img.src = "carphoto/"+v;
	img.style.height = '100%';
	img.style.width = '100%';
	document.getElementById('PIC').appendChild(img);
	
	if(no=="" || no==1 || no=="undefined")
	{
		document.getElementById('PICID').value=1;
	}
	else if(no>1)
	{
		document.getElementById('PICID').value=no;
	}
}

function ClickPIC()
{
	location.href = 'ViewPhoto.php?ID=' + document.getElementById('HID').value + '&PIC=' + document.getElementById('PICID').value;
}

function ClickPicture(no)
{
	location.href = 'ViewPhoto.php?ID=' + document.getElementById('HID').value + '&PIC=' + no;
}
</script>

</head>
	<body style="background-color:#CCC;" onLoad="FillImg('<?php echo $row['Photo1']; ?>')">
    <form method="post">
    <input type="hidden" id="HID" name="HiddenID" value="<?php echo $row['ID']; ?>">
    <input type="hidden" id="PICID" value="<?php echo 1; ?>">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div style="width:900px; margin:4% auto; padding:60px; background-color:#3b5998; border-radius:10px; ">
                	<?php
						if($num>0)
						{
							//$row=mysql_fetch_array($ret);
							?>
                            	<center><h1 style="font-size:25px; color:white;" >Welcome From Shwe Ya Mone</h1></center>
                                    </br></br></br>
                                <div style="border:1px solid white; width:80%; overflow:hidden; margin:0 auto;">
                                    <table style="margin:4px; float:left;">
                                        <tr>
                                           <td>
                                           		<div onClick="ClickPIC()" id="PIC" style="width:320px; height:300px; padding:6px; border:2px solid white;">
                                                </div>
                                           </td>
                                        </tr>
                                        <tr>
                                            <td>
                                               <ul>
                                               		<li onMouseOver="FillImg('<?php echo $row['Photo1']; ?>', 1)"><img src="carphoto/<?php echo $row['Photo1']; ?>" onClick="ClickPicture(1)" style="width:55px; height:65px; border:2px solid white;" alt="gallery thumbnail"></a></li>
													<li onMouseOver="FillImg('<?php echo $row['Photo2']; ?>', 2)"><img src="carphoto/<?php echo $row['Photo2']; ?>" onClick="ClickPicture(2)" style="width:55px; height:65px; border:2px solid white;" alt="gallery thumbnail"></a></li>
                                                    <li onMouseOver="FillImg('<?php echo $row['Photo3']; ?>', 3)"><img src="carphoto/<?php echo $row['Photo3']; ?>" onClick="ClickPicture(3)" style="width:55px; height:65px; border:2px solid white;" alt="gallery thumbnail"></a></li>
                                                    <li onMouseOver="FillImg('<?php echo $row['Photo4']; ?>', 4)"><img src="carphoto/<?php echo $row['Photo4']; ?>" onClick="ClickPicture(4)" style="width:55px; height:65px; border:2px solid white;" alt="gallery thumbnail"></a></li>
                                                    <li onMouseOver="FillImg('<?php echo $row['Photo5']; ?>', 5)"><img src="carphoto/<?php echo $row['Photo5']; ?>" onClick="ClickPicture(5)" style="width:55px; height:65px; border:2px solid white;" alt="gallery thumbnail"></a></li>
												</ul>
                                           </td>	
                                        </tr>
                                    </table>
                                    <table style="margin:4px; float:left; padding:20px; color:white;">
                                        <tr>
                                            <td>LogNo</td>
                                            <td> - <?php echo $row['LogNo']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Company</td>
                                            <td> - <?php echo $row['Company']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>CarMarks</td>
                                            <td> - <?php echo $row['CarMarks']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Model</td>
                                            <td> - <?php echo $row['Model']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Engine Power</td>
                                            <td> - <?php echo $row['HorsePower']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Fuel</td>
                                            <td> - <?php echo $row['Fuel']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Gear</td>
                                            <td> - <?php echo $row['Gear']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Kilo</td>
                                            <td> - <?php echo $row['Kilo']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Chassis</td>
                                            <td> - <?php echo $row['Chassis']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Price</td>
                                            <td> - <?php echo $row['CarPrice']; ?></td>
                                        </tr>
										 <tr>
                                            <td colspan="2"><input type="submit" value="Confirm Delete" /></td>
                                        </tr>
                                    </table>
									</br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br>
									<div style="color:white; margin:0 0 2% 2%;">
                                     <p3>Description - </p3>
                                     <p3><?php echo $row['Description']; ?></p3>
									 </div>
                                </div>
                            <?php
						}
						else
						{
							?>
                            	<center>
                                <h1 style="font-size:25px; color:white;" >Welcome From Shwe Ya Mone</h1>
                                <div style="width:100%; height:200px; background-color:yellow;">
                                    <h5 style="font-size:60px; color:red; padding:3% 0 0 0"; overflow:hidden;>Warning!!! Car Does Not Exist!!!</h5>
                                </div>
                                </center>
                            <?php
						}
					?>
                    
                </div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
        </form>
	</body>
    
</html>