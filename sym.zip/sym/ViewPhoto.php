<?php
session_start();
include("connection.php");
require_once("function/globalfunction.php");


if($_GET['ID']=="" && $_GET['PIC']=="")
{
	header("Location:home.php");
}

$ID=Clean($_GET['ID']);
$PIC=Clean($_GET['PIC']);

$sql="SELECT * FROM `car` WHERE ID='$ID'";
$ret=mysql_query($sql);
$num=mysql_num_rows($ret);
if($num>0)
{
	$row=mysql_fetch_array($ret);
}

if($PIC==1)
{
	echo "<img src=carphoto/" . $row['Photo1'] . ">";
}
elseif($PIC==2)
{
	echo "<img src=carphoto/" . $row['Photo2'] . ">";
}
elseif($PIC==3)
{
	echo "<img src=carphoto/" . $row['Photo3'] . ">";
}
elseif($PIC==4)
{
	echo "<img src=carphoto/" . $row['Photo4'] . ">";
}
elseif($PIC==5)
{
	echo "<img src=carphoto/" . $row['Photo5'] . ">";
}


?>