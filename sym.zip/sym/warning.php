<center>
<div style="width:100%; height:200px; background-color:yellow;">
	<h5 style="font-size:60px; color:red; padding:3% 0 0 0"; overflow:hidden;>Warning!!! Car Does Not Exist!!!</h5>
</div>
</center>