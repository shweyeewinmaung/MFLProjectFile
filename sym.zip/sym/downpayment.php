<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Calculation</title>
<script>

var _RF, _SC, _IP, _DownPayment;

function DisplayFees()
{
	var str=document.getElementById('LTY').value;
	if(str=="1 Year")
	{
		document.getElementById('RF').innerHTML="1 year for 7% rental fees";
		document.getElementById('SC').innerHTML="1 year for 2.1% service charges + 11000";
		_RF=7/100;
		_SC=2.1/100;
	}
	else if(str=="2 Year")
	{
		document.getElementById('RF').innerHTML="2 year for 11% rental fees";
		document.getElementById('SC').innerHTML="2 year for 3.1% service charges + 11000";
		_RF=11/100;
		_SC=3.1/100;
	}
	else if(str=="3 Year")
	{
		document.getElementById('RF').innerHTML="3 year for 16% rental fees";
		document.getElementById('SC').innerHTML="3 year for 4.1% service charges + 11000";
		_RF=16/100;
		_SC=4.1/100;
	}
	else
	{
		document.getElementById('RF').innerHTML="";
		document.getElementById('SC').innerHTML="";
		_RF="";
		_SC="";
	}
	//alert(_RF + " " + _SC + " " + _IP);
}

function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function Calculate()
{
	var ca, ip, _Pay, _Remain, _Year;
	ca=document.getElementById('A').value;
	ip=document.getElementById('IP').value;
	_Year=document.getElementById('LTY').value;
	
	if(ip=="30%")
	{
		ip=30;
	}
	else if(ip=="40%")
	{
		ip=40;
	}
	else if(ip=="50%")
	{
		ip=50;
	}
	
	
	if(_Year=="1 Year")
	{
		_Year=parseFloat("12");
	}
	else if(_Year=="2 Year")
	{
		_Year=parseFloat("24");
	}
	else if(_Year=="3 Year")
	{
		_Year=parseFloat("36");
	}
	
	
	_Pay=parseFloat(parseFloat(ca) * parseFloat(ip) / 100);
	_Remain=(parseFloat(ca) - _Pay) * parseFloat(_RF);
	//alert(_Remain);
	_ServiceCharge=(parseFloat(ca) * parseFloat(_SC)) + parseFloat("11000");
	//_DownPayment=_Pay + " " + _Remain + " " + ServiceCharge;
	_DownPayment=_Pay + _Remain + _ServiceCharge;
	document.getElementById('DP').innerHTML=numberWithCommas(_DownPayment);
	
	//-------------------------- Down Payment Finished -------------------------- //
	
	document.getElementById('Remain').innerHTML=numberWithCommas(parseInt((parseFloat(document.getElementById('A').value) - _Pay) / _Year));
	//alert((parseFloat(document.getElementById('A').value) - _Pay) + " " + _Year);
	
	//-------------------------- Monthly Payment Finished -------------------------- //
	
	document.getElementById('TA').innerHTML=numberWithCommas(_DownPayment + (parseFloat(document.getElementById('A').value) - _Pay));
	
}
</script>
</head>

<body>
<form>
	<table>
			<tr>
				<td style="color:#666;">Car Amount</td>
				<td><input id="A" type="text" onkeyup="Fill()" style="color:#666;"/></td>
			</tr>
			<tr>
				<td style="color:#666;">Interest Percentage</td>
				<td style="color:#666;">
					<select id="IP" style="color:#666;">
						<option>30%</option>
						<option>40%</option>
						<option>50%</option>
					</select>
				</td>
			</tr>
			<tr>
				<td style="color:#666;">Loan Term Year</td>
				<td>
					<select id="LTY" onchange="DisplayFees()" style="color:#666;">
                    	<option>Select Year</option>
						<option>1 Year</option>
						<option>2 Year</option>
						<option>3 Year</option>
					</select>
				</td>
			</tr>
			<tr>
				<td style="color:#666;">Rental Fees (HP Amount)</td>
				<td style="color:#666;"><label id="RF"></label></td>
			</tr>
			<tr>
				<td style="color:#666;">Service Charges</td>
				<td style="color:#666;"><label id="SC"></label></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="button" onclick="Calculate()" value="Calculate" style="color:#666;" /></td>
			</tr>
			<tr>
				<td style="color:#666;">Down Payment -</td>
				<td><label id="DP" style="color:#666;"></label></td>
			</tr>
			<tr>
				<td style="color:#666;">Monthly Payment -</td>
				<td style="color:#666;"><label id="Remain" style="color:#666;"></label></td>
			</tr>
			<tr>
				<td style="color:#666;">Total Amount -</td>
				<td><label id="TA" style="color:#666;"></label></td>
			</tr>
			<tr>
				<td colspan="2" style="color:#666;">- service charges include Bank service fees, PO commersion, Opening Account Fees, Document Fees</td>
			</tr>
			<tr>
				<td colspan="2" style="color:#666; font-family:Zawgyi-One;">- သိန္း ၂ ေထာင္ အထက္ကားမ်ားကို 3 Year plan ျဖင့္ အထူး၀န္ေဆာင္မႈ ေပးေနပါသည္</td>
			</tr>
		</table>
</form>
</body>
</html>