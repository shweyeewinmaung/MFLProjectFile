<?php
session_start();
include("connection.php");
require_once("function/globalfunction.php");

if(!$_SESSION['SESS']['UserID'])
{
	header("Location:login.php");
}

$ID=Clean($_GET['ID']);	

mysql_query("DELETE FROM `admin` WHERE ID='".$ID."'")or die("DELETE ERROR");
header("location:manageadmin.php");
?>