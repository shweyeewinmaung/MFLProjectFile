<?php
session_start();

include("connection.php");
include("function/pager.php");
require_once("function/globalfunction.php");
$pageSize=10;

if(isset($_GET['page']))
	$currentPageIndex=Clean($_GET['page']);
else
	//by default we show first page
	$currentPageIndex=1;
$objPager=new pager($pageSize,$currentPageIndex);

$sql=$objPager->GetAllCarData();
$result=$objPager->Search_Data($sql);
$numOfRows=mysql_num_rows($result);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div id="activityleft">
                <div style="border:1px solid #CCC; width:95%; overflow:hidden; margin:5px auto;">
                 <center><h1 style="font-size:25px; color:#3b5998;" >Car List</h1></center>
                    <?php
                        for($i=0;$i<$numOfRows;$i++)
                        {
                            $row=mysql_fetch_array($result);
                            
                    ?>
                    <div style="border:1px solid #CCC; width:80%; overflow:hidden; margin:0 auto;">
                    <a href="CarDetail.php?ID=<?php echo $row['ID']; ?>">
                        <table style="border:1px solid white; float:left;">
                            <tr>
                                <td>
                                    <img src="carphoto/<?php echo $row['Photo1']; ?>" style="width:90px; height:90px;">
                                </td>
                            </tr>
                        </table>
                        <table style="float:left;">
                            <tr>
                                <td style="font-size:11px; color:#123456;"><a href="CarDetail.php?ID=<?php echo $row['ID']; ?>"><?php echo $row['Company']; ?> - <?php echo $row['CarMarks']; ?></a></td>
                            </tr>
                            <tr>
                                <td style="font-size:11px; color:#123456;">Model - <?php echo $row['Model']; ?></td>
                            </tr>
                            <tr>
                                <td style="font-size:11px; color:#123456;">Kilo - <?php echo $row['Kilo']; ?></td>
                            </tr>
                            <tr>
                                <td style="font-size:11px; color:#123456;"> 
								<?php 
									
									if(strlen($row['Description'])<=75)
									{
										echo substr($row['Description'], 0, 50); 
									}
									else
									{
										echo substr($row['Description'], 0, 50) . "..."; 
									}
								?></td>
                            </tr>
                        </table>
                        <table style="float:right; margin:5px 7px 0 0; background-color:#3b5998; border-radius:5px;">
                            <tr>
                                <td style="font-size:11px; color:white;"><?php echo $row['CarPrice']; ?></td>
                            </tr>
                        </table>
                       </a> 
                    </div>
                        </br>
                        <?php
                            }
                        ?>
                    </div>
                <center>
                <?php
                    $objPager->Generate_Pager($str);
                ?>
                  </center>
                  </br>
            </div>
				<?php
					include("right.php");
				?>      
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>