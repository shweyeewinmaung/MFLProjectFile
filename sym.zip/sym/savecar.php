<?php
	include("connection.php");
	require_once("function/globalfunction.php");
	
	$logno=Clean($_POST['LogNo']);
	$companybrand=Clean($_POST['CompanyBrand']);
	$carmarks=Clean($_POST['CarMarks']);
	$Model=Clean($_POST['Model']);
	$horsepower=Clean($_POST['HorsePower']);
	$fuel=Clean($_POST['Fuel']);
	$gear=Clean($_POST['Gear']);
	$kilo=Clean($_POST['Kilo']);
	$Chassis=Clean($_POST['Chassis']);
	$Description=Clean($_POST['Description']);
		
	$photo1=$_FILES['photo1']['name'];
	$tmp=$_FILES['photo1']['tmp_name'];
	move_uploaded_file($tmp,"carphoto/".$photo1);
	
	$photo2=$_FILES['photo2']['name'];
	$tmp=$_FILES['photo2']['tmp_name'];
	move_uploaded_file($tmp,"carphoto/".$photo2);
	
	$photo3=$_FILES['photo3']['name'];
	$tmp=$_FILES['photo3']['tmp_name'];
	move_uploaded_file($tmp,"carphoto/".$photo3);
	
	$photo4=$_FILES['photo4']['name'];
	$tmp=$_FILES['photo4']['tmp_name'];
	move_uploaded_file($tmp,"carphoto/".$photo4);
	
	$photo5=$_FILES['photo5']['name'];
	$tmp=$_FILES['photo5']['tmp_name'];
	move_uploaded_file($tmp,"carphoto/".$photo5);

	$rank=Clean($_POST['Rank']);
	$carprice=Clean($_POST['carprice']);
	
	mysql_query("INSERT INTO `car`(LogNo,Company,CarMarks,Model,HorsePower,Fuel,Gear,Kilo,Chassis,Description,Photo1,Photo2,Photo3,Photo4,Photo5,Rank,CarPrice) VALUES ('".$logno."','".$companybrand."','".$carmarks."','".$Model."','".$horsepower."','".$fuel."','".$gear."','".$kilo."','".$Chassis."','".$Description."','".$photo1."','".$photo2."','".$photo3."','".$photo4."','".$photo5."','".$rank."','".$carprice."')")or die("INSERT ERROR");
	
	//header("location:PostPage.php");
	
	
	/**
 * Edit the Page ID you are targeting
 * And the message for your fans!
 */

session_start();
include("connection.php");
require_once("function/globalfunction.php"); 


$sql="SELECT * FROM `car` ORDER BY ID DESC LIMIT 1";
$ret=mysql_query($sql);
$num=mysql_num_rows($ret);

if($num<1)
{
	header("Location:home.php");
}

$row=mysql_fetch_array($ret);
$ID=$row['ID'];

//$page_id = '598962016853013';
$page_id = '712257032120305';
$message = $row['Description'];


/**
 * This code is just a snippet of the example.php script
 * from the PHP-SDK <http://github.com/facebook/php-sdk/blob/master/examples/example.php>
 */
 require_once('Facebook/facebook.php');

// Create our Application instance (replace this with your appId and secret).
$facebook = new Facebook(array(
  'appId'  => '625147720902204',
  'secret' => '7b0f8f6649c294873b2c624b20356cf2',
));

// Get User ID
$user = $facebook->getUser();

if ($user) {
  try {
    $page_info = $facebook->api("/$page_id?fields=access_token");
    if( !empty($page_info['access_token']) ) {
        $args = array(
            'access_token'  => $page_info['access_token'],
			'link' => 'www.mfl-itsolution.com/sym/CarDetail.php?ID='  . $ID,
            'message'       => $message 
        );
        $post_id = $facebook->api("/$page_id/feed","post",$args);
		
    } else {
        $permissions = $facebook->api("/me/permissions");
        if( !array_key_exists('publish_stream', $permissions['data'][0]) ||
           !array_key_exists('manage_pages', $permissions['data'][0])) {
                // We don't have one of the permissions
                // Alert the admin or ask for the permission!
                header( "Location: " . $facebook->getLoginUrl(array("scope" => "publish_stream, manage_pages")) );
        }
    }
  } catch (FacebookApiException $e) {
    error_log($e);
    $user = null;
  }
}

// Login or logout url will be needed depending on current user state.
if ($user) {
  $logoutUrl = $facebook->getLogoutUrl();
} else {
  $loginUrl = $facebook->getLoginUrl(array('scope'=>'manage_pages,publish_stream'));
}
// ... rest of your code
header("Location:viewallcar.php");
?>