<div id="left">

	<div id="popularbox">

		<div id="picwrapper">

			<div style="float:left; width:58%; height:99%; background-color:#CCC; margin:2px;">

				<table style="width:97%; margin:1% auto;">

                	<?php

						$sql1="select * from `car` where Rank='Favourite' ORDER BY ID DESC LIMIT 0,1";

						$sql2="select * from `car` where Rank='Favourite' ORDER BY ID DESC LIMIT 1,1";

						$sql3="select * from `car` where Rank='Favourite' ORDER BY ID DESC LIMIT 2,1";

						$sql4="select * from `car` where Rank='Favourite' ORDER BY ID DESC LIMIT 3,1";

						$ret1=mysql_query($sql1);

						$ret2=mysql_query($sql2);

						$ret3=mysql_query($sql3);

						$ret4=mysql_query($sql4);

						$num1=mysql_num_rows($ret1);

						$num2=mysql_num_rows($ret2);

						$num3=mysql_num_rows($ret3);

						$num4=mysql_num_rows($ret4);

						

						if($num1>0)

						{

							$row1=mysql_fetch_array($ret1);

					?>

								<center><h1 style="font-size:20px;">Hot Cars</h1></center>

                            	<tr>

                                    <td align="center"><a href="CarDetail.php?ID=<?php echo $row1['ID']; ?>"><img src="carphoto/<?php echo $row1['Photo1']; ?>" style="width:155px; height:140px; border:2px solid white;"/></a></td>

                                    <?php

										if($num2>0)

										{

											$row2=mysql_fetch_array($ret2);

											?>

                                            	<td align="center"><a href="CarDetail.php?ID=<?php echo $row2['ID']; ?>"><img src="carphoto/<?php echo $row2['Photo1']; ?>" style="width:155px; height:140px; border:2px solid white;" /></a></td>

                    <?php

						}

					?>

                                </tr>

								<tr>

									<td align="center"><a style="text-decoration:none; color:#3b5998; font-size:11px;" href="CarDetail.php?ID=<?php echo $row1['ID']; ?>"><?php echo $row1['CarMarks']; ?></a></td>

									<td align="center"><a style="text-decoration:none; color:#3b5998; font-size:11px;" href="CarDetail.php?ID=<?php echo $row2['ID']; ?>"><?php echo $row2['CarMarks']; ?></a></td>			

								</tr>

								</tr>

									<td align="center"><a style="text-decoration:none; color:#3b5998; font-size:11px;" href="CarDetail.php?ID=<?php echo $row1['ID']; ?>"><?php echo $row1['CarPrice']; ?></a></td>

									<td align="center"><a style="text-decoration:none; color:#3b5998; font-size:11px;" href="CarDetail.php?ID=<?php echo $row2['ID']; ?>"><?php echo $row2['CarPrice']; ?></a></td>

								</tr>

                            <?php

							

							

							if($num3>0)

							{

								$row3=mysql_fetch_array($ret3);

								?>

									<tr>

										<td align="center"><a href="CarDetail.php?ID=<?php echo $row3['ID']; ?>"><img src="carphoto/<?php echo $row3['Photo1']; ?>" style="width:155px; height:140px; border:2px solid white;"/></a></td>

										<?php

											if($num4>0)

											{

												$row4=mysql_fetch_array($ret4);

												?>

													<td align="center"><a href="CarDetail.php?ID=<?php echo $row4['ID']; ?>"><img src="carphoto/<?php echo $row4['Photo1']; ?>" style="width:155px; height:140px; border:2px solid white;" /></a></td>

												<?php

											}

										?>

									</tr>

									<tr>

										<td align="center"><a style="text-decoration:none; color:#3b5998; font-size:11px;" href="CarDetail.php?ID=<?php echo $row3['ID']; ?>"><?php echo $row3['CarMarks']; ?></a></td>

										<td align="center"><a style="text-decoration:none; color:#3b5998; font-size:11px;" href="CarDetail.php?ID=<?php echo $row4['ID']; ?>"><?php echo $row4['CarMarks']; ?></a></td>

									</tr>

									</tr>

										<td align="center"><a style="text-decoration:none; color:#3b5998; font-size:11px;" href="CarDetail.php?ID=<?php echo $row3['ID']; ?>"><?php echo $row3['CarPrice']; ?></a></td>

										<td align="center"><a style="text-decoration:none; color:#3b5998; font-size:11px;" href="CarDetail.php?ID=<?php echo $row4['ID']; ?>"><?php echo $row4['CarPrice']; ?></a></td>

									</tr>

								<?php

							}

						}

						else if($num1==0)

						{

							

						}

					?>

				</table>

			</div>

			<div style="float:left; width:40%; height:448px; background-color:#CCC; margin:2px;">

            	<?php

					$sql5="SELECT * FROM `car` WHERE Rank='Popular'";

					$ret5=mysql_query($sql5);

					$num5=mysql_num_rows($ret5);

					

					if($num5>0)

					{

						$row5=mysql_fetch_array($ret5);

						?>

							<center><h1 style="font-size:20px; margin-top:35px;">Popular</h1></center>

                        	<a href="CarDetail.php?ID=<?php echo $row5['ID']; ?>"><img src="carphoto/<?php echo $row5['Photo1']; ?>" style="width:95%; height:210px; overflow:hidden; margin:10px 0 0 6px; border:2px solid white;"></a>

							<center><a style="text-decoration:none; color:#3b5998; font-size:11px;" href="CarDetail.php?ID=<?php echo $row5['ID']; ?>"><?php echo $row5['CarMarks']; ?></a></center>

							<center><a style="text-decoration:none; color:#3b5998; font-size:11px;" href="CarDetail.php?ID=<?php echo $row5['ID']; ?>"><?php echo $row5['CarPrice']; ?></a></center>
							<br />
							<a style="text-decoration:none; color:#123456; font-size:9px; overflow:hidden; margin-left:10px;" href="CarDetail.php?ID=<?php echo $row5['ID']; ?>">
								<?php 
									if(strlen($row5['Description'])<=75)
									{
										echo "<div style='margin-left:15px;'>" . substr($row5['Description'], 0, 100) . "</div>"; 
									}
									else
									{
										echo "<div style='margin-left:15px;'>" . substr($row5['Description'], 0, 100) . "... See More</div>"; 
									}
								?>
                                </a>

                        <?php

					}

					elseif($num5==0)

					{

						

					}

				?>

				

			</div>

		</div>

	</div>

	<div id="leftlogobox">

		<marquee style="background-color:#CCC;" direction="left">

			<a href="#"><img src="logoadv/7.png" style="margin-top:3px;"/></a>

			<a href="#"><img src="logoadv/9.png"/></a>

			<a href="#"><img src="logoadv/10.png"/></a>

			<a href="http://nanhtiketheingi.com/"><img src="logoadv/11.png" /></a>

			<a href="#"><img src="logoadv/12.png" /></a>

		</marquee>

	</div>

	<div id="inhandbox">

		<center><h1>In Hand Cars!!!</h1></center>

		<div style="background-color:#CCC; margin:1% auto; width:99%; overflow:hidden;">

			<?php

			

				$query=mysql_query("SELECT * FROM `car` Order By ID DESC LIMIT 15")or die("Select Error");

				

				while($row=mysql_fetch_assoc($query))

					{

			?>

				<table style="float:left; overflow:hidden; margin:2px 0 2px 10px; padding:0;">

					<tr>

						<td>

							<a href="CarDetail.php?ID=<?php echo $row['ID']; ?>"><img src="carphoto/<?php echo $row['Photo1']; ?>" style="width:120px; height:120px; border:2px solid white;"></a>

						</td>

					</tr>

					<tr>

						<td align="center"><h1><a style="text-decoration:none; color:#3b5998; font-size:10px;" href="CarDetail.php?ID=<?php echo $row['ID']; ?>"><?php echo $row['CarMarks']; ?>-<?php echo $row['CarPrice']; ?></a></h1></td>

					</tr>	

					

				</table>

			<?php

				}

			?>

			</br>	

			<div style="width:100%; overflow:hidden;">

				<center><h1><a href="CarList.php" style="text-decoration:none;">see more</a></h1></center>

			</div>

		</div>

	</div>

</div>