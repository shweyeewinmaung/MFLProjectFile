<?php
session_start();

if(!$_SESSION['SESS']['UserID'])
{
	header("Location:login.php");
}
?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div>
					<table style="width:900px; margin:4% auto; padding:60px; background-color:#3b5998; border-radius:10px;">
						<tr>
							<td colspan="2" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
						</tr>
						<tr>
							<td></br></td>
							<td></br></td>
						</tr>
						<form action="uploadvideo.php" method="POST" enctype="multipart/form-data">
							<tr>
								<td colspan="2" align="center" style="font-size:20px; color:white; ">Upload Video</td>
							</tr>
							<tr align="center">
								<td style="width:290px; font-size:17px; color:white;" align="center">Title</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="text" name="title"/></td>
							</tr>
							<tr align="center">
								<td style="width:290px; font-size:17px; color:white;" align="center">Description</td>
								<td style="width:290px; font-size:17px; color:white;" align="left">
									<textarea name="description" rows="10" cols="100" ></textarea>
								</td>
							</tr>
							<tr align="center">
								<td style="font-size:17px; color:white; width:200px;" align="center">Date</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="text" name="date"/></td>
							</tr>
							<tr align="center">
								<td style="font-size:17px; color:white; width:200px;" align="center">Upload Video</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="file" name="uploadvideo"/></td>
							</tr>
							<tr align="center">
								<td style="font-size:17px; color:white; width:200px;" align="center"></td>
								<td style="font-size:17px; color:white;" align="left"><input type="submit" value="Upload Video" style="background-color:#19d595;"/></td>
							</tr>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
						</form>
						<form action="uploadimage.php" method="POST" enctype="multipart/form-data">
							<tr>
								<td colspan="2" align="center" style="font-size:20px; color:white; ">Upload Image</td>
							</tr>
							<tr>
								<td style="width:290px; font-size:17px; color:white;" align="center">Title</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="text" name="title"/></td>
							</tr>
							<tr>
								<td style="width:290px; font-size:17px; color:white;" align="center">Description</td>
								<td style="width:290px; font-size:17px; color:white;" align="left">
									<textarea name="description" rows="10" cols="100" ></textarea>
								</td>
							</tr>
							<tr>
								<td style="width:290px; font-size:17px; color:white;" align="center">Date</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="text" name="date"/></td>
							</tr>
							<tr>
								<td style="width:290px; font-size:17px; color:white;" align="center">Upload Image</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="file" name="img1"/></td>
							</tr>
							<tr>
								<td style="width:290px; font-size:17px; color:white;" align="center">Upload Image</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="file" name="img2"/></td>
							</tr>
							<tr>
								<td style="width:290px; font-size:17px; color:white;" align="center">Upload Image</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="file" name="img3"/></td>
							</tr>
							<tr>
								<td style="width:290px; font-size:17px; color:white;" align="center">Upload Image</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="file" name="img4"/></td>
							</tr>
							<tr>
								<td style="width:290px; font-size:17px; color:white;" align="center">Upload Image</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="file" name="img5"/></td>
							</tr>
							<tr align="center">
								<td style="font-size:17px; color:white; width:200px;" align="center"></td>
								<td style="font-size:17px; color:white;" align="left"><input type="submit" value="Upload Image" style="background-color:#19d595;"/></td>
							</tr>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
						</form>
						<form action="uploadnews.php" method="POST" enctype="multipart/form-data">
							<tr>
								<td colspan="2" align="center" style="font-size:20px; color:white; ">Upload News</td>
							</tr>
							<tr>
								<td style="width:290px; font-size:17px; color:white;" align="center">Title</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="text" name="title"/></td>
							</tr>
							<tr>
								<td style="width:290px; font-size:17px; color:white;" align="center">Description</td>
								<td style="width:290px; font-size:17px; color:white;" align="left">
									<textarea name="description" rows="10" cols="100" ></textarea>
								</td>
							</tr>
							<tr>
								<td style="width:290px; font-size:17px; color:white;" align="center">Date</td>
								<td style="width:290px; font-size:17px; color:white;" align="left"><input type="text" name="date"/></td>
							</tr>
							<tr align="center">
								<td style="font-size:17px; color:white; width:200px;" align="center"></td>
								<td style="font-size:17px; color:white;" align="left"><input type="submit" value="Upload News" style="background-color:#19d595;"/></td>
							</tr>
						</form>
							<tr>
								<td></td>
								<td><a href="adminpage.php" style="color:white; float:right; text-decoration:none;">Back</a></td>
							</tr>
					</table>
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>