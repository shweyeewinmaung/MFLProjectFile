<?php
  session_start();
  include("connection.php");
  require_once("function/globalfunction.php");

  // Remember to copy files from the SDK's src/ directory to a
  // directory in your application on the server, such as php-sdk/
  require_once('Facebook/facebook.php');


if($_GET['ID']=="")
{
	header("Location:home.php");
}

$ID=Clean($_GET['ID']);
$sql="SELECT * FROM `car` WHERE ID='$ID'";
$ret=mysql_query($sql);
$num=mysql_num_rows($ret);

if($num<1)
{
	header("Location:home.php");
}
$row=mysql_fetch_array($ret);

		$msg=$row['Description'];
  $config = array(
    'appId' => '625147720902204',
    'secret' => '7b0f8f6649c294873b2c624b20356cf2',
    'allowSignedRequest' => false // optional but should be set to false for non-canvas apps
  );

  $facebook = new Facebook($config);
  $user_id = $facebook->getUser();
?>
<html>
  <head></head>
  <body>

  <?php
    if($user_id) {

      // We have a user ID, so probably a logged in user.
      // If not, we'll get an exception, which we handle below.
      try {
		

        $ret_obj = $facebook->api('/me/feed', 'POST',
                                    array(
                                      'link' => 'www.mfl-itsolution.com/sym/CarDetail.php?ID=' . $ID,
                                      'message' => '' . $msg
                                 ));
        
		
		echo "<script type='text/javascript'>setTimeout('window.close();', 2000);</script>";
		
		/*
		echo '<pre>Post ID: ' . $ret_obj['id'] . '</pre>';

        // Give the user a logout link 
        echo '<br /><a href="' . $facebook->getLogoutUrl() . '">logout</a>';
		*/
      } catch(FacebookApiException $e) {
        // If the user is logged out, you can have a 
        // user ID even though the access token is invalid.
        // In this case, we'll get an exception, so we'll
        // just ask the user to login again here.
        $login_url = $facebook->getLoginUrl( array(
                       'scope' => 'publish_stream'
                       )); 
        echo 'Please <a href="' . $login_url . '">login.</a>';
        error_log($e->getType());
        error_log($e->getMessage());
      }   
    } else {

      // No user, so print a link for the user to login
      // To post to a user's wall, we need publish_stream permission
      // We'll use the current URL as the redirect_uri, so we don't
      // need to specify it here.
      $login_url = $facebook->getLoginUrl( array( 'scope' => 'publish_stream' ) );
      echo 'Please <a href="' . $login_url . '">login.</a>';

    } 

  ?>      

  </body> 
</html> 