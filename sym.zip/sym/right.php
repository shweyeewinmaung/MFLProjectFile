<?php
	include("connection.php");
	
	//$result1=mysql_query("SELECT * FROM `video` Order By ID DESC LIMIT 1")or die("SELECT VIDEO ERROR");
	//$result2=mysql_query("SELECT * FROM `image` Order By ID DESC LIMIT 1")or die("SELECT Image ERROR");
	$result3=mysql_query("SELECT * FROM `news` Order By ID DESC LIMIT 3")or die("SELECT News ERROR");
?>
<script src="slidejquery/slidejquery.js"></script>
<script>
    $(document).ready(function(){
    $(".box2,.box3").css("display","none");
    var a=2;
    function recursive()
    {

    $(".box1,.box2,.box3").css("display","none");  
    $(".box"+a).fadeIn(1000);

    a=Number(a)+1; 
    if(a==4)
    a=1;
    }

    setInterval(function(){recursive()},3000);

    });
</script>
<div id="right">
		<div id="WelcomeBox">
			<div style="margin:2%;">
				<h1>Welcome From Shew Ya Mone</h1>
					<p1><span data-reactid=".cg.$mid=11409021008530=28432947a67dc45c213.2:0.0.0.0.0">မဂၤလာ ပါ ခင္ဗ်ာ။ ကြ်န္ေတာ္ တို႔ sale and service centre မွ ေမာ္ေတာ္ကား၀ယ္လိုေသာ customer မ်ားအတြက္ အေကာင္းဆုံး ၀န္ေဆာင္မႈ ၊အခ်ိဳသာဆုံးေစ်းႏွဳန္း၊ Online မွ တိုက္ရိုက္၀ယ္ယူၿခင္း မ်ား အပါအ၀င္ ကားႏွင့္ ပတ္သက္ေသာ အၿခား၀န္ေဆာင္မႈမ်ား၊ အမည္ေပါက္၊ေနာက္ဆုံးနံပါတ္၊Owner book ရသည့္အထိေဆာင္ရြက္ေပးၿခင္း၊ကားတစ္စီး ၏ လိုအပ္ေသာ ၾကံခိုင္မႈ ႏွင့္ service တို႔ကို တစ္ေနရာထဲတြင္ အဆင္ေၿပေစရန္ ၀န္ေဆာင္မႈမ်ား ေပးေနပါသည္။</span></p1>
			</div>
		</div>
		<div id="Advslide">
			 <div class="boxes">
			    <div class="box1"><a href="#"><img src="rightadv/1.png" width="100%" height="40%" alt="" /></a></div>
			    <div class="box2"><a href="#"><img src="rightadv/5.png" width="100%" height="40%" alt="" /></a></div>
			    <div class="box3"><a href="#"><img src="rightadv/6.png" width="100%" height="40%" alt="" /></a></div>
			 </div>
		</div>
		<div id="Foradvpurpose">
			<div style="margin:2%;">
				<h1>သင္၏လုပ္ငန္းကို ေၾကာ္ျငာပါ</h1>
					  <p5 style="color:#666;">Shweyamone Website တြင္ ေၾကာ္ျငာလိုပါက ေအာက္ပါ အီးေမးလ္နဲ႕ ဖုန္းနံပါတ္သို႕ ဆက္သြယ္ႏိုင္ပါသည္။</p5></br>
					  <p5 style="color:#666;">Email: sym@shweyamone-carcentre.com  </p5></br>
					  <p5 style="color:#666;">Phone: 01656708 ၊ 01656709</p5>
			</div>			
		</div>
		<div id="calculate" style="border:1px solid #CCC;">
			<div style="margin:2%;">
				<h1 style="font-size:18px;">Calculate your Car Price</h1>		
					<table style=" width:80%; margin:2%;font-size:11px;">
							<?php
								include("downpayment.php");						{									echo '																					<tr>												<td>. </td>												<td>													<a href="activity.php">'.$row3['Title'].'</a> 												</td>											</tr>											';								}		
							?>
					</table>					</br>
			</div>					
		</div>
		<div id="LatestNews">
			<div style="margin:2%;">
				<h1>Latest News</h1>					<table style=" width:80%; margin:2%;font-size:11px;">
							<?php
								while($row3=mysql_fetch_assoc($result3))								{									echo '																					<tr>												<td>. </td>												<td>													<a href="activity.php">'.$row3['Title'].'</a> 												</td>											</tr>											';								}		
							?>
					</table>					</br>
			</div>					
		</div>
		<div id="CountryView" style="overflow:hidden;">	
				<div style="float:left; overflow:hidden; margin:5px 5px 5px 20px;">
					<style>
						.gcw_main173629407{width:230px;font-family:Trebuchet MS,Tahoma,Verdana,Arial,sans-serif;font-size:11px;border:#A6C9E2 1px solid;text-align:center;color:#000000;background-color:#FCFDFD;margin:0 auto;}
						.gcw_header173629407{margin:4px;padding:5px;text-align:center;border:#4297D7 1px solid;background-color:#5C9CCC;}
						#ccw_cnhfybwf173629407{text-decoration:none;color:#FFFFFF;font-size:13px;font-weight:bold;}
						.gcw_input173629407{color:#2E6E9E;font-weight:bold;background-color:#FCFDFD;border:#C5DBEC 1px solid;text-align:right;padding:2px 0;margin:1px 0;display:inline;font-size:11px;}
						.gcw_select173629407{color:#000;display:inline;}
						#gcw_date173629407{font-size:10px;color:#2E6E9E;}
					</style>
					<div class='gcw_main173629407'>
						<div class='gcw_header173629407'>
							<a href='http://www.freecurrencyrates.com/myconverter#cur=MMK-USD-THB-SGD-MYR;amt=MMK1' id='ccw_cnhfybwf173629407'>Currency Counverter</a>
						</div>
						<div id='gcw_rates173629407'></div>
						<script src='http://www.freecurrencyrates.com/converter-widget?source=Yahoo%20Finance&width=230&currs=MMK,USD,THB,SGD,MYR&precision=2&language=en&flags=1&currchangable=1&firstrowvalue=1&id=173629407' charset='UTF-8'></script>
					</div>
				</div>
				<div style="float:left; overflow:hidden; margin:5px 0 5px 10px;">
					<center><h1>Country View</h1></center>
					<center>
						<script type="text/javascript" src="http://widget.supercounters.com/flag.js"></script>
						<script type="text/javascript">
						sc_flag(908180,"FFFFFF","000000","cccccc",1,7,0,0)
						</script>
					</center>
				</div>		
		</div>
</div>