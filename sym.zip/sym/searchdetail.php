<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div style="width:900px; margin:10% auto; padding:60px; background-color:#3b5998; border-radius:10px; ">
                    <center><h1 style="font-size:25px; color:white;" >Welcome From Shwe Ya Mone</h1></center>
                                    </br></br></br>
						<div style="border:1px solid white; width:80%; overflow:hidden; margin:0 auto;">
							<table style="margin:4px; float:left;">
                                <tr>
                                   <td>
										<img src="carphoto/2.jpg" style="width:280px; height:280px; padding:6px; border:2px solid white;">						
								   </td>
	                            </tr>
								<tr>
									<td>
										<img src="carphoto/2.jpg" style="width:70px; height:70px; border:2px solid white;">
										<img src="carphoto/2.jpg" style="width:70px; height:70px; border:2px solid white;">
										<img src="carphoto/2.jpg" style="width:70px; height:70px; border:2px solid white;">
										<img src="carphoto/2.jpg" style="width:70px; height:70px; border:2px solid white;">
								   </td>	
								</tr>
							</table>
							<table style="margin:4px; float:left; padding:20px; color:white;">
                                <tr>
									<td>LogNo</td>
									<td> - </td>
								</tr>
								<tr>
									<td>Company</td>
									<td> - </td>
								</tr>
								<tr>
									<td>CarMarks</td>
									<td> - </td>
								</tr>
								<tr>
									<td>Model</td>
									<td> - </td>
								</tr>
								<tr>
									<td>HorsePower</td>
									<td> - </td>
								</tr>
								<tr>
									<td>Fuel</td>
									<td> - </td>
								</tr>
								<tr>
									<td>Gear</td>
									<td> - </td>
								</tr>
								<tr>
									<td>Kilo</td>
									<td> - </td>
								</tr>
								<tr>
									<td>Chassis</td>
									<td> - </td>
								</tr>
								<tr>
									<td>Price</td>
									<td> - </td>
	                            </tr>
								<tr>
									<td>Description</td>
									<td> - </td>
	                            </tr>
							</table>
						</div>
                </div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>