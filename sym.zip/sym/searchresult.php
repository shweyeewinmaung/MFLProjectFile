<?php
include("connection.php");
include("function/pager.php");
require_once("function/globalfunction.php");

$pageSize=7;

if(isset($_GET['page']))
	$currentPageIndex=Clean($_GET['page']);
else
	//by default we show first page
	$currentPageIndex=1;
$objPager=new pager($pageSize,$currentPageIndex);

$str="CarMark=" . Clean($_GET['CarMark']) . "&Model=" . Clean($_GET['Model']) . "&Brand=" . Clean($_GET['Brand']);

if(isset($_GET['CarMark']) && $_GET['CarMark']!="")
{
	$CarMark=Clean($_GET['CarMark']);
	$sql=$objPager->SearchData_CarMark($CarMark);
}

elseif(isset($_GET['Model']) && $_GET['Model']!="Model")
{
	$Model=Clean($_GET['Model']);
	$sql=$objPager->SearchData_Model($Model);
}

elseif(isset($_GET['Brand']) && $_GET['Brand']!="Brand")
{
	$Brand=Clean($_GET['Brand']);
	$sql=$objPager->SearchData_Company($Brand);
}



elseif(isset($_GET['CarMark']) && $_GET['CarMark']!="" && isset($_GET['Model']) && $_GET['Model']!="")
{
	$CarMark=Clean($_GET['CarMark']);
	$Model=Clean($_GET['Model']);
	$sql=$objPager->SearchData_CarMarkAndModel($CarMark, $Model);
}

elseif(isset($_GET['CarMark']) && $_GET['CarMark']!="" && isset($_GET['Brand']) && $_GET['Brand']!="")
{
	$CarMark=Clean($_GET['CarMark']);
	$Brand=Clean($_GET['Brand']);
	$sql=$objPager->SearchData_CarMarkAndCompany($CarMark, $Brand);
}

elseif(isset($_GET['Model']) && $_GET['Model']!="" && isset($_GET['Brand']) && $_GET['Brand']!="")
{
	$Model=Clean($_GET['Model']);
	$Brand=Clean($_GET['Brand']);
	$sql=$objPager->SearchData_ModelAndCompany($Model, $Brand);
}



elseif(isset($_GET['CarMark']) && $_GET['CarMark']!="" && isset($_GET['Model']) && $_GET['Model']!="" && isset($_GET['Brand']) && $_GET['Brand']!="")
{
	$CarMark=Clean($_GET['CarMark']);
	$Model=Clean($_GET['Model']);
	$Brand=Clean($_GET['Brand']);
	$sql=$objPager->SearchData_All($CarMark, $Model, $Brand);
}

$result=$objPager->Search_Data($sql);
$numOfRows=mysql_num_rows($result);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
                <div id="searchleft">
	 <center><h1 style="font-size:25px; color:#3b5998;" >Search Result</h1></center>
		 <?php
			if($numOfRows==0 || $numOfRows<0)
			{
				echo "
					<script>alert('Does not exist')</script>
				";
			}
			if($numOfRows>0)
			{
				for($i=0;$i<$numOfRows;$i++)
				{
					$row=mysql_fetch_array($result);	
					?>
                     <div style="border:1px solid #CCC; width:80%; overflow:hidden; margin:0 auto;">
                     	<a href="CarDetail.php?ID=<?php echo $row['ID']; ?>">
                        <table style="border:1px solid white; margin:4px; float:left;">
                        <tr>
                            <td>
                                <img src="carphoto/<?php echo $row['Photo1']; ?>" style="width:90px; height:90px;">
                            </td>
                        </tr>
                        </table>
                        <table style="float:left;">
                            <tr>
                                <td style="font-size:11px; color:#123456;"><?php echo $row['Company']; ?> - <?php echo $row['CarMarks']; ?></a></td>
                            </tr>
                            <tr>
                                <td style="font-size:11px; color:#123456;;">Model - <?php echo $row['Model']; ?></td>
                            </tr>
                            <tr>
                                <td style="font-size:11px; color:#123456;;">Kilo - <?php echo $row['Kilo']; ?></td>
                            </tr>
                            <tr>
                                <td style="font-size:11px; color:#123456;;"> 
                                <?php 
									echo strlen($row['Description']);
									if(strlen($row['Description'])<=75)
									{
										echo substr($row['Description'], 0, 50); 
									}
									else
									{
										echo substr($row['Description'], 0, 50) . "..."; 
									}
								?>
								</td>
                            </tr>
                        </table>
                        <table style="float:right; margin:5px 7px 0 0; background-color:#3b5998; border-radius:5px;">
                            <tr>
                                <td style="font-size:11px; color:white;"><?php echo $row['CarPrice']; ?></td>
                            </tr>
                        </table>
                        </a>
                    </div>
                    </br>
                    <center>
                     <?php
                            }
                        }
                    echo "-<br />";
                    $objPager->Generate_Pager($str);
                    ?>
                    </center></br>
			</div>
                <?php
					include("right.php");
				?>           
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>