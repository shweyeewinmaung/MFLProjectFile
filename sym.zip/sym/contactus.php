<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div>
					<table style="width:1000px; margin:4% auto; padding:60px; background-color:#3b5998; border-radius:10px;">
						<tr>
							<td colspan="2" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
						</tr>
						<tr>
							<td></br></td>
							<td></br></td>
						</tr>
						<tr align="center">
							<td style="width:290px; font-size:17px; color:white;" align="center">Showroom Address</td>
							<td style="width:290px; font-size:17px; color:white;" align="left">- No.29, Pyay Road, 7 mile, Mayangone Township, Yangon</td>
						</tr>
						<tr align="center">
							<td style="font-size:17px; color:white; width:200px;" align="center">Office Tel.Phone Number</td>
							<td style="width:290px; font-size:17px; color:white;" align="left">- 01656708</td>
						</tr>
						<tr align="center">
							<td style="font-size:17px; color:white; width:200px;" align="center">Office Fax.Phone Number</td>
							<td style="width:290px; font-size:17px; color:white;" align="left">- 01656709</td>
						</tr>
						<tr align="center">
							<td style="font-size:17px; color:white; width:200px;" align="center">Contact Department</td>
							<td style="width:290px; font-size:17px; color:white;" align="left">- Shweyamone Marketing Department</td>
						</tr>
						<tr align="center">
							<td style="font-size:17px; color:white; width:200px;" align="center">Email</td>
							<td style="width:290px; font-size:17px; color:white;" align="left">- sym@shweyamone-carcentre.com</td>
						</tr>
						<tr align="center">
							<td style="font-size:17px; color:white; width:200px;" align="center">Facebook link</td>
							<td style="width:290px; font-size:17px; color:white;" align="left"> - https://www.facebook.com/pages/Shwe-Ya-Mone-Car-Showroom/712257032120305</td>
						</tr>
					</table>
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>