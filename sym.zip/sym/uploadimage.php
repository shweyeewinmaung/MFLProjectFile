<?php
	session_start();
	include("connection.php");
	require_once("function/globalfunction.php");
		
	if(!$_SESSION['SESS']['UserID'])
	{
		header("Location:login.php");
	}

	$title=Clean($_POST['title']);
	$description=Clean($_POST['description']);
	$date=Clean($_POST['date']);
	
	$img1=$_FILES['img1']['name'];
	$tmp=$_FILES['img1']['tmp_name'];
	move_uploaded_file($tmp,"uploadimage/".$img1);
	
	$img2=$_FILES['img2']['name'];
	$tmp=$_FILES['img2']['tmp_name'];
	move_uploaded_file($tmp,"uploadimage/".$img2);
	
	$img3=$_FILES['img3']['name'];
	$tmp=$_FILES['img3']['tmp_name'];
	move_uploaded_file($tmp,"uploadimage/".$img3);
	
	$img4=$_FILES['img4']['name'];
	$tmp=$_FILES['img4']['tmp_name'];
	move_uploaded_file($tmp,"uploadimage/".$img4);
	
	$img5=$_FILES['img5']['name'];
	$tmp=$_FILES['img5']['tmp_name'];
	move_uploaded_file($tmp,"uploadimage/".$img5);
	
	mysql_query("INSERT INTO `image` (Title,Description,Date,img1,img2,img3,img4,img5) VALUES ('".$title."','".$description."','".$date."','".$img1."','".$img2."','".$img3."','".$img4."','".$img5."')")or die("INSERT ERROR");
	
	header("location:uploadvideoimagesnew.php");
?>