<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div>
					<table style="width:90%; margin:4% auto; padding:60px; background-color:#3b5998; border-radius:10px;">
						<tr>
							<td colspan="6" align="center" style="font-size:25px; color:white; ">Welcome From Shwe Ya Mone</td>
						</tr>
						<tr>
								<td></br></td>
								<td></br></td>
							</tr>
						<tr>
							<td colspan="6" align="center" style="font-size:20px; color:white; ">Delete Video</td>
						</tr>
						<tr>
							<td></br></td>
							<td></br></td>
						</tr>
						<tr>
							<td id="tdforshow">ID</td>
							<td id="tdforshow">Title</td>
							<td id="tdforshow">Description</td>
							<td id="tdforshow">Filename</td>
						</tr>
						<?php
							include("connection.php");
						
							$query=mysql_query("SELECT * FROM `video`")or die("SELECT ERROR");
							$i=1;
							while($row=mysql_fetch_assoc($query))
							{
								echo "<tr>";
									echo "<td id='tdforshow1'>".$i."</td>";
									echo "<td id='tdforshow1'>".$row['Title']."</td>";
									echo "<td id='tdforshow1'>".$row['Description']."</td>";
									echo "<td id='tdforshow1'>".$row['VideoFile']."</td>";
									echo "<td id='tdforshow1'><a href='deleteactivity.php?ID=" . $row['ID'] . "'>Delete</a></td>";
								echo "</tr>";
								$i+=1;
							}
						?>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<tr>
							<td colspan="6" align="center" style="font-size:20px; color:white; ">Delete Images</td>
						</tr>
						<tr>
							<td></br></td>
							<td></br></td>
						</tr>
						<tr>
							<td id="tdforshow">ID</td>
							<td id="tdforshow">Title</td>
							<td id="tdforshow">Description</td>
							<td id="tdforshow">Image</td>
						</tr>
						<?php
							include("connection.php");
						
							$query=mysql_query("SELECT * FROM `image`")or die("SELECT ERROR");
							$i=1;
							while($row=mysql_fetch_assoc($query))
							{
								echo "<tr>";
									echo "<td id='tdforshow1'>".$i."</td>";
									echo "<td id='tdforshow1'>".$row['Title']."</td>";
									echo "<td id='tdforshow1'>".$row['Description']."</td>";
									echo "<td id='tdforshow1'>".$row['img1']."</td>";
									echo "<td id='tdforshow1'><a href='deleteactivity.php?ID=" . $row['ID'] . "'>Delete</a></td>";
								echo "</tr>";
								$i+=1;
							}
						?>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<tr>
							<td colspan="6" align="center" style="font-size:20px; color:white; ">Delete News</td>
						</tr>
						<tr>
							<td></br></td>
							<td></br></td>
						</tr>
						<tr>
							<td id="tdforshow">ID</td>
							<td id="tdforshow">Title</td>
							<td id="tdforshow">Description</td>
							<td id="tdforshow">News</td>
						</tr>
						<?php
							include("connection.php");
						
							$query=mysql_query("SELECT * FROM `news`")or die("SELECT ERROR");
							$i=1;
							while($row=mysql_fetch_assoc($query))
							{
								echo "<tr>";
									echo "<td id='tdforshow1'>".$i."</td>";
									echo "<td id='tdforshow1'>".$row['Title']."</td>";
									echo "<td id='tdforshow1'>".$row['Description']."</td>";
									echo "<td id='tdforshow1'>".$row['News']."</td>";
									echo "<td id='tdforshow1'><a href='deleteactivity.php?ID=" . $row['ID'] . "'>Delete</a></td>";
								echo "</tr>";
								$i+=1;
							}
						?>
							<tr>
								<td></br></td>
								<td></br></td>
							</tr>
							<tr>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td><a href="adminpage.php" style="color:white; float:right; text-decoration:none;">Back</a></td>
							</tr>
					</table>
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>