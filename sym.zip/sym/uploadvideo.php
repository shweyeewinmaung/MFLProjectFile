<?php
	session_start();
	include("connection.php");
	require_once("function/globalfunction.php");
	
	if(!$_SESSION['SESS']['UserID'])
	{
		header("Location:login.php");
	}
	
	$title=Clean($_POST['title']);
	$description=Clean($_POST['description']);
	$date=Clean($_POST['date']);
	
	$video=$_FILES['uploadvideo']['name'];
	$tmp=$_FILES['uploadvideo']['tmp_name'];
	move_uploaded_file($tmp,"uploadvideo/".$video);
	
	mysql_query("INSERT INTO `video` (Title,Description,Date,VideoFile) VALUES ('".$title."','".$description."','".$date."','".$video."')")or die("INSERT ERROR");
	
	header("location:uploadvideoimagesnew.php");
?>