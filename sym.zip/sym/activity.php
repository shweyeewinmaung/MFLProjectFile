<?php
session_start();

include("connection.php");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
	</head>
	<body style="background-color:#CCC;">
		<div>
			<?php
				include("header.php");
			?>
			<div id="body">
				<?php
					include("slider.php");
				?>
				<div style="width:90%; padding:20px; margin:10px auto; overflow:hidden;">	
					<?php
						include("activityleft.php");
					?>
					<?php
						include("right.php");
					?>
				</div>
			</div>
			<?php
				include("footer.php");
			?>
		</div>
	</body>
</html>