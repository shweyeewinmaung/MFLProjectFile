<?php
	include("connection.php");
	require_once("function/globalfunction.php");

	$name=Clean($_POST['adminname']);
	$password=Clean($_POST['adminpassword']);
	
	mysql_query("INSERT INTO `admin` (username,password) VALUES ('".$name."','".$password."')")or die("INSERT ERROR");
	
	header("location:addadmin.php");
?>