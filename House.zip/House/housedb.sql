-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 30, 2015 at 07:53 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `housedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_advertise`
--

CREATE TABLE IF NOT EXISTS `tbl_advertise` (
  `advertiseid` int(11) NOT NULL AUTO_INCREMENT,
  `houseid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `startdate` date DEFAULT NULL,
  `enddate` date DEFAULT NULL,
  `price` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`advertiseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_advertise`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_city`
--

CREATE TABLE IF NOT EXISTS `tbl_city` (
  `cityid` int(11) NOT NULL AUTO_INCREMENT,
  `cityname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `countryid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`cityid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_city`
--

INSERT INTO `tbl_city` (`cityid`, `cityname`, `countryid`) VALUES
(9, 'bbb', '21'),
(10, 'pp', '20');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country`
--

CREATE TABLE IF NOT EXISTS `tbl_country` (
  `countryid` int(11) NOT NULL AUTO_INCREMENT,
  `countryname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`countryid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `tbl_country`
--

INSERT INTO `tbl_country` (`countryid`, `countryname`) VALUES
(21, 'dd'),
(22, 'ee'),
(20, 'cc'),
(19, 'bb');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_house`
--

CREATE TABLE IF NOT EXISTS `tbl_house` (
  `houseid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uploaddate` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updatetime` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `housetype` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `width` varchar(135) COLLATE utf8_unicode_ci DEFAULT NULL,
  `length` varchar(135) COLLATE utf8_unicode_ci DEFAULT NULL,
  `houseno` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `road` text COLLATE utf8_unicode_ci,
  `townshipid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `price` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `wantto` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `housestatus` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`houseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_house`
--

INSERT INTO `tbl_house` (`houseid`, `userid`, `uploaddate`, `updatetime`, `housetype`, `width`, `length`, `houseno`, `road`, `townshipid`, `description`, `price`, `wantto`, `housestatus`, `status`) VALUES
('H-000003', 'Usr-000001', '2015/03/26', '09:48:01', 'cc', 'cc', 'cc', 'cc', 'cc', '19', 'cc', 'cc', 'cc', 'cc', 'cc'),
('H-000001', 'Usr-000002', '2015/03/26', '09:47:17', 'aa', 'aa', 'aa', 'aa', 'aa', '21', 'aa', 'aa', 'aa', 'aa', 'aa'),
('H-000002', 'Usr-000002', '2015/03/26', '09:47:43', 'bb', 'bb', 'bb', 'bb', 'bb', '20', 'bb', 'bb', 'bb', 'bb', 'bb');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_news`
--

CREATE TABLE IF NOT EXISTS `tbl_news` (
  `newsid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `newsdate` date DEFAULT NULL,
  `newstime` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`newsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_news`
--

INSERT INTO `tbl_news` (`newsid`, `title`, `description`, `newsdate`, `newstime`, `status`, `userid`) VALUES
('N-000005', 'bbbbbbbbb', 'bbbbbbbbb', '2015-03-25', '12:48:45', 'bbbbbbbbbb', 'Usr-000002'),
('N-000004', 'aaaa', 'aaaaa', '2015-03-25', '12:48:27', 'aaa', 'Usr-000002'),
('N-000003', 'aaa', 'aaa', '2015-03-25', '12:37:30', 'aaa', 'Usr-000002');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_photo`
--

CREATE TABLE IF NOT EXISTS `tbl_photo` (
  `photoid` int(11) NOT NULL AUTO_INCREMENT,
  `houseid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`photoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_photo`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_township`
--

CREATE TABLE IF NOT EXISTS `tbl_township` (
  `townshipid` int(11) NOT NULL AUTO_INCREMENT,
  `townshipname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cityid` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`townshipid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `tbl_township`
--

INSERT INTO `tbl_township` (`townshipid`, `townshipname`, `cityid`) VALUES
(21, 'aaaaa', '10'),
(19, 'aa', '9'),
(20, 'bbbbb', '9');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `userid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fullname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dob` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(135) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(135) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `usertype` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`userid`, `fullname`, `dob`, `gender`, `phone`, `email`, `username`, `password`, `usertype`, `role`) VALUES
('Usr-000002', 'bb', '23-Feb-2015', 'female', 'bb', 'bb', 'bb', '21ad0bd836b90d08f4cf640b4c298e7c', 'bb', 'bb'),
('Usr-000001', 'aaa', '23-Feb-2015', 'male', 'aa', 'aa', 'aa', '4124bc0a9335c27f086f24ba207a4912', 'aa', 'aa');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
