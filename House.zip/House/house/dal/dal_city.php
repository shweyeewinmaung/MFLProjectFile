<?php
function GetCityDataByCityName($cityname)
{
	$sql="SELECT * FROM tbl_city WHERE cityname='$cityname'";
	return mysql_query($sql);
}
function GetCityDataBy_CityID($cityid){
	$sql="SELECT * FROM tbl_city WHERE cityid='$cityid'";
	$ret=mysql_query($sql);
	return $ret;
}
function GetCityDataBy_City($cityid){
	$sql="SELECT * FROM tbl_city WHERE cityid='$cityid'";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row[1];
	
}


function GetCityDataByCity($CityID)
{
	$sql="SELECT * FROM tbl_city  order by cityid asc";
	return mysql_query($sql);

}
/*function getAllCityData(){
	$sql="Select * from tbl_city order by cityid";
	$ret=mysql_query($sql);
	return $ret;
}

function GetCityDataBy_CityID($cityid){
	$sql="SELECT * FROM tbl_city WHERE cityid='$cityid'";
	$ret=mysql_query($sql);
	return $ret;
}

function GetCityDataByCityName($cityname)
{
	$sql="SELECT * FROM tbl_city WHERE cityname='$cityname'";
	return mysql_query($sql);
}

function GetCityNameByCityID($cityid)
{
	$sql="SELECT * FROM tbl_city WHERE cityid='$cityid'";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row['cityname'];
}
function InsertCity($cityname,$countryname)
{
	$sql="INSERT INTO tbl_city(cityname,countryid) VALUES('$cityname','$countryname')";
	$ret=mysql_query($sql);
	return $ret;
	
}

function UpdateCity($cityname,$countryname){
	$sql="update tbl_city set cityname=$cityname where cityid='$cityid'";
	$ret=mysql_query($sql);
	return $ret;
}

function DeleteCity($cityid,$countryname){
	$sql="delete tbl_city where cityid=$cityid";
	$ret=mysql_query($sql);
	return $ret;
}*/
function UpdateCity($CityName, $CountryName,$CityID)
{
	$sql="UPDATE tbl_city SET cityname='$CityName', 
							  countryid='$CountryName' 
							 
							WHERE cityid='$CityID'";
					
	mysql_query($sql);
	
}
function InsertCity($cityname,$countryname)
{
	$sql="INSERT INTO tbl_city(cityname,countryid) VALUES('$cityname','$countryname')";
	mysql_query($sql);
	
	
}
function DeleteCity($CityName, $CountryID,$CityID){
	$sql="delete from tbl_city where cityid='$CityID'";
	$ret=mysql_query($sql);
	return $ret;
}
?>