<?php

function GetNewsDataByNewsID($newsid)
{
	$sql="SELECT * FROM tbl_news WHERE newsid='$newsid'";
	return mysql_query($sql);
}
function GetNewsDataByNews($newsid)
{
	$sql="SELECT * FROM tbl_news order by newsid asc";
	return mysql_query($sql);
}


function InsertNews($newsid, $title, $description, $newsdate, $newstime, $status, $userid)
{
	$sql="INSERT INTO tbl_news(newsid, title, description, newsdate,newstime, status,userid)
	VALUES('$newsid', '$title', '$description', '$newsdate', '$newstime', '$status', '$userid')";
	mysql_query($sql);
}
function UpdateNews($NewsID, $Title, $Description, $NewsDate, $NewsTime, $Status, $UserID)
{
	$sql="UPDATE tbl_news SET title='$Title', 
								description='$Description', 
								newsdate='$NewsDate', 
								newstime='$NewsTime', 
								status='$Status',
								userid='$UserID' 
							WHERE newsid='$NewsID'";
							
	 mysql_query($sql);
	 
}
function DeleteNews($NewsID, $Title, $Description, $NewsDate, $NewsTime, $Status, $UserName)
{
	$sql="delete from tbl_news where newsid='$NewsID'";
	$ret=mysql_query($sql);
	return $ret;
}
?>