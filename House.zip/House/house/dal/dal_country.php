<?php


function GetCountryDataByCountryName($countryname)
{
	$sql="SELECT * FROM tbl_country WHERE countryname='$countryname'";
	return mysql_query($sql);
}
function GetCountryDataByCountryID($countryid)
{
	$sql="SELECT * FROM tbl_country WHERE countryid='$countryid'";
	return mysql_query($sql);
}
function GetCountryDataByCountry($countryid)
{
	$sql="SELECT * FROM tbl_country order by countryid asc";
	return mysql_query($sql);
}

function GetCountryNameByCountryID($CountryID)
{
	$sql="SELECT * FROM tbl_country WHERE countryid='$CountryID'";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row[1];
}

function GetAllCountryData()
{
	$sql="SELECT * FROM tbl_country";
	return mysql_query($sql);
}
/*function GetAllCountryData()
{
	$sql="SELECT * FROM tbl_country";
	return mysql_query($sql);
}

function GetCountryDataByCountryID($countryid)
{
	$sql="SELECT * FROM tbl_country WHERE countryid='$countryid'";
	return mysql_query($sql);
}

function GetCountryDataByCountryName($countryname)
{
	$sql="SELECT * FROM tbl_country WHERE countryname='$countryname'";
	return mysql_query($sql);
}

function GetCountryNameByCountryID($countryid)
{
	$sql="SELECT * FROM tbl_country WHERE countryid='$countryid'";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row['countryname'];
}

function InsertCountry($countryid,$countryname)
{
	$sql="INSERT INTO tbl_country($countryid,countryname) VALUES('$countryid','$countryname')";
	mysql_query($sql);
}




function DeleteCountry($countryid)
{
	$sql="DELETE FROM tbl_country WHERE countryid='$countryid'";
	mysql_query($sql);
}*/

function InsertCountry($countryname)
{
	$sql="INSERT INTO tbl_country(countryname) VALUES('$countryname')";
	mysql_query($sql);
	
	
}
function UpdateCountry($CountryID,$CountryName)
{
	$sql="UPDATE tbl_country SET countryname='$CountryName' 
							  
							 
							WHERE countryid='$CountryID'";
					
	mysql_query($sql);
	
}
function DeleteCountry($CountryID,$CountryName){
	$sql="delete from tbl_country where countryid='$CountryID'";
	$ret=mysql_query($sql);
	return $ret;
}
?>