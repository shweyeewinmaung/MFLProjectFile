<?php

function InsertTownship($townshipname,$cityname)
{
	$sql="INSERT INTO tbl_township(townshipname,cityid) VALUES('$townshipname','$cityname')";
	mysql_query($sql);
	
	
}
function GetTownshipDataByTownshipName($townshipname)
{
	$sql="SELECT * FROM tbl_township WHERE townshipname='$townshipname'";
	return mysql_query($sql);
}
function GetTownshipDataBy_TownshipID($townshipid){
	$sql="SELECT * FROM tbl_township WHERE townshipid='$townshipid'";
	
	$ret=mysql_query($sql);
	return $ret;
}
function GetTownshipDataBy_Township($townshipid){
	$sql="SELECT * FROM tbl_township  order by townshipid asc";
	return mysql_query($sql);
}
function GetTownshipNameByTownshipID($TownshipID){
	$sql="SELECT * FROM tbl_township WHERE townshipid='$TownshipID'";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row[1];
	
}


/*function getAllTownshipData(){
	$sql="Select * from tbl_township order by townshipid";
	$ret=mysql_query($sql);
	return $ret;
}

function GetTownshipDataBy_TownshipID($townshipid){
	$sql="SELECT * FROM tbl_township WHERE townshipid='$townshipid'";
	$ret=mysql_query($sql);
	return $ret;
}

function GetTownshipDataByTownshipName($townshipname)
{
	$sql="SELECT * FROM tbl_township WHERE townshipname='$townshipname'";
	return mysql_query($sql);
}

function GetTownshipNameByTownshipID($townshipid)
{
	$sql="SELECT * FROM tbl_township WHERE townshipid='$townshipid'";
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	
	return $row['townshipname'];
}
function InsertTownship($townshipname,$cityname)
{
	$sql="INSERT INTO tbl_township(townshipname,cityid) VALUES('$townshipname','$cityname')";
	mysql_query($sql);
	
	
}

function UpdateTownship($townshipname,$cityname){
	$sql="update tbl_township set townshipname=$townshipname where townshipid='$townshipid'";
	$ret=mysql_query($sql);
	return $ret;
}

function DeleteTownship($townshipid,$townshipname){
	$sql="delete tbl_township where townshipid=$townshipid";
	$ret=mysql_query($sql);
	return $ret;
}*/
function UpdateTownship($TownshipID,$TownshipName, $CityName)
{
	$sql="UPDATE tbl_township SET townshipname='$TownshipName', 
							  cityid='$CityName' 
							 
							WHERE townshipid='$TownshipID'";
					
	mysql_query($sql);
	
}
function DeleteTownship($CityID, $TownshipID,$TownshipName){
	$sql="delete from tbl_township where townshipid='$TownshipID'";

	$ret=mysql_query($sql);
	return $ret;
}
?>