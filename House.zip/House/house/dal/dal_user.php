<?php

function GetUserDataByUserID($userid)
{
	$sql="SELECT * FROM tbl_user WHERE userid='$userid'";
	return mysql_query($sql);
}
function GetUserDataByUser($userid)
{
	$sql="SELECT * FROM tbl_user order by userid asc";
	return mysql_query($sql);
}
function GetUserDataByUserName($username)
{
	$sql="SELECT * FROM tbl_user WHERE username='$username'";
	return mysql_query($sql);
}
function GetUserNameByUserID($UserID)
{
	$sql="SELECT * FROM tbl_user WHERE userid='$UserID'";
	
	$ret=mysql_query($sql);
	$row=mysql_fetch_array($ret);
	return $row[6];
}

/**function CheckMail($email)
{
    $sql="SELECT * FROM tbl_user WHERE username='$email'";
    $ret=mysql_query($sql);
    $num=mysql_num_rows($ret);
    
    if($num>0)
    {
        return true;
    }
    elseif($num==0 || $num<0)
    {
        return false;
    }
}

function CheckLogInData($username, $password)
{
	$sql="SELECT * FROM tbl_user WHERE username='$username' AND password='" . md5($password) . "'";
	$ret=mysql_query($sql);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

function GetUserDataByUserID($userid)
{
	$sql="SELECT * FROM tbl_user WHERE userid='$userid'";
	return mysql_query($sql);
}

function GetLogInData($username, $password)
{
	$sql="SELECT * FROM tbl_user WHERE username='$username' AND password='" . md5($password) . "'";
	return mysql_query($sql);
}

function InsertUser($userid, $fullname, $dob, $gender, $phone, $email, $username, $password, $role)
{
	$sql="INSERT INTO tbl_user(userid,fullname,dob,gender,phone,email,username,password,role)
	VALUES('$userid', '$fullname', '$dob', '$gender', '$phone', '$email', '$username', '" . md5($password) . "', '$role')";
	mysql_query($sql);
}

function UpdateUserData($userid, $fullname, $dob, $gender, $phone, $email, $username, $password, $role)
{
	$sql="UPDATE tbl_user SET fullname='$fullname', 
							  dob='$dob', 
							  gender='$gender', 
							  phone='$phone', 
							  email='$email'
							WHERE userid='$userid'";
	mysql_query($sql);
}

function UpdateUserPassword($userid, $Password)
{
	$sql="UPDATE tbl_user SET Password='" . md5($password) . "' WHERE userid='$userid'";
	mysql_query($sql);
}

function UpdateUserRole($userid, $role)
{
	$sql="UPDATE tbl_user SET role='$role' WHERE userid='$userid'";
	mysql_query($sql);
}



function DeleteUser($userid)
{
	$sql="DELETE FROM tbl_user WHERE userid='$userid'";
	mysql_query($sql);
}*/
function InsertUser($userid, $fullname, $dob, $gender, $phone, $email, $username, $password,$usertype,$role)
{
	$sql="INSERT INTO tbl_user(userid,fullname,dob,gender,phone,email,username,password,usertype,role)
	VALUES('$userid', '$fullname', '$dob', '$gender', '$phone', '$email', '$username', '" . md5($password) . "', '$usertype', '$role')";
	mysql_query($sql);
}
function UpdateUser($UserID,$FullName,$DOB,$Gender,$Phone,$Email,$UserName,$Password,$UserType,$Role)
{
	$sql="UPDATE tbl_user SET fullname='$FullName', 
							  dob='$DOB', 
							  gender='$Gender', 
							  phone='$Phone', 
							  email='$Email',
							  username='$UserName', 
							  password='" . md5($password) . "', 
							  usertype='$UserType'
							WHERE userid='$UserID'";
	mysql_query($sql);
}
function DeleteUser($UserID)
{
	$sql="DELETE FROM tbl_user WHERE userid='$UserID'";
	mysql_query($sql);
}
?>