<?php

function GetHouseDataByHouseID($houseid)
{
	$sql="SELECT * FROM tbl_house WHERE houseid='$houseid'";
	return mysql_query($sql);
}

function GetHouseDataByHouse($houseid)
{
	$sql="SELECT * FROM tbl_house order by houseid asc";
	return mysql_query($sql);
}

/*function GetAllHouseDataASC()
{
	$sql="SELECT * FROM tbl_house ORDER BY houseid";
	return mysql_query($sql);
}

function GetAllHouseDataDESC()
{
	$sql="SELECT * FROM tbl_house ORDER BY houseid DESC";
	return mysql_query($sql);
}

function GetHouseDataByHouseID($houseid)
{
	$sql="SELECT * FROM tbl_house WHERE houseid='$houseid'";
	return mysql_query($sql);
}

function InsertHouse($houseid, $username, $uploaddate, $uploadtime, $housetype, $width, $length, $houseno, $road, $townshipname, $description, $price, $wantto, $housestatus, $status)
{
	$sql="INSERT INTO tbl_house(houseid, username, uploaddate, uploadtime, housetype, width, length, houseno, road, townshipname, description, price, wantto, housestatus, status)
	VALUES('$houseid', '$username', '$uploaddate', '$uploadtime', '$housetype', '$width', '$length', '$houseno', '$road', '$townshipname', '$description', '$price', '$wantto', '$housestatus', '$status')";
	mysql_query($sql);
}

function UpdateHouse($houseid, $username, $uploaddate, $uploadtime, $housetype, $width, $length, $houseno, $road, $townshipname, $description, $price, $wantto, $housestatus, $status)
{
	$sql="UPDATE tbl_house SET username='$username', 
								uploaddate='$uploaddate', 
								uploadtime='$uploadtime' 
								$housetype='$housetype'
								width='$width', 
								length='$length', 
								houseno='$houseno' ,
								$road='$road',
								townshipname='$townshipname', 
								description='$description' 
								$price='$price'
								wantto='$wantto', 
								housestatus='$housestatus', 
								status='$status' 
							WHERE houseid='$houseid'";
	mysql_query($sql);
}

function DeleteHouse($houseid)
{
	$sql="DELETE FROM tbl_house WHERE houseid='$houseid'";
	mysql_query($sql);
}*/
function InsertHouse($houseid, $userid, $uploaddate, $updatetime, $housetype, $width, $length, $houseno, $road, $townshipid, $description, $price, $wantto, $housestatus, $status)
{
	$sql="INSERT INTO tbl_house
	       (houseid, userid, uploaddate, updatetime, housetype, width, length, houseno, road, townshipid, description, price, wantto, housestatus, status)
	VALUES('$houseid', '$userid', '$uploaddate', '$updatetime', '$housetype', '$width', '$length', '$houseno', '$road', '$townshipid', '$description', '$price', '$wantto', '$housestatus', '$status')";

	mysql_query($sql);


}
function UpdateHouse($HouseID, $UserID, $UploadDate, $UpdateTime, $HouseType, 
                     $Width, $Length, $HouseNo, $Road, $TownshipID, $Description,
					 $Price, $WantTo, $HouseStatus, $Status)
{ 

	$sql="UPDATE tbl_house SET  userid='$UserID', 
								uploaddate='$UploadDate', 
								updatetime='$UpdateTime', 
								housetype='$HouseType',
								width='$Width', 
								length='$Length', 
								houseno='$HouseNo' ,
								road='$Road',
								townshipid='$TownshipID', 
								description='$Description' ,
								price='$Price',
								wantto='$WantTo', 
								housestatus='$HouseStatus', 
								status='$Status' 
							WHERE houseid='$HouseID'";
						
	mysql_query($sql) ;
}

function DeleteHouse($HouseID, $UserName, $UploadDate, $UpdateTime, 
                     $HouseType, $Width, $Length, $HouseNo, $Road, 
					 $TownshipName, $Description, $Price, $WantTo, $HouseStatus, $Status)

{
	$sql="DELETE FROM tbl_house WHERE houseid='$HouseID'";
	mysql_query($sql);
}
?>