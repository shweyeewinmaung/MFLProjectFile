<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../dal/dal_township.php");
require_once("../dal/dal_house.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");

if (isset($_POST['btnUpdate']) && isset($_POST['HouseID']) )
{
	
	$HouseID=Clean($_POST['HouseID']);
	$UserName=Clean($_POST['UserName']);
	
	$retUserName=GetUserDataByUserName($UserName);
	$rowUserName=mysql_fetch_array($retUserName);
	
	$UserID=$rowUserName[0];
	
	$UploadDate=date("Y/m/d");
	$UpdateTime=GetCurrentTime();
	$HouseType=Clean($_POST['HouseType']);
	$Width=Clean($_POST['Width']);
	$Length=Clean($_POST['Length']);
	$HouseNo=Clean($_POST['HouseNo']);
	$Road=Clean($_POST['Road']);
	$TownshipName=Clean($_POST['TownshipName']);
	
	$retTownshipName=GetTownshipDataByTownshipName($TownshipName);
	$rowTownshipName=mysql_fetch_array($retTownshipName);
	
	$TownshipID=$rowTownshipName[0]; 
	
	$Description=Clean($_POST['Description']);
	$Price=Clean($_POST['Price']);
	$WantTo=Clean($_POST['WantTo']);
	$HouseStatus=Clean($_POST['HouseStatus']);
	$Status=Clean($_POST['Status']);

	
	UpdateHouse($HouseID, $UserName, $UploadDate, $UpdateTime, $HouseType, $Width, $Length, $HouseNo, $Road, $TownshipName, $Description, $Price, $WantTo, $HouseStatus, $Status);
	$msg="Successfully House Data Updated";

}
if (isset($_GET['houseid']) && $_GET['houseid']!="")
{
	$houseid=Clean($_GET['houseid']);
	$ret=GetHouseDataByHouseID($houseid);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head></head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box" style="height:auto;">
					<!-- Box Head -->
					<div class="box-head">
						<h2>House Update</h2>
					</div>
                    <!-- End Box Head -->
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="entrystyle">
                    <form method="post" class="formstyle" >
                    <input type="hidden" name="HouseID" value="<?php echo $row['houseid']; ?>" required  size="48" style="height:27px;"/>
  <table width="400" border="0">
    <tr>
      <td colspan="2"  height="40"><font style="color:red;"><?php  echo $msg; ?></font></td>
    </tr>
    
     
     <tr>
      <td height="40" style="text-align:right;">Username:</td>
      <td>&nbsp;&nbsp;
             
        <select name="UserName"  onChange="showCustomer(this.value)"  class="selectstyle">
	    <option><?php echo GetUserNameByUserID($row[1]);?></option>
		<?php
	   		$sql="select * from tbl_user";
					
             $ret= mysql_query($sql);
             while($rowsd=mysql_fetch_array($ret)){?>
          <option value="<?php echo $rowsd['userid'];?>" ><?php echo $rowsd['username'];?></option>
          <?php }?>
	   
		   </select>
           
           </td>
    </tr>
   
    <tr>
      <td height="40" style="text-align:right;">House Type:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
       
        <input name="HouseType" type="text"  size="48" style="height:27px;" value="<?php echo $row['housetype']; ?>"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Width:</td>
      <td>&nbsp;&nbsp;
        <input name="Width" type="text" size="48" style="height:27px;"  value="<?php echo $row['width']; ?>"/></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Length:</td>
      <td>&nbsp;&nbsp;
        <input name="Length" type="text" size="48" style="height:27px;"  value="<?php echo $row['length']; ?>" /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">House No:</td>
      <td>&nbsp;&nbsp;
        <input name="HouseNo" type="text" size="48" style="height:27px;" value="<?php echo $row['houseno']; ?>"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Road:</td>
      <td>&nbsp;&nbsp;
        <input name="Road" type="text" size="48" style="height:27px;"  value="<?php echo $row['houseno']; ?>" /></td>
    </tr>
    
    
     <tr>
      <td height="40" style="text-align:right;">Township Name:</td>
      <td>&nbsp;&nbsp;           
            <select name="TownshipName"  onChange="showCustomer(this.value)"  class="selectstyle">
	    <option><?php echo GetTownshipNameByTownshipID($row[9]);?></option>
		<?php
	   		$sql="select * from tbl_township";
					
             $ret= mysql_query($sql);
             while($rowsd1=mysql_fetch_array($ret)){?>
          <option value="<?php echo $rowsd1['townshipid'];?>" ><?php echo $rowsd1['townshipname'];?></option>
          <?php }?>
	   
		   </select></td>
    </tr>
	
    <tr>
      <td height="40" style="text-align:right;">Description:</td>
      <td>&nbsp;&nbsp;
         <textarea name="Description" cols="23" rows="3"  class="txtbox"><?php echo $row['description']; ?> </textarea></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Price:</td>
      <td>&nbsp;&nbsp;
        <input name="Price" type="text"  size="48" style="height:27px;"  value="<?php echo $row['price']; ?>" /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Want to:</td>
      <td>&nbsp;&nbsp;
        <input name="WantTo" type="text" size="48" style="height:27px;"  value="<?php echo $row['wantto']; ?>" /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">House Status:</td>
      <td>&nbsp;&nbsp;
        <input name="HouseStatus" type="text" size="48" style="height:27px;" value="<?php echo $row['housestatus']; ?>"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Status:</td>
      <td>&nbsp;&nbsp;
        <input name="Status" type="text"  size="48" style="height:27px;"  value="<?php echo $row['status']; ?>" /></td>
    </tr>
   
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input name="btnUpdate" type="submit"  value="Update" class="btnstyle">
      <input name="Reset" type="reset" value="Cancel" class="btnstyle"><br><br>
      <!--<input type="submit" name="submit" id="submit" value="" class="entry" onClick="return Validate()">
      <input type="reset" name="Reset" id="button" value="" class="reset">--></td>
    </tr>
  </table>
</form>
                    
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
