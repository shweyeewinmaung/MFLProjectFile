<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_country.php");
require_once("../dal/dal_city.php");
require_once("../library/globalfunction.php");


if(isset($_POST['btnDelete']) && isset($_POST['CityName']) !="")
{
	$CityID=Clean($_POST['CityID']);
	$CityName=Clean($_POST['CityName']);
	$CountryName=Clean($_POST['countryname']);
	$retCountry=GetCountryDataByCountryName($CountryName);
	$rowCountry=mysql_fetch_array($retCountry);
	DeleteCity($CityName, $CountryID, $CityID);
	$msg="Successfully Deleted";
	print "<script language=\"JavaScript\">window.location.href=\"citylist.php \";</script>";
	
}






if (isset($_GET['cityid']) && $_GET['cityid']!="")
{
	$cityid=Clean($_GET['cityid']);
	$ret=GetCityDataBy_CityID($cityid);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head></head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>City Delete</h2>
					</div>
                    <!-- End Box Head -->
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="entrystyle">
                 
                    <form method="post" class="formstyle">
                    
                 
  <table width="400" border="0">
    <tr>
      <td colspan="2"  height="40"></td>
    </tr> <tr>
      </tr>
    </tr>
      <tr>
      <td colspan="2"  height="40"> <font style="color:red;"><?php   echo $msg; ?></font></td>
    </tr> <tr>
      </tr>
    </tr>
    
     <tr style="display:none;">
     <td height="40" style="text-align:right;">City ID:</td>
      <td >&nbsp;&nbsp;<label for="obj"></label>
        <label for="CityID"></label>
        <input name="CityID" type="hidden" id="txtCityID" size="48" style="height:27px;"  value="<?php echo $row['cityid']; ?>"  /></td>
    </tr>
    <tr>
     <td height="40" style="text-align:right;">City Name:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="CityName"></label>
        <input name="CityName" type="text" id="txtcityname" size="48" style="height:27px;"  value="<?php echo $row['cityname']; ?>" /></td>
    </tr>
    <tr>
    
    <td height="40" style="text-align:right;">Country Name:</td>
      <td>&nbsp;&nbsp;
     
     
    <select name="countryname"  onChange="showCustomer(this.value)"  class="selectstyle">

	   
        <option>
         <?php
          echo GetCountryNameByCountryID($row[2]);?>
		  </option>
		<?php
	   		$sql="select * from tbl_country";
					
             $ret= mysql_query($sql);
             while($rowsd=mysql_fetch_array($ret)){?>
          <option value="<?php echo $rowsd['countryid'];?>" ><?php echo $rowsd['countryname'];?></option>
          <?php }?>
         ?>
        
	  
	   
		   </select>
      
      
      </td>
    </tr>
    
	
    
    
   
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input name="btnDelete" type="submit" id="btnDelete"  value="Delete"  class="btnstyle">
      <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle" ><br><br>
      <!--<input type="submit" name="submit" id="submit" value="" class="entry" onClick="return Validate()">
      <input type="reset" name="Reset" id="button" value="" class="reset">--></td>
    </tr>
  </table>
</form>
                    
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
