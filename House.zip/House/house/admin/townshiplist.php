<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_township.php");
require_once("../dal/dal_city.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");
require_once("../library/pager_house.php");


/*$pageSize=10;



if(isset($_GET['page']))
{
	$currentPageIndex=Clean($_GET['page']);
}
else
{
	$currentPageIndex=1;
}
$objPager=new pager($pageSize,$currentPageIndex);

/*$sql=$objPager->SearchData_GetAllCar();
$ret=$objPager->Search_Data($sql);
$num=mysql_num_rows($ret);*/
$ret=GetTownshipDataBy_Township($townshipid);
$num=mysql_num_rows($ret);

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  
    
</head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<!--<div class="box-head">
						<h2>Country List</h2>
					</div>-->
                    <!-- End Box Head -->
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="liststyledesign">
                    <form name="form1" method="post" action="">
  <table width="700" border="0">
    
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
	<tr>
      <td align="center" width="180" height="40" class="listfontstyle">Township ID</td>
	  <td align="center" width="180" class="listfontstyle">Township Name</td>
	   <td align="center" width="180" class="listfontstyle">City Name</td>
	  <td  align="center"width="200" class="listfontstyle">Edit/ Delete </td>
     </tr>
	 <tr>
      <td align="center">&nbsp;</td>
	  <td align="center">&nbsp;</td>
       <td align="center">&nbsp;</td>
	  <td align="center">&nbsp;</td>
     </tr>
   	<?php while($row=mysql_fetch_array($ret)) 
	{?>
	
	 <tr height="30">
    <td width="200" style="text-align:center;"><?php echo $row['townshipid']; ?></td>
	<td width="186" style="text-align:center;"><?php echo $row['townshipname']; ?></td>
	<td width="186" style="text-align:center;"><?php echo GetCityDataBy_City($row['2']); ?></td>
	<td align="center"><a href="townshipupdate.php?townshipid=<?php echo $row['townshipid']; ?>" target="_blank">
    <img src="../images/wrench-screwdriver.png" /></a> 
   &nbsp; &nbsp;
    <a href="townshipdelete.php?townshipid=<?php echo $row['townshipid']; ?>" target="_blank">
    <img src="../images/cross-script.png" /></a> 
     &nbsp; &nbsp;
    <a href="townshipdetail.php?townshipid=<?php echo $row['townshipid']; ?>" target="_blank">
    Detail</a> 
    </td>
    </tr>
    <?php } ?>
	<tr>
	<td>&nbsp;</td>
	<td>&nbsp;</td>
	</tr>
	
     	
    <tr>
      <td align="center" colspan="7">
	
	  
	  </td>
      
    </tr>
    <!--<tr>
      <td align="" colspan="7">Note*** e=english , m=myanmar</td>
    </tr>-->
  </table>
</form>
                  
                    
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
