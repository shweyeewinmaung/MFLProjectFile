<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_country.php");
require_once("../library/globalfunction.php");

if(isset($_POST['btnUpdate']) && isset($_POST['CountryID']))
{
	$CountryID=Clean($_POST['CountryID']);
	$CountryName=Clean($_POST['CountryName']);
	
	UpdateCountry($CountryID, $CountryName);
	$msg="Successfully Updated";
}



if (isset($_GET['countryid']) && $_GET['countryid']!="")
{
	$countryid=Clean($_GET['countryid']);
	$ret=GetCountryDataByCountryID($countryid);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head></head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Country Update</h2>
					</div>
                    <!-- End Box Head -->
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="entrystyle">
                 
                    <form method="post" class="formstyle">
                    
                 
  <table width="400" border="0">
    <tr>
      <td colspan="2"  height="40"></td>
    </tr> <tr>
      </tr>
    </tr>
     <tr>
      <td colspan="2"  height="40"><font style="color:red;"><?php   echo $msg; ?></font></td>
    </tr> <tr>
      </tr>
    </tr>
     <tr style="display:none;">
     <td height="40" style="text-align:right;">Country ID:</td>
      <td >&nbsp;&nbsp;<label for="obj"></label>
        <label for="CountryID"></label>
        <input name="CountryID" type="hidden" id="txtCountryID" size="48" style="height:27px;"  value="<?php echo $row['countryid']; ?>"  /></td>
    </tr>
    <tr>
     <td height="40" style="text-align:right;">Country Name:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="CountryName"></label>
        <input name="CountryName" type="text" id="txtCountryName" size="48" style="height:27px;"  value="<?php echo $row['countryname']; ?>" /></td>
    </tr>
        
	
    
    
   
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input name="btnUpdate" type="submit" id="btnUpdate"  value="Update"  class="btnstyle">
      <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle" ><br><br>
      <!--<input type="submit" name="submit" id="submit" value="" class="entry" onClick="return Validate()">
      <input type="reset" name="Reset" id="button" value="" class="reset">--></td>
    </tr>
  </table>
</form>
                    
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
