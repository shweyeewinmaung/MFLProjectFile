<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_news.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");

if (isset($_POST['submit']) )
{	
	//$UserID=AutoID('tbl_user','UserID','Usr-',6);
	$newsid=AutoID('tbl_news','newsid','N-',6);
	$title=Clean($_POST['txttitle']);
	$description=Clean($_POST['txtdescription']);
	$newsdate=date("Y/m/d");
	$newstime=GetCurrentTime();
	
	$status=Clean($_POST['txtstatus']);
	$username=Clean($_POST['username']);
	
	
	
	
	

		
		InsertNews($newsid, $title, $description, $newsdate, $newstime, $status, $username);
		$msg="Successfully News Save";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  
    
</head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>News Entry</h2>
					</div>
                    <!-- End Box Head -->
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="entrystyle">
                    <form name="townshipform" method="post" action="" class="formstyle" >
   <font style="color:red;"> <?php echo "<tr><th colspan='2'>$msg</th></tr>" ?></font>
  <table width="400" border="0">
    <tr>
      <td colspan="2"  height="40"></td>
    </tr>
    <tr>
     <td height="40" style="text-align:right;">News ID</td>
                <td>
                &nbsp;&nbsp;<label for="obj"></label>
        <label for="newsid"></label>
                <input type="text" name="newsid" value="<?php echo AutoID('tbl_news','newsid','N-',6); ?>" required /></td>
            </tr>
     <tr>
      <td height="40" style="text-align:right;">Title:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txttitle"></label>
        <input name="txttitle" type="text" id="txttitle" size="48" style="height:27px;"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Description:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtdescription"></label>
         <textarea name="txtdescription" cols="23" rows="3"  id="txtdescription" class="txtbox"></textarea></td>
    </tr>
    <!--<tr>
      <td height="40" style="text-align:right;">News Date:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtnewsdate"></label>
        <input name="txtnewsdate" type="text" id="txtnewsdate" size="48" style="height:27px;"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">News Date:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtnewstime"></label>
        <input name="txtnewstime" type="text" id="txtnewstime" size="48" style="height:27px;"  /></td>
    </tr>-->
    <tr>
      <td height="40" style="text-align:right;">Status:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtstatus"></label>
        <input name="txtstatus" type="text" id="txtstatus" size="48" style="height:27px;"  /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Username:</td>
      <td>&nbsp;&nbsp;
            <select name="username"  onChange="showCustomer(this.value)"  class="selectstyle">
	   <option> </option>
	   
	   <?php 
	   		$sql="select * from tbl_user";
					
             $ret= mysql_query($sql);
             while($rowsd=mysql_fetch_array($ret)){?>
          <option value="<?php echo $rowsd['userid'];?>" ><?php echo $rowsd['username'];?></option>
          <?php }?>
	   
		   </select>
           
           </td>
    </tr>
   
    
    
	
    
    
   
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input name="submit" type="submit" id="submit"  value="Save" class="btnstyle">
      <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle"><br><br>
      <!--<input type="submit" name="submit" id="submit" value="" class="entry" onClick="return Validate()">
      <input type="reset" name="Reset" id="button" value="" class="reset">--></td>
    </tr>
  </table>
</form>
                    
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
