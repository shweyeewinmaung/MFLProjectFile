<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");
require_once("../library/pager_house.php");


/*$pageSize=10;



if(isset($_GET['page']))
{
	$currentPageIndex=Clean($_GET['page']);
}
else
{
	$currentPageIndex=1;
}
$objPager=new pager($pageSize,$currentPageIndex);

/*$sql=$objPager->SearchData_GetAllCar();
$ret=$objPager->Search_Data($sql);
$num=mysql_num_rows($ret);*/
$ret=GetUserDataByUser($userid);
$num=mysql_num_rows($ret);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <style>
    .d1{ text-align:right; font-size:13px; height:20px;}
.d2{margin-left:3px; font-size:13px; height:20px;}
    </style>
    
</head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<!--<div class="box-head">
						<h2>Country List</h2>
					</div>-->
                    <!-- End Box Head -->
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="liststyledesign">
                     <?php  while($row=mysql_fetch_array($ret))
					{?>
                    <form name="form1" method="post" action="">
                   
                     <div style="margin-left:60px; padding:10px; border:1px solid #104c6b; border-radius:10px;margin-top: 20px; width:600px; float:left;">
  <table>
                            	<tr>
                                	<td colspan="7" style=" font-size:18px; padding-bottom:10px;"><?php echo $row['userid']; ?></td>
                                </tr>
                               <!--?php
						for($i=0;$i<$num;$i++)
						{
							$row=mysql_fetch_array($ret);
						?-->
                                <tr>
                                   
                                    <td width="15%" class="d1">User ID : </td>
                                    <td width="15%" class="d2"><?php echo $row['userid']; ?></td>
                                    <td width="15%" class="d1">Phone : </td>
                                    <td width="15%" class="d2"><?php echo $row['phone']; ?></td>
                                    <td width="15%" class="d1">User Type : </td>
                                    <td width="15%" class="d2"><?php echo $row['usertype']; ?></td>
                                   
                                    
                                </tr>
                                <tr>
                                    <td width="15%" class="d1">Full Name : </td>
                                    <td width="15%" class="d2"><?php echo $row['fullname']; ?></td>
                                    <td width="15%" class="d1">Email : </td>
                                    <td width="15%" class="d2"><?php echo $row['email']; ?></td>
                                    <td width="15%" class="d1">Role : </td>
                                    <td width="15%" class="d2"><?php echo $row['role']; ?></td>
                                    
                                </tr>
                                <tr>
                                    <td width="15%" class="d1">D.O.B : </td>
                                    <td width="15%" class="d2"><?php echo $row['dob']; ?></td>
                                    <td width="15%" class="d1">UserName : </td>
                                    <td width="15%" class="d2"><?php echo $row['username']; ?></td>
                                    <td width="15%" class="d1"> </td>
                                    <td width="15%" class="d2"></td>
                                </tr>
                                 <tr>
                                    <td width="15%" class="d1">Gender : </td>
                                    <td width="15%" class="d2"><?php echo $row['gender']; ?></td>
                                    <td width="15%" class="d1"></td>
                                    <td width="15%" class="d2"></td>
                                    <td width="15%" class="d1"></td>
                                    <td width="15%" class="d2"></td>
                                </tr>
                                
                                <tr> <td colspan="6" style="text-align:right; margin-right:10px; ">
                                 <a href="userdetail.php?userid=<?php echo $row['userid']; ?>" target="_blank">
    Detail</a> 
   &nbsp; &nbsp;
                                 <a href="userupdate.php?userid=<?php echo $row['userid']; ?>">
    <img src="../images/wrench-screwdriver.png"  width="20" height="20"/></a> 
   &nbsp; &nbsp;
    <a href="userdelete.php?userid=<?php echo $row['userid']; ?>">
    <img src="../images/cross-script.png" width="20" height="20" /></a></td></tr>
                            </table>
                            </div>
                            
</form>
                  
                    <?php } ?>
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
