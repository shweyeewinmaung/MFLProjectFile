<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");

if (isset($_POST['btnDelete']) && isset($_POST['UserID']) )
{	
	//$UserID=AutoID('tbl_user','UserID','Usr-',6);
	$UserID=Clean($_POST['UserID']);
	$FullName=Clean($_POST['FullName']);
	$DOB=Clean($_POST['DOB']);
	$Gender=Clean($_POST['Gender']);
	$Phone=Clean($_POST['Phone']);
	$Email=Clean($_POST['Email']);
	$UserName=Clean($_POST['UserName']);
	$Password=Clean($_POST['Password']);
	$UserType=Clean($_POST['UserType']);
	$Role=Clean($_POST['Role']);
	
	
	
	DeleteUser($UserID,$FullName,$DOB,$Gender,$Phone,$Email,$UserName,$Password,$UserType,$Role);
	$msg= "Successfully Deleted";
	print "<script language=\"JavaScript\">window.location.href=\"userlist.php\";</script>";

}

if (isset($_GET['userid']) && $_GET['userid']!="")
{
	$userid=Clean($_GET['userid']);
	$ret=GetUserDataByUserID($userid);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
}
?>

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <style>
 
 table.calendar input {
    
    width: 40px;
}
 </style>
    
</head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>User Delete</h2>
					</div>
                    <!-- End Box Head -->
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="entrystyle">
                    <form method="post" class="formstyle" >
  
  <table width="400" border="0">
   
     <tr>
      <td colspan="2"  height="40"><font style="color:red;"><?php   echo $msg; ?></font></td>
    </tr>
    <tr style="display:none;">
     <td height="40" style="text-align:right;">User ID:</td>
      <td >&nbsp;&nbsp;<label for="obj"></label>
        <label for="UserID"></label>
        <input name="UserID" type="hidden" id="txtUserID" size="48" style="height:27px;"  value="<?php echo $row['userid']; ?>"  /></td>
    </tr>
    <!--<tr>
            	<td>User ID</td>
                <td><input type="text" name="txtuserid" value="<!--?php echo AutoID('tbl_user','userid','Usr-',6); ?>" required /></td>
            </tr>-->
     <tr>
      <td height="40" style="text-align:right;">Full Name:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="FullName"></label>
        <input name="FullName" type="text" id="txtFullName" size="48" style="height:27px;"  value="<?php echo $row['fullname']; ?>" /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">DOB:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="DOB"></label>
      
        <input name="DOB" type="text" size="48" id="txtDOB" maxlength="11" style="height:27px;"  value="<?php echo $row['dob']; ?>" onfocus="showCalender(calender,this)"/>
       
       </td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Gender:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="Gender" ></label>
        <input type="radio" name="Gender" value="male"<?php if($row['gender']=="male"){ echo "checked";} ?> style="width:20px; " ><font style="color:#333;">Male</font>
		<input type="radio" name="Gender" value="female" <?php if($row['gender']=="female"){ echo "checked";} ?>     style="width:20px;font-size:14px;" ><font style="color:#333;">Female</font>
        </td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Phone:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="Phone"></label>
        <input name="Phone" type="text" id="txtPhone" size="48" style="height:27px;"  value="<?php echo $row['phone']; ?>" /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Email:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="Email"></label>
        <input name="Email" type="text" id="txtEmail" size="48" style="height:27px;"  value="<?php echo $row['email']; ?>" /></td>
    </tr>
     
     <tr>
      <td height="40" style="text-align:right;">Username:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="UserName"></label>
        <input name="UserName" type="text" id="txtUserName" size="48" style="height:27px;"  value="<?php echo $row['username']; ?>" disabled="disabled" /></td>
    </tr>
     <tr  style="display:none;">
      <td height="40" style="text-align:right;">Password:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="Password"></label>
        <input name="Password" type="hidden" id="txtPassword" size="48" style="height:27px;"  value="<?php echo $row['password']; ?>" /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">User Type:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="UserType"></label>
        <input name="UserType" type="text" id="txtUserType" size="48" style="height:27px;" value="<?php echo $row['usertype']; ?>"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Role:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="Role"></label>
        <input name="Role" type="text" id="txtRole" size="48" style="height:27px;"   value="<?php echo $row['role']; ?>"/></td>
    </tr>
    
    
	
    
    
   
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input name="btnDelete" type="submit" id="btnDelete"  value="Delete" class="btnstyle">
      <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle"><br><br>
      <!--<input type="submit" name="submit" id="submit" value="" class="entry" onClick="return Validate()">
      <input type="reset" name="Reset" id="button" value="" class="reset">--></td>
    </tr>
  </table>
</form>
                    
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
