<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../dal/dal_township.php");
require_once("../dal/dal_house.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");

  if (isset($_POST['submit']) )
{	
	//$UserID=AutoID('tbl_user','UserID','Usr-',6);
	$houseid=AutoID('tbl_house','houseid','H-',6);
	$username=Clean($_POST['username']);
	$uploaddate=date("Y/m/d");
	$updatetime=GetCurrentTime();
	$housetype=Clean($_POST['txthousetype']);
	$width=Clean($_POST['txtwidth']);
	$length=Clean($_POST['txtlength']);
	$houseno=Clean($_POST['txthouseno']);
	$road=Clean($_POST['txtroad']);
	$townshipname=Clean($_POST['townshipname']);
	$description=Clean($_POST['txtdescription']);
	$price=Clean($_POST['txtprice']);
	$wantto=Clean($_POST['txtwanto']);
	$housestatus=Clean($_POST['txthousestatus']);
	$status=Clean($_POST['txtstatus']);
	
	
	InsertHouse($houseid, $username, $uploaddate, $updatetime, $housetype, $width, $length, $houseno, $road, $townshipname, $description, $price, $wantto, $housestatus, $status);
	$msg="Successfully House Data Save";

}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head></head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box" style="height:auto;">
					<!-- Box Head -->
					<div class="box-head">
						<h2>House Entry</h2>
					</div>
                    <!-- End Box Head -->
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="entrystyle">
                    <form name="townshipform" method="post" action="" class="formstyle" >
  <table width="400" border="0">
    <tr>
      <td colspan="2"  height="40"><font style="color:red;"><?php  echo $msg; ?></font></td>
    </tr>
     <tr>
     <td height="40" style="text-align:right;">House ID</td>
                <td>
                &nbsp;&nbsp;
                <input type="text" name="houseid" value="<?php echo AutoID('tbl_house','houseid','H-',6); ?>" required  size="48" style="height:27px;" disabled="disabled"/></td>
            </tr>
     
     <tr>
      <td height="40" style="text-align:right;">Username:</td>
      <td>&nbsp;&nbsp;
             
        <select name="username"  onChange="showCustomer(this.value)"  class="selectstyle">
	   <option> </option>
	   
	   <?php 
	   		$sql="select * from tbl_user";
			echo $sql;
			
             $ret= mysql_query($sql);
             while($rowsd=mysql_fetch_array($ret)){?>
          <option value="<?php echo $rowsd['userid'];?>" ><?php echo $rowsd['username'];?></option>
          <?php }?>
	   
		   </select>
           
           </td>
    </tr>
   
    <tr>
      <td height="40" style="text-align:right;">House Type:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
       
        <input name="txthousetype" type="text"  size="48" style="height:27px;"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Width:</td>
      <td>&nbsp;&nbsp;
        <input name="txtwidth" type="text" size="48" style="height:27px;"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Length:</td>
      <td>&nbsp;&nbsp;
        <input name="txtlength" type="text" size="48" style="height:27px;"  /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">House No:</td>
      <td>&nbsp;&nbsp;
        <input name="txthouseno" type="text" size="48" style="height:27px;"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Road:</td>
      <td>&nbsp;&nbsp;
        <input name="txtroad" type="text" size="48" style="height:27px;"  /></td>
    </tr>
    
    
     <tr>
      <td height="40" style="text-align:right;">Township Name:</td>
      <td>&nbsp;&nbsp;           
            <select name="townshipname"  onChange="showCustomer(this.value)"  class="selectstyle">
	   <option> </option>
	   
	   <?php 
	   		$sql="select * from tbl_township";
			echo $sql;
			
             $ret= mysql_query($sql);
             while($rowsd=mysql_fetch_array($ret)){?>
          <option value="<?php echo $rowsd['townshipid'];?>" ><?php echo $rowsd['townshipname'];?></option>
          <?php }?>
	   
		   </select></td>
    </tr>
	
    <tr>
      <td height="40" style="text-align:right;">Description:</td>
      <td>&nbsp;&nbsp;
         <textarea name="txtdescription" cols="23" rows="3"  class="txtbox" ></textarea></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Price:</td>
      <td>&nbsp;&nbsp;
        <input name="txtprice" type="text"  size="48" style="height:27px;"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Want to:</td>
      <td>&nbsp;&nbsp;
        <input name="txtwanto" type="text" size="48" style="height:27px;"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">House Status:</td>
      <td>&nbsp;&nbsp;
        <input name="txthousestatus" type="text" size="48" style="height:27px;"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Status:</td>
      <td>&nbsp;&nbsp;
        <input name="txtstatus" type="text"  size="48" style="height:27px;"  /></td>
    </tr>
   
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input name="submit" type="submit"  value="Save" class="btnstyle">
      <input name="Reset" type="reset" value="Cancel" class="btnstyle"><br><br>
      <!--<input type="submit" name="submit" id="submit" value="" class="entry" onClick="return Validate()">
      <input type="reset" name="Reset" id="button" value="" class="reset">--></td>
    </tr>
  </table>
</form>
                    
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
