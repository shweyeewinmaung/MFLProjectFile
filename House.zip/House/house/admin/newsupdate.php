<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_news.php");
require_once("../dal/dal_user.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");

if (isset($_POST['btnUpdate'])&& isset($_POST['NewsID']) )
{	
	//$UserID=AutoID('tbl_user','UserID','Usr-',6);
	$NewsID=Clean($_POST['NewsID']);
	$Title=Clean($_POST['Title']);
	$Description=Clean($_POST['Description']);
	$NewsDate=date("Y/m/d");
	$NewsTime=GetCurrentTime();
	$Status=Clean($_POST['Status']);
	$UserName=Clean($_POST['UserName']);
	
	$retUserName=GetUserDataByUserName($UserName);
	$rowUserName=mysql_fetch_array($retUserName);
	
	$UserID=$rowUserName[0];
	
		UpdateNews($NewsID, $Title, $Description, $NewsDate, $NewsTime, $Status, $UserName);
		$msg="Successfully News Update";
}
if (isset($_GET['newsid']) && $_GET['newsid']!="")
{
	$newsid=Clean($_GET['newsid']);
	$ret=GetNewsDataByNewsID($newsid);
	$num=mysql_num_rows($ret);
	
	if($num>0)
	{
		$row=mysql_fetch_array($ret);
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  
    
</head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>News Update</h2>
					</div>
                    <!-- End Box Head -->
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="entrystyle">
                    <form name="townshipform" method="post" action="" class="formstyle" >
   
  <table width="400" border="0">
    <tr>
      <td colspan="2"  height="40"><font style="color:red;"><?php echo $msg; ?></font></td>
    </tr>
    <tr style="display:none;">
     <td height="40" style="text-align:right;">News ID</td>
                <td>
                &nbsp;&nbsp;<label for="obj"></label>
        
                <input type="hidden" name="NewsID" value="<?php echo $row['newsid']; ?>" /></td>
            </tr>
     <tr>
      <td height="40" style="text-align:right;">Title:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
       
        <input name="Title" type="text" id="txtTitle" size="48" style="height:27px;"  value="<?php echo $row['title']; ?>" /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Description:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="Description"></label>
         <textarea name="Description" cols="23" rows="3"  id="txtDescription" class="txtbox"><?php echo $row['description']; ?></textarea></td>
    </tr>
    <!--<tr>
      <td height="40" style="text-align:right;">News Date:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtnewsdate"></label>
        <input name="txtnewsdate" type="text" id="txtnewsdate" size="48" style="height:27px;"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">News Date:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtnewstime"></label>
        <input name="txtnewstime" type="text" id="txtnewstime" size="48" style="height:27px;"  /></td>
    </tr>-->
    <tr>
      <td height="40" style="text-align:right;">Status:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="Status"></label>
        <input name="Status" type="text" id="txtStatus" size="48" style="height:27px;" value="<?php echo $row['status']; ?>"  /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Username:</td>
      <td>&nbsp;&nbsp;
            <select name="UserName"  onChange="showCustomer(this.value)"  class="selectstyle">
	     <option><?php echo GetUserNameByUserID($row[6]);?></option>
		<?php
	   		$sql="select * from tbl_user";
					
             $ret= mysql_query($sql);
             while($rowsd=mysql_fetch_array($ret)){?>
          <option value="<?php echo $rowsd['userid'];?>" ><?php echo $rowsd['username'];?></option>
          <?php }?>
	   
		   </select>
           
           </td>
    </tr>
   
    
    
	
    
    
   
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input name="btnUpdate" type="submit" value="Update" class="btnstyle">
      <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle"><br><br>
      <!--<input type="submit" name="submit" id="submit" value="" class="entry" onClick="return Validate()">
      <input type="reset" name="Reset" id="button" value="" class="reset">--></td>
    </tr>
  </table>
</form>
                    
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
