<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../dal/dal_township.php");
require_once("../dal/dal_house.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");
require_once("../library/pager_house.php");

if(isset($_GET['houseid']) && $_GET['houseid']!="")
{	
	$houseid=$_GET['houseid'];
	//IncreaseView($houseid);
	$ret=GetHouseDataByHouseID($houseid);
	$num=mysql_num_rows($ret);
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

  
   <style>
   .tablecolumn1
{
	font-size:15px; 
	height:40px; 
	text-align:right; 
	background-color:none;
	color:#000;
	padding-right:10px;
}
.tablecolumn2
{
	font-size:15px; 
	height:40px; 
	background-color:none;
	color:#000;
	padding-left:10px;
}


   
   </style> 
</head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box" style="height:800px;">
					<!-- Box Head -->
					<div class="box-head">
						<h2>House Detail</h2>
					</div>
                    <!-- End Box Head -->
                    
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="liststyledesign">
                   <div style="width:700px; height:auto; margin-left:20px; margin-top:15px; ">
                   <?php
			if($num>0)
			{
				$row=mysql_fetch_array($ret);
				?>
                <div style="width:250px; height:auto; margin-left:20px; margin-top:5px; float:left;">
                <img src="../images/girl-hugging-the-globe.jpg" width="200" height="200" style="border:2px solid#000; " /></div>
                
		           <table width="420" style="border:2px solid#188ac6; box-shadow: 10px 5px 5px #0ea8f9; background-color:#83d0f8;">
                 
                   <tr >
                   
                   <td width="200" class="tablecolumn1">HouseID:</td>
                   <td width="200" class="tablecolumn2"><?php echo $row['houseid']; ?></td>
                   </tr>
                   <tr><?php 
																
									
									$retUser=GetUserDataByUserID($row['userid']);
									$rowUser=mysql_fetch_array($retUser);
									
								?>
                   <td class="tablecolumn1">UserName:</td>
                   <td class="tablecolumn2"><?php echo $rowUser['username']; ?></td>
                   </tr>
                   <tr>
                   <td class="tablecolumn1">Upload Date:</td>
                   <td class="tablecolumn2"><?php echo $row['uploaddate']; ?></td>
                   </tr>
                   <tr>
                   <td class="tablecolumn1">Upload Time:</td>
                   <td class="tablecolumn2"><?php echo $row['updatetime']; ?></td>
                   </tr>
                    <tr>
                   <td class="tablecolumn1">House Type:</td>
                   <td class="tablecolumn2"><?php echo $row['housetype']; ?></td>
                   </tr>
                    <tr>
                   <td class="tablecolumn1">Width:</td>
                   <td class="tablecolumn2"><?php echo $row['width']; ?></td>
                   </tr>
                    <tr>
                   <td class="tablecolumn1">Height:</td>
                   <td class="tablecolumn2"><?php echo $row['length']; ?></td>
                   </tr>
                    <tr>
                   <td class="tablecolumn1">House No:</td>
                   <td class="tablecolumn2"><?php echo $row['houseno']; ?></td>
                   </tr>
                    <tr>
                   <td class="tablecolumn1">Road:</td>
                   <td class="tablecolumn2"><?php echo $row['road']; ?></td>
                   </tr>
                    <tr><?php 
																
									
									$retTownship=GetTownshipDataBy_TownshipID($row['townshipid']);
									$rowTownship=mysql_fetch_array($retTownship);
									
								?>
                   <td class="tablecolumn1">Township Name:</td>
                   <td class="tablecolumn2"><?php echo $rowTownship['townshipname']; ?></td>
                   </tr>
                    <tr>
                   <td class="tablecolumn1">Description:</td>
                   <td class="tablecolumn2"><?php echo $row['description']; ?></td>
                   </tr>
                    <tr>
                   <td class="tablecolumn1">Price:</td>
                   <td class="tablecolumn2"><?php echo $row['price']; ?></td>
                   </tr>
                    <tr>
                   <td class="tablecolumn1">Want To:</td>
                   <td class="tablecolumn2"><?php echo $row['wantto']; ?></td>
                   </tr>
                    <tr>
                   <td class="tablecolumn1">House Status:</td>
                   <td class="tablecolumn2"><?php echo $row['housestatus']; ?></td>
                   </tr>
                    <tr>
                   <td class="tablecolumn1">Status:</td>
                   <td class="tablecolumn2"><?php echo $row['status']; ?></td>
                   </tr>
                   
                   </table>
       	
			
			 <?php
			}
			else
			{
				?>
                	<center><h1>No result found!</h1></center>
                <?php
			}
		?>
			
					
		
	</div>
                  
                    
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
