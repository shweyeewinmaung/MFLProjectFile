<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_township.php");
require_once("../dal/dal_city.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");
require_once("../library/pager_house.php");

if(isset($_GET['townshipid']) && $_GET['townshipid']!="")
{	
	$townshipid=$_GET['townshipid'];
	//IncreaseView($houseid);
	$ret=GetTownshipDataBy_TownshipID($townshipid);
	$num=mysql_num_rows($ret);
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  
   <style>
   .tablecolumn1
{
	height:40px; text-align:right; font-size:16px;color:#082f44;
}
.tablecolumn2
{
	font-size:16px;color:#082f44;
}


   
   </style> 
</head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>Township Detail</h2>
					</div>
                    <!-- End Box Head -->
                    
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="liststyledesign">
                   <div style="width:700px; height:auto; margin-left:20px; margin-top:15px; ">
                   <?php
			if($num>0)
			{
				$row=mysql_fetch_array($ret);
				?>
               <table width="400">
               <tr>
               <td class="tablecolumn1">
               Township ID :
               </td>
               <td class="tablecolumn2">
                 &nbsp;&nbsp;<?php echo $row['townshipid']; ?>
               </td>
               </tr>
                <tr>
               <td class="tablecolumn1">
               Township Name :
               </td>
               <td class="tablecolumn2">
               &nbsp;&nbsp;<?php echo $row['townshipname']; ?>
               </td>
               </tr>
                <tr>
              
               <td class="tablecolumn1">
              City Name :
               </td>
               <td class="tablecolumn2">
               &nbsp;&nbsp;<?php echo GetCityDataBy_City($row['2']); ?>
               </td>
               </tr>
               </table>
       	
			
			 <?php
			}
			else
			{
				?>
                	<center><h1>No result found!</h1></center>
                <?php
			}
		?>
			
					
		
	</div>
                  
                    
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
