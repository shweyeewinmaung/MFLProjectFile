<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../dal/dal_news.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");
require_once("../library/pager_house.php");

/*$pageSize=10;



if(isset($_GET['page']))
{
	$currentPageIndex=Clean($_GET['page']);
}
else
{
	$currentPageIndex=1;
}
$objPager=new pager($pageSize,$currentPageIndex);

/*$sql=$objPager->SearchData_GetAllCar();
$ret=$objPager->Search_Data($sql);
$num=mysql_num_rows($ret);*/
$ret=GetNewsDataByNews($newsid);
$num=mysql_num_rows($ret);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  
    <style>
    .d1{ text-align:right;}
.d2{margin-left:3px;}
    </style>
</head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box" style="height:auto;">
					<!-- Box Head -->
					<!--<div class="box-head">
						<h2>House List</h2>
					</div>-->
                    <!-- End Box Head -->
                    <!-- Sidebar -->
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="liststyledesign">
                   <div style="width:700px; height:auto; margin-left:20px; ">
                    
                   <form method="post">
        <table style="width:700px; overflow:hidden; float:left;">	
			<th colspan="6" style="font-size:18px; color:#104c6b; padding-top:20px;">Search By</th>
            <tr>
            	<td colspan="6"><br /></td>
            </tr>
            <tr style="font:bold; color:#104c6b; text-align:center;">
            	<td>Brand</td>
                <td>Car Name</td>
                <td>Car Type</td>
                <td>Model</td>
                <td>Price</td>
            </tr>
            <tr>
            	<td width="18%;"><select name="Brand" style="width:80%; ">
                	<option></option>
                	
                </select></td>
                
                <td width="18%;"><input type="text" name="CarName" style="width:80%;height:30px;" /></td>
                
                <td width="18%;"><select name="CarType" style="width:80%;">
                	<option></option>
                	<option>Sedan</option>
                    <option>Hatchback</option>
                    <option>Stationwagon</option>
                    <option>Sports</option>
                    <option>SUV</option>
                    <option>Truck</option>
                    <option>Bus</option>
                    <option>Others</option>
                    <option>MPV(Minivan)</option>
                </select></td>
                
                <td width="18%;"><input type="text" name="Model" style="width:80%;  height:30px;" /></td>
                
                <td width="18%;"><select name="Price" style="width:80%;">
                	<option>0 to 50L</option>
                    <option>50L to 75L</option>
                    <option>75L to 100L</option>
                    <option>100L to 150L</option>
                    <option>150L to 200L</option>
                    <option>200L to 300L</option>
                    <option>300L to 400L</option>
                    <option>400L to 500L</option>
                    <option>500L to 600L</option>
                    <option>Over 600L</option>
                </select></td>
                
                <td ><input type="submit" name="btnSearch" value="Search" class="btnstyle"/></td>
            </tr>
        </table>
        <br /><br />
        </form>
        <br />
    
       				 <div style="margin:60px auto;margin-top: 100px;">
      					<?php while($row=mysql_fetch_array($ret))
						{ ?>
                    	
                        <div style="margin:15px auto; padding:10px; border:1px solid #104c6b; border-radius:10px;">
                           <table>
                            	<tr>
                                	<td colspan="7" style=" font-size:18px; padding-bottom:10px;"><?php echo $row['newsid']; ?></td>
                            
                                <tr>
                                    <td rowspan="5" width="20%"><img src="../images/girl-hugging-the-globe.jpg" width="120px;" height="120px;"  style="border:2px solid#000;margin-left:3px;" /></td>
                                    <td width="20%" class="d1">NewsID : </td>
                                     <td width="20%" class="d2"><?php echo $row['newsid']; ?></td>
                                    <td width="20%" class="d1">Title : </td>
                                     <td width="20%" class="d2"><?php echo $row['title']; ?></td>
                                   
                                    
                                </tr>
                                <tr>
                                    <td class="d1">Description : </td>
                                    <td  class="d2"><?php echo $row['description']; ?></td>
                                    <td class="d1">News Date : </td>
                                    <td  class="d2"><?php echo $row['newsdate']; ?></td>
                                    
                                </tr>
                                <tr>
                                    <td class="d1">News Time : </td>
                                    <td class="d2"><?php echo $row['newstime']; ?></td>
                                    <td class="d1">status :</td>
                                    <td class="d2"> <?php echo $row['status']; ?></td>
                                    
                                </tr>
                                 <tr>
                                    <td class="d1">User Name : </td>
                                    <td class="d2"><?php echo GetUserNameByUserID($row['6']); ?></td>
                                    <td class="d1"></td>
                                    <td class="d2"></td>
                                    
                                </tr>
                                
                                <tr> <td colspan="5" style="text-align:right; margin-right:20px; ">
                                 <a href="newsdetail.php?newsid=<?php echo $row['newsid']; ?>" target="_blank">
    Detail</a> 
   &nbsp; &nbsp;
                                 <a href="newsupdate.php?newsid=<?php echo $row['newsid']; ?>">
    <img src="../images/wrench-screwdriver.png"  width="20" height="20"/></a> 
   &nbsp; &nbsp;
    <a href="newsdelete.php?newsid=<?php echo $row['newsid']; ?>">
    <img src="../images/cross-script.png" width="20" height="20" /></a></td></tr>
                            </table>
                           
                        </div>
                   <?php }?>
				</div>
				
            
       
				
				
				
				
				
				
			
							
						
			
			
			
			
			
					
		
	</div>
                  
                    
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
