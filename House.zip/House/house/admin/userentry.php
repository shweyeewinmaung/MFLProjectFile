<?php
session_start();

require_once("../library/connection.php");
require_once("../dal/dal_user.php");
require_once("../library/autoidfunction.php");
require_once("../library/globalfunction.php");

if (isset($_POST['submit']) )
{	
	//$UserID=AutoID('tbl_user','UserID','Usr-',6);
	$userid=AutoID('tbl_user','userid','Usr-',6);
	$fullname=Clean($_POST['txtfullname']);
	$dob=Clean($_POST['txtdob']);
	$gender=Clean($_POST['txtgender']);
	$phone=Clean($_POST['txtphone']);
	$email=Clean($_POST['txtemail']);
	$username=Clean($_POST['txtusername']);
	$password=Clean($_POST['txtpassword']);
	$usertype=Clean($_POST['txtusertype']);
	$role=Clean($_POST['txtrole']);
	
	
	
	InsertUser($userid,$fullname,$dob,$gender,$phone,$email,$username,$password,$usertype,$role);
	$msg="Successfully User Save";

}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <style>
 
 table.calendar input {
    
    width: 40px;
}
 </style>
    
</head>
<body>


  <?php
require_once("../template/header.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2>User Entry</h2>
					</div>
                    <!-- End Box Head -->
                    <!-- Sidebar -->
                     <?php
require_once("../template/sidebar.php");
?>

                    
                    <!-- End Sidebar --> 
                    
                    <!-------Content Box Start------------->
                    <div id="entrystyle">
                    <form name="userform" method="post" action="" class="formstyle" >
  <font style="color:red;"> <?php echo "<tr><th colspan='2'>$msg</th></tr>" ?></font>
  <table width="400" border="0">
    <tr>
      <td colspan="2"  height="40"></td>
    </tr>
    <!--<tr>
            	<td>User ID</td>
                <td><input type="text" name="txtuserid" value="<!--?php echo AutoID('tbl_user','userid','Usr-',6); ?>" required /></td>
            </tr>-->
     <tr>
      <td height="40" style="text-align:right;">Full Name:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtfullname"></label>
        <input name="txtfullname" type="text" id="txtfullname" size="48" style="height:27px;"  /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">DOB:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtdob"></label>
      
        <input name="txtdob" type="text" size="48" id="txtdob" maxlength="11" style="height:27px;"  value="<?php echo date("d-M-Y")?>" onfocus="showCalender(calender,this)"/>
       
       </td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Gender:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtgender"></label>
        <input type="radio" name="txtgender" value="male" checked="checked" style="width:20px; "><font style="color:#333;">Male</font>
		<input type="radio" name="txtgender" value="female"  style="width:20px;font-size:14px;"><font style="color:#333;">Female</font>
        </td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Phone:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtphone"></label>
        <input name="txtphone" type="text" id="txtphone" size="48" style="height:27px;"  /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Email:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtemail"></label>
        <input name="txtemail" type="text" id="txtemail" size="48" style="height:27px;"  /></td>
    </tr>
     
     <tr>
      <td height="40" style="text-align:right;">Username:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtusername"></label>
        <input name="txtusername" type="text" id="txtusername" size="48" style="height:27px;"  /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">Password:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtpassword"></label>
        <input name="txtpassword" type="password" id="txtpassword" size="48" style="height:27px;"  /></td>
    </tr>
     <tr>
      <td height="40" style="text-align:right;">User Type:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtusertype"></label>
        <input name="txtusertype" type="text" id="txtusertype" size="48" style="height:27px;"  /></td>
    </tr>
    <tr>
      <td height="40" style="text-align:right;">Role:</td>
      <td>&nbsp;&nbsp;<label for="obj"></label>
        <label for="txtrole"></label>
        <input name="txtrole" type="text" id="txtrole" size="48" style="height:27px;"  /></td>
    </tr>
    
    
	
    
    
   
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;&nbsp;
      <input name="submit" type="submit" id="submit"  value="Save" class="btnstyle">
      <input name="Reset" type="reset" id="button" value="Cancel" class="btnstyle"><br><br>
      <!--<input type="submit" name="submit" id="submit" value="" class="entry" onClick="return Validate()">
      <input type="reset" name="Reset" id="button" value="" class="reset">--></td>
    </tr>
  </table>
</form>
                    
                    
                    </div>
                   
                

				</div>
				<!-- End Box -->
                

			</div>
			<!-- End Content -->
			
			
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("../template/footer.php");
?>	


          
</body>
</html>
