
 <!-- Sidebar -->
                    <div id="sidebar">
                    <!-----SidebarFirst Start-------->
                    <div id="sidebarfirst">
                    <p class="sidebarhead">News</p>
                    
                   <p class="sidebarfont"> ghe;kahepoiwqcn3orynqeowh bhlkjaher jheuiaryhewkl cyduisarey 
                   
					</p>
                    </div>
                    
                    <p class="clear">-----------------------------------</p> 
                    <!-----Sidebar First End----->
                    
                     <!-----Sidebar Second Start-------->
                    <div id="sidebarsecond">
                    <p class="sidebarhead">hdioparek fna</p>
                    
                   <p class="sidebarfont"> ghe;kahepoiwqcn3orynqeowh bhlkjaher jheuiaryhewkl cyduisarey 
                   
					</p>
                    </div>
                    
                    <p class="clear">-----------------------------------</p> 
                    <!-----Sidebar Second End----->
                     <!-----Sidebar Third Start-------->
                    <div id="sidebarthird">
                    <p class="sidebarhead">hdioparek fna</p>
                    
                   <p class="sidebarfont" style="height:160px;"> ghe;kahepoiwqcn3orynqeowh bhlkjaher jheuiaryhewkl cyduisarey 
                   
					</p>
                    <p class="clear">-----------------------------------</p> 
                     <p class="sidebarfont"> ghe;kahepoiwqcn3orynqeowh bhlkjaher jheuiaryhewkl cyduisarey 
                   
					</p>
                    </div>
                     
                   
					</p>
                    <p class="clear">-----------------------------------</p> 
                    <!-----Sidebar Third End----->
                    </div>
                    
                    <!-- End Sidebar --> 
