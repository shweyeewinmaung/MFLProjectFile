<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="Shortcut Icon" href="file:///D|/xampp/htdocs/images/uico.png" />
<link rel='shortcut icon' href="../images/little-girl-hugging-the-globe.jpg" type='image/x-icon' />

	<title>House</title>

<link rel="stylesheet" href="../css/admin_style.css"    type="text/css" media="all" />
    <link type="text/css" href="../css/menu.css" rel="stylesheet" />
    <link rel="stylesheet" href="../css/tabstyles.css" />    
   <link rel="stylesheet" href="../css/style.css" />  
<div id="header">
	<div class="shell">
		<!-- Logo + Top Nav -->
		<div id="top">
			<h1><a href="#">House</a></h1>
			<div id="top-navigation" >
				Welcome: <strong></strong> 
				
			
			</div>
		</div>
		<!-- End Logo + Top Nav -->

<!-- Main Nav -->
		<div id="p_menu">	
       	 <div id="menu">
    		<ul class="menu">
    				<li><a href="../index.php" class="parent"><span>Home</span></a></li>
      			 	<li><a href="#" class="parent"><span>Entry</span></a>
      				 <div>
       					<ul>
        					 <li><a href="userentry.php"><span>User Entry</span></a></li>
          					 <li><a href="newsentry.php"><span>News Entry</span></a></li>
           		 			 <li><a href="houseentry.php"><span>House Entry</span></a></li>
          					 <li><a href="townshipentry.php"><span>Township Entry</span></a></li>
          	 	 			 <li><a href="countryentry.php"><span>Country Entry</span></a></li>
           	 	 			 <li><a href="cityentry.php"><span>City Entry</span></a></li>
         			  </ul>
         			</div>
 				  </li>
				  <li><a href="#" class="parent"><span>List</span></a>
      			 	 <div>
                 		<ul>
       						 <li><a href="userlist.php"><span>User List</span></a></li>
          					 <li><a href="newslist.php"><span>News List</span></a></li>
           		 			 <li><a href="houselist.php"><span>House List</span></a></li>
          					 <li><a href="townshiplist.php"><span>Township List</span></a></li>
          	 	 			 <li><a href="countrylist.php"><span>Country List</span></a></li>
           	 	 			 <li><a href="citylist.php"><span>City List</span></a></li>
         
      				   </ul>
                 	</div>
 				   </li>        			
     			 <li class='last'><a href="../LogOut.php"><span>LOGOUT</span></a></li>
			
	
   	 </ul>
	
</div></div>
		</div>
		<!-- End Main Nav -->
	</div>
