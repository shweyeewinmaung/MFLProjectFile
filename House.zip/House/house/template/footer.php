<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>House</title>
<link rel="stylesheet" href="css/admin_style.css"    type="text/css" media="all" />
    <link type="text/css" href="css/menu.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/tabstyles.css" />    
   <link rel="stylesheet" href="css/style.css" />    
  
</head>

<body>
<div id='footer'>
<div class='shell'>
<span class='left'>&copy; 2014 - Administration</span></div>
</div>
</body>
</html>