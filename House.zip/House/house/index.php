<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="Shortcut Icon" href="../images/uico.png" />
<link rel='shortcut icon' href="images/little-girl-hugging-the-globe.jpg" type='image/x-icon' />

	
	
  <link rel="stylesheet" type="text/css" href="css/coin-slider.css" />
<!--<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/droid_sans_400-droid_sans_700.font.js"></script>-->
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
    
</head>
<body>


  <?php
require_once("template/headerindex.php");
?>



</div>
<div id="container">
	<div class="shell">
		
		<!-- Main -->
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<!-- Content -->
		  <div id="content1">
				<!-- Box -->
				<div class="box" style="height:800px;">
                
                
                
                <div class="slider">
        <div id="coin-slider"> <a href="#">
        <img src="images/little-girl-blowing-wind-mill.jpg" width="960" height="300" alt="" />
        <!--<span>Aliquam fermentum arcu et velit fringillaonec ut felis ipsum. Maecenas lacinia orci cursuslacus sodales in posuere risus gravida. Lorem ipsum dolor sit amet, consectetng ipsum, in euismod velit fringilla vitae.</span>--></a> 
        <a href="#"><img src="images/map-in-grass.jpg" width="960" height="300" alt="" />
        <!--<span>Tasellus ornare adipiscing ipsum, in euismod velit fringilla vitae. Aliquam fermentum arcu et velit fringilla vitae consequat lectus tempus. Donec at ante nec sem bibendum porttitor. Mauris eu accumsan justo. Suspendisse lacus ante.</span>--></a> 
        <a href="#"><img src="images/girl-hugging-the-globe.jpg" width="960" height="300" alt="" />
        <!--<span>Lorem ipsum dolor sit amet, consectetng ipsum, in euismod velit fringilla vitae. Aliquam fermentum arcu et velit fringillaonec ut felis ipsum. Maecenas lacinia orci cursuslacus sodales in posuere risus gravida.</span>--></a> </div>
        <div class="clr"></div>
      </div>
                
                
					<!-- Box Head -->
					<!--<div class="box-head">
						<h2>Title</h2>
					</div>
					<!-- End Box Head -->
                    <!-------Content Box Start------------->
                    <ul class="ulstyle">
                    <li class="lileft"> 
                    <img src="images/little-girl-blowing-wind-mill.jpg" alt="" width="200" height="150" class="imgstyle" />
                    <p class="lihead">
                    dnhlkaejroaiu4rjkdhiofpae
                    </p>
                    <p class="lifont">
                    fdajhel;krjaear efa safewr  ernasdfklah fdajhel;krjaear efa safewr  ernasdfklah fdajhel;krjaear efa safewr  ernasdfklah
                    </p>
                  <button  class="readmore" >Read More</button>
                    </li>
                    <li class="limiddle"> 
                    <img src="images/map-in-grass.jpg" alt="" width="200" height="150" class="imgstyle" />
                    <p class="lihead">
                    dnhlkaejroaiu4rjkdhiofpae
                    </p>
                    <p class="lifont">
                    fdajhel;krjaear efa safewr  ernasdfklah fdajhel;krjaear efa safewr  ernasdfklah fdajhel;krjaear efa safewr  ernasdfklah
                    </p>
                  <button  class="readmore" >Read More</button>
                    </li>
                    <li class="liright"><img src="images/girl-hugging-the-globe.jpg" alt="" width="200" height="150" class="imgstyle"/>
                    <p class="lihead">
                    dnhlkaejroaiu4rjkdhiofpae
                    </p>
                    <p class="lifont">
                    fdajhel;krjaear efa safewr  ernasdfklah fdajhel;krjaear efa safewr  ernasdfklah fdajhel;krjaear efa safewr  ernasdfklah
                    </p>
                  <button  class="readmore" >Read More</button>
                    </li>
                    
                    </ul>
                   
                   <!-- <div style="width:300px; height:200px; margin-left:10px; background-color:#CCC; float:left;">
                    <img src="images/little-girl-blowing-wind-mill.jpg" alt="" width="200" height="150" style=" margin-left:40px; margin-top:20px; border:2px solid#000;"/>
                    
                    </div>
                     <div style="width:300px; height:200px; margin-left:10px; background-color:#CCC; ">
                    <img src="images/map-in-grass.jpg" alt="" width="200" height="150" style=" margin-left:40px; margin-top:20px; border:2px solid#000;"/>
                    
                    </div>
                     <div style="width:300px; height:200px; margin-left:10px; background-color:#CCC; float:right;">
                    <img src="images/girl-hugging-the-globe.jpg" alt="" width="200" height="150" style=" margin-left:40px; margin-top:20px; border:2px solid#000;"/>
                    
                    </div>
                  <!--  
                    <table>
                    <tr>
                    <td><img src="images/little-girl-blowing-wind-mill.jpg" alt="" width="200" height="150" style="border: 3px solid #FFF;"/></td>
                    <td><img src="images/girl-hugging-the-globe.jpg" alt=""  width="200" height="150" style="border: 3px solid #FFF;" /></td>
                    <td><img src="images/map-in-grass.jpg" alt=""   width="200" height="150" style="border: 3px solid #FFF;"/></td>
                    
                    </tr>
                    <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    
                    </tr>
                    
                    
                    
                    </table>-->
                    <!-------------Content Box End---------------------->

				</div>
				<!-- End Box -->

			</div>
			<!-- End Content -->
			
			<!-- Sidebar --><!-- End Sidebar -->
			
		  <div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<?php
require_once("template/footerindex.php");
?>	


          
</body>
</html>
