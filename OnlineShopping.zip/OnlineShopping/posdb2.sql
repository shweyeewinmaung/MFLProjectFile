-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 11, 2012 at 07:40 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `posdb2`
--

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE IF NOT EXISTS `checkout` (
  `CheckOutID` varchar(15) NOT NULL,
  `CheckOutDate` date NOT NULL,
  `MemberID` varchar(15) NOT NULL,
  `TotalAmount` decimal(6,2) NOT NULL,
  PRIMARY KEY (`CheckOutID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `checkout`
--

INSERT INTO `checkout` (`CheckOutID`, `CheckOutDate`, `MemberID`, `TotalAmount`) VALUES
('012012000001', '2012-01-10', 'MEM000001', '299.99'),
('012012000002', '2012-01-11', 'MEM000001', '299.99');

-- --------------------------------------------------------

--
-- Table structure for table `checkoutdetail`
--

CREATE TABLE IF NOT EXISTS `checkoutdetail` (
  `CheckOutID` varchar(15) NOT NULL,
  `ItemID` varchar(15) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` decimal(6,2) NOT NULL,
  PRIMARY KEY (`CheckOutID`,`ItemID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `checkoutdetail`
--

INSERT INTO `checkoutdetail` (`CheckOutID`, `ItemID`, `Quantity`, `Price`) VALUES
('012012000001', 'ITM000001', 1, '299.99'),
('012012000002', 'ITM000001', 1, '299.99');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `ItemID` varchar(15) NOT NULL,
  `ItemName` varchar(50) NOT NULL,
  `ItemTypeID` varchar(15) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` decimal(6,2) NOT NULL,
  `ItemImage` varchar(255) NOT NULL,
  PRIMARY KEY (`ItemID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`ItemID`, `ItemName`, `ItemTypeID`, `Quantity`, `Price`, `ItemImage`) VALUES
('ITM000001', 'Lenovo Desktop', 'ITY000002', 9, '299.99', 'ItemImage/ITM000001_best-desk-top-computers.jpg'),
('ITM000002', 'Dell Laptop', 'ITY000001', 12, '699.00', 'ItemImage/ITM000002_dell_studio_laptop.jpg'),
('ITM000005', 'Apple iPhone 4GS', 'ITY000003', 30, '499.00', 'ItemImage/ITM000005_iphone5.jpg'),
('ITM000006', 'Microsoft Mouse', 'ITY000005', 3, '29.99', 'ItemImage/ITM000006_6a0120a85dcdae970b012877701f31970c.jpg'),
('ITM000004', 'Acer Desktop', 'ITY000002', 20, '199.99', 'ItemImage/ITM000004_acer-aspire-l3600-a10.jpg'),
('ITM000003', 'Acer Laptop', 'ITY000001', 7, '499.99', 'ItemImage/ITM000003_acer-laptop-computer.jpg'),
('ITM000007', 'Dell XPS Laptop', 'ITY000001', 5, '999.99', 'ItemImage/ITM000007_dell3-start-up-error.jpg'),
('ITM000008', 'iPad2', 'ITY000004', 30, '499.00', 'ItemImage/ITM000008_ipad.png'),
('ITM000009', 'Acer Monitor', 'ITY000008', 5, '249.00', 'ItemImage/ITM000009_98BB69E6-EB00-4F05-BE48-FE288F885A9C.jpg'),
('ITM000010', 'iPhone 3GS', 'ITY000003', 5, '399.00', 'ItemImage/ITM000010_apple_iphone_2.jpg'),
('ITM000011', 'Prolink Desktop', 'ITY000002', 7, '350.00', 'ItemImage/ITM000011_desktop-computers.jpg'),
('ITM000012', 'Prolink Mouse', 'ITY000005', 7, '5.99', 'ItemImage/ITM000012_mouse.jpg'),
('ITM000013', 'ssa', 'ITY000002', 30, '4.00', 'ItemImage/ITM000013_3060000000055351.JPG');

-- --------------------------------------------------------

--
-- Table structure for table `itemtype`
--

CREATE TABLE IF NOT EXISTS `itemtype` (
  `ItemTypeID` varchar(15) NOT NULL,
  `ItemTypeName` varchar(50) NOT NULL,
  PRIMARY KEY (`ItemTypeID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `itemtype`
--

INSERT INTO `itemtype` (`ItemTypeID`, `ItemTypeName`) VALUES
('ITY000001', 'Laptop'),
('ITY000002', 'Desktop'),
('ITY000003', 'iPhone'),
('ITY000004', 'iPad'),
('ITY000005', 'Mouse'),
('ITY000006', 'Wireless Router'),
('ITY000007', 'Laptop Cooling Fan'),
('ITY000008', 'LCD Monitor'),
('ITY000009', 'UPS'),
('ITY000010', 'External Hard Drive');

-- --------------------------------------------------------

--
-- Table structure for table `item_view`
--

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `posdb2`.`item_view` AS select `posdb2`.`item`.`ItemID` AS `ItemID`,`posdb2`.`item`.`ItemName` AS `ItemName`,`posdb2`.`item`.`ItemTypeID` AS `ItemTypeID`,`posdb2`.`itemtype`.`ItemTypeName` AS `ItemTypeName`,`posdb2`.`item`.`Quantity` AS `Quantity`,`posdb2`.`item`.`Price` AS `Price`,`posdb2`.`item`.`ItemImage` AS `ItemImage` from (`posdb2`.`item` join `posdb2`.`itemtype` on((`posdb2`.`item`.`ItemTypeID` = `posdb2`.`itemtype`.`ItemTypeID`))) order by `posdb2`.`item`.`ItemID`;

--
-- Dumping data for table `item_view`
--


CREATE TABLE IF NOT EXISTS `member` (
  `MemberID` varchar(15) NOT NULL,
  `MemberName` varchar(50) NOT NULL,
  `Gender` char(1) NOT NULL,
  `DOB` date NOT NULL,
  `EMail` varchar(30) NOT NULL,
  PRIMARY KEY (`MemberID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`MemberID`, `MemberName`, `Gender`, `DOB`, `EMail`) VALUES
('MEM000001', 'Mg Mg', 'M', '1980-01-01', 'mgmg@gmail.com'),
('MEM000002', 'Aye Aye', 'M', '1985-12-03', 'ayeaye@gmail.com'),
('MEM000003', 'Thiri', 'F', '1992-01-03', 'thiri@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `UserID` varchar(15) NOT NULL,
  `UserName` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Role` varchar(10) NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `UserName`, `Password`, `Role`) VALUES
('MEM000001', 'mgmg', 'mgmg', 'member'),
('MEM000002', 'ayeaye', 'ayeaye', 'member'),
('MEM000003', 'thiri', 'thiri', 'member'),
('ADM000001', 'admin', 'admin', 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
