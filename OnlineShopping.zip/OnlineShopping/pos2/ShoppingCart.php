<?php
	session_start();	//starting "Session"

	require_once("includes/db.php");		
	require_once("includes/function.php");
	require_once("includes/shoppingCartFunction.php");
	require_once("includes/logInFunction.php");

	/********************************************************/
	$objLogIn=new LogIn();
	
	//Checking logged in as "member"?
	if ($objLogIn->isMemberLogIn()==false)
		header("Location:LogIn.php");
	/********************************************************/
		
	$shoppingCart=new ShoppingCart();
	
	if($_GET['Action']=="Add")
	{
		$itemID=$_GET['ItemID'];
		//Function Call to Insert "Item" into "ShoppingCart"		
		$statusOK= $shoppingCart->Insert($itemID);
	}
	else if ($_GET['Action']=="Remove")
	{
		$itemID=$_GET['ItemID'];
		//Function Call to Remove "Item" from "ShoppingCart"
		$shoppingCart->Remove($itemID);
	}
	else if ($_GET['Action']=="Clear")
	{
		//Function Call to Clear "ShoppingCart"
		$shoppingCart->Clear();
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>My Online Store</title>
    <link href="CSS/StyleSheet.css" rel="stylesheet" type="text/css" />
</head>
    
<body>

    <?php include_once("header.php"); ?>
    <div id="content">
        <?php include_once("left.php"); ?>
        <div id="content-right">
        
        	<br /><div class="form-Header">Shopping Cart</div><br/>

            <table class="display">                
				<?php
					$size=count($_SESSION['ShoppingCart']);
					
					$totalAmount=0;
					
					if ($size==0)
					{
				?>
                	<td style="width:600px;text-align:center;">
						<h3>Your Shopping Cart is empty.</h3>
                    </td>
                    <?php
					}//end of "if"

					for($i=0;$i<$size;$i++)
					{			
						$itemID=$_SESSION['ShoppingCart'][$i]['ItemID'];
						$quantity=$_SESSION['ShoppingCart'][$i]['Quantity'];
						
						$sql="SELECT * FROM Item_View WHERE ItemID='$itemID'";	
						$result=mysql_query($sql) or die(mysql_error());
						$row=mysql_fetch_array($result);
						
						$amount=$quantity*$row['Price'];
						$totalAmount+=$amount;
						
						if ($i%2==0)
							echo "<tr>";
						else
							echo "<tr class='alt'>";
                ?>
                    <td>
                        <img src="<?php echo $row['ItemImage']; ?>" width="100px" height="100px"/>
                    </td>
                    <td>
                        <?php include("SubShoppingCart.php"); ?>
                    </td>
                  </tr>
            <?php             
                    }//end of "for" loop
            ?>
            	<tr>
                	<td colspan="2" align="right">
	                    <a href="CheckOut.php">Check Out</a>&nbsp;
                    	<a href="ShoppingCart.php?Action=Clear">Clear</a>&nbsp;
                    	<strong>Total Amount : $<?php echo $totalAmount; ?></strong>
                    </td>
                </tr>
            </table>
            
            <br/>            
    
        </div>
    </div>
    <?php include_once("footer.php"); ?>
    
</body>
    
</html>

