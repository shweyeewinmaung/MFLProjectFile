<div id="banner">
	<div style="position:absolute;width:1000px;top:95px;
    text-align:right;font-weight:bold;color:#FFFFFF;">
    
    <?php
	
	if (isset($_SESSION['user']))
	{
		echo $_SESSION['user']['UserName'];
		echo "&nbsp;";
		echo "(" . $_SESSION['user']['Role'] .")";
		echo "&nbsp;";
		echo "<a style='color:#FFFFFF;' href='LogOut.php'>Log Out</a>";
	}
	else
	{
		echo "<a style='color:#FFFFFF;' href='LogIn.php'>Log In</a>";
	}
	?>
    
    </div>
</div>

