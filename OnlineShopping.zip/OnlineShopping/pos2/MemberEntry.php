<?php
	session_start();
	
    require_once("includes/db.php");
	require_once("includes/function.php");
	
	if (isset($_POST['submitted']))
	{		
		$error=false;
		/*********************************************************************/
		//Filling Data
		$memberID=$_POST['memberID'];
		$memberName=$_POST['memberName'];
		$gender=$_POST['gender'];
		$dOB=date("Y-m-d",strtotime($_POST['dOB']));
		$eMail=$_POST['eMail'];
		$userName=$_POST['userName'];
		$password=$_POST['password'];						
		/*********************************************************************/
		//Member Table Insert
		$memberInsert_sql="INSERT INTO " .
			"Member(MemberID,MemberName,Gender,DOB,EMail) ".
			"VALUES('$memberID','$memberName','$gender','$dOB','$eMail')";
							
		mysql_query($memberInsert_sql) or die(mysql_error());
		/*********************************************************************/
		//User Table Insert
		$userInsert_sql="INSERT INTO " .
			"User(UserID,UserName,Password,Role) ".
			"VALUES('$memberID','$userName','$password','member')";			
															
		mysql_query($userInsert_sql) or die(mysql_error());
		/*********************************************************************/					
		$message="Member is successfully saved with MemberID : " . $memberID;
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>My Online Store</title>
    <link href="CSS/StyleSheet.css" rel="stylesheet" type="text/css" />    
	<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"></script>
    <script type="text/javascript" src="JavaScript/jquery.js"></script>
	<script type="text/javascript" src="JavaScript/jquery.validate.js"></script>   
</head>
    
<body>

    <script type="text/javascript">
	
	$(function() 
	{
		// validate contact form on keyup and submit
		$("#memberEntry").validate(
		{
		//set the rules for the field names
			rules: {
				memberName: 
				{
					required: true
				},
				eMail: 
				{
					required: true,
					email: true
				},
				userName: 
				{
					required: true
				},
				password: 
				{
					required: true
				},
				confirm_Password: 
				{
					required:true,
					equalTo: "#password"
				},
			},
			//set messages to appear inline
			messages: 
			{
				memberName: "Please enter Member name.",
				eMail: 
					{ 
						required: "Please enter a E-Mail address.",
						email: "Please enter a valid E-Mail address."
					},
				userName: "Please enter user name.",
				password: "Please enter a password.",
				confirm_Password: 
					{
						required: "Please enter a confirm password.",
						equalTo: "Password and Confirm Password not match."
					}
			}
		});
	});
	</script>


    <?php include_once("header.php"); ?>
    <div id="content">
        <?php include_once("left.php"); ?>
        <div id="content-right">
            <br/>
			<form name="memberEntry" id="memberEntry" action="MemberEntry.php" method="post">
                <?php
				if (!empty($message))
				{
					if ($error)
						echo "<div class='error-Message'>$message</div>";
					else
						echo "<div class='success-Message'>$message</div>";
				}
				?>    
                <table class="default">
                	<tr>
                        <th colspan="2">Member Entry</th>
                    </tr>
                    <tr>
                        <td><div>Member ID :</div></td>
                        <td>
                            <input name="memberID" type="text" id="memberID"
                                size="30" maxlength="15" readonly="true" 
                                value="<?php echo AutoID('Member','MemberID','MEM',6) ?>"/>
                        </td>
                    </tr>                        
                    <tr>
                        <td><div>Member Name :</div></td>
                        <td>
                            <input name="memberName" type="text" id="memberName"
                                size="50" maxlength="50" />
                        </td>
                    </tr>
                    <tr>
                        <td><div>Gender :</div></td>
                        <td>                                
                            <p>
                              <label>
                                <input type="radio" name="gender" 
                                    value="M" id="gender_0" checked="true"/>Male<label>
                                <input type="radio" name="gender" 
                                    value="F" id="gender_1" />Female</label>                                  
                            </p>
                        </td>                        
                    </tr>    
                    <tr>
                        <td><div>DOB :</div></td>
                        <td>
                            <input name="dOB" type="text" size="30" id="dOB"
                                maxlength="11" value="<?php echo date("d-M-Y")?>" 
                                    onfocus="showCalender(calender,this)"/>
                        </td>
                    </tr>
                    <tr>
                        <td><div>EMail :</div></td>
                        <td>
                            <input name="eMail" type="text" id="eMail"
                                size="50" maxlength="50" />
                        </td>
                    </tr>
                    <tr>
                        <td><div>User Name :</div></td>
                        <td>
                            <input name="userName" type="text" id="userName"
                            size="30" maxlength="15" />
                        </td>
                    </tr>  
                    <tr>
                        <td><div>Password :</div></td>
                        <td>
                            <input name="password" type="password" id="password"
                            size="30" maxlength="15" />
                        </td>
                    </tr>  
                    <tr>
                        <td><div>Confirm Password :</div></td>
                        <td>
                            <input name="confirm_Password" type="password"
                            	id="confirm_Password"  size="30" maxlength="15" />
                        </td>
                    </tr>   
                    <tr>
                        <td></td>
                        <td>
                            <input name="submitted" type="submit" value="Save" />
                            <input name="reset" type="reset" value="Clear" />
                        </td>
                    </tr>   
                </table>                           
			</form>        
        </div>
    </div>
    <?php include_once("footer.php"); ?>
    
</body>
    
</html>

