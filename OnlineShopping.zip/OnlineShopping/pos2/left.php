<div id="content-left">
    <ul id="menu">
        <li><a href="index.php"><div>Home</div></a></li>
        <li><a href="login.php"><div>Log In</div></a></li>  
        <li><a href="MemberEntry.php"><div>Member Entry</div></a></li>
        <li><a href="MemberDisplay.php"><div>Member Display</div></a></li>
        <li><a href="ItemEntry.php"><div>Item Entry</div></a></li>
        <li><a href="ItemDisplay.php"><div>Item Display</div></a></li>
        <li><a href="ShoppingCart.php"><div>Shopping Cart</div></a></li>
        <li><a href="CheckOut.php"><div>Check Out</div></a></li>
    </ul>
</div>

