<table class="sub-display">
    <tr>
        <td><div>Item ID :</div></td>
        <td><?php echo $itemID; ?></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td><div>Item Name :</div></td>
        <td><?php echo $row['ItemName']; ?></td>
        <td><div>Item Type :</div></td>
        <td><?php echo $row['ItemTypeName']; ?></td>
    </tr>
    <tr>
        <td><div>Quantity :</div></td>
        <td><?php echo $quantity; ?></td>
        <td><div>Price :</div></td>
        <td>$<?php echo $row['Price']; ?></td>
    </tr>
    <tr>
        <td><div>Amount</div></td>
        <td>$<?php echo $amount; ?></td>
        <td colspan="2" align="right">                                    
            <a href="ShoppingCart.php?ItemID=
			<?php echo $itemID ?>&Action=Remove">Remove</a>
        </td>                                
    </tr>
</table>