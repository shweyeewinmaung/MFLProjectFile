<?php
	session_start();

    require_once("includes/db.php");
	require_once("includes/function.php");
	require_once("includes/pager.php");
	require_once("includes/logInFunction.php");
	/********************************************************************/			
	//Page Size
	$pageSize=5;	

	if(isset($_GET['page']))
		$currentPageIndex=$_GET['page'];
	else
		//by default we show first page
		$currentPageIndex=1;				
	/********************************************************************/	
	$searchBy="";
	$searchKey="";
	
	if (isset($_GET['searchKey']))
		$searchBy=$_GET['searchBy'];
	
	if (isset($_GET['searchKey']))
		$searchKey=$_GET['searchKey'];	
	/********************************************************************/						
	$objPager=new pager($pageSize,$currentPageIndex,$searchBy,$searchKey);
	/********************************************************************/	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>My Online Store</title>
    <link href="CSS/StyleSheet.css" rel="stylesheet" type="text/css" />
</head>
    
<body>

    <?php include_once("header.php"); ?>
    <div id="content">
        <?php include_once("left.php"); ?>
        <div id="content-right">            
        
        	<br/><div class="form-Header">Item Display</div>
                        
			<form name="itemSearch" id="itemSearch" 
            	action="ItemDisplay.php" method="get">
                
          		<div class="search">
                	<p>
                    	<select name="searchBy" id="searchBy">
                            <option value="ItemID" selected="true">ItemID</option>
                            <option value="ItemName">Item Name</option>
                            <option value="ItemTypeName">Item Type</option>
                        </select>
                        <input name="searchKey" type="text" id="searchKey"
                            size="30"/>
                            <input name="search" type="submit" value="Search" />
                        <input name="showAll" type="submit" value="Show All" />
					</p>
                </div>

			</form>

			<table class="display">
 			<?php
				$result=$objPager->Get_Data("Item_View","ItemID");
				$numOfRows=mysql_num_rows($result);
				
				for($i=0;$i<$numOfRows;$i++)
				{
					$row=mysql_fetch_array($result); 
					$itemID=$row['ItemID'];
								
					if ($i%2==0)
						echo "<tr>";
					else							
						echo "<tr class='alt'>";						
			?>                          	  		
                	<td>
                    	<img src="<?php echo $row['ItemImage']; ?>" width="100px" height="100px"/>
                    </td>
                    <td>
                    <?php            
						 include("ItemSubDisplay.php"); 
					?>
                    </td>
                </tr>				
			<?php
				}//end of "for" loop
			?>
            	<tr>
                	<td colspan="2">
					<?php       
					//Generating "Pager" Control             
					$objPager->Generate_Pager();
                    ?>
                	</td>
                </tr>
			</table>
                                
        </div>
    </div>
    <?php include_once("footer.php"); ?>
    
</body>
    
</html>

