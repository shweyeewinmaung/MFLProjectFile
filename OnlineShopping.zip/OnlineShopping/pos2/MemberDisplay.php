<?php
	session_start();
	
    require_once("includes/db.php");
	require_once("includes/function.php");
	
	if ($_GET['search'])
	{
		$searchBy=$_GET['searchBy'];
		$searchKey=$_GET['searchKey'];
		
		//If no search key is defined.
		if (empty($searchKey))		
			$sql="SELECT * FROM Member " .
				"ORDER BY MemberID";
		else
			$sql="SELECT * FROM Member " .
				"WHERE $searchBy='$searchKey' ".
				"ORDER BY MemberID";
	}
	//No searching or clicking "Show All"
	else 
	{
		$sql="SELECT * FROM Member " .
				"ORDER BY MemberID";
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>My Online Store</title>
    <link href="CSS/StyleSheet.css" rel="stylesheet" type="text/css" />
</head>
    
<body>

    <?php include_once("header.php"); ?>
    <div id="content">
        <?php include_once("left.php"); ?>
        <div id="content-right">            
        
        	<br/><div class="form-Header">Member Display</div>
                        
			<form name="memberSearch" id="memberSearch" 
            	action="MemberDisplay.php" method="get">
                
          		<div class="search">
                	<p>
                    	<select name="searchBy" id="searchBy">
                            <option value="MemberID" selected="true">MemberID</option>
                            <option value="MemberName">Member Name</option>
                        </select>
                        <input name="searchKey" type="text" id="searchKey"
                            size="30"/>
                            <input name="search" type="submit" value="Search" />
                        <input name="showAll" type="submit" value="Show All" />
					</p>
                </div>

			</form>
                        
   	  		<table class="display">
                <tr>
                    <th>MemberID</th>
                    <th>Member Name</th>
                    <th>Gender</th>
                    <th>DOB</th>
                    <th>EMail</th>                        
                    <th></th>
                    <th></th>
                </tr>
                
                <?php
                    //$sql="SELECT * FROM Member ORDER BY MemberID ASC";
                    $result=mysql_query($sql) or die(mysql_error());
                    $numOfRows=mysql_num_rows($result);
					
					for($i=0;$i<$numOfRows;$i++)
					{
                    	$row=mysql_fetch_array($result); 
												
						if ($i%2!=0)
							echo "<tr class='alt'>";
						else
							echo "<tr>";												                
                    ?>                          
                            <td><?php echo $row['MemberID']; ?></td>
                            <td><?php echo $row['MemberName']; ?></td>
                            <td><?php echo $row['Gender']; ?></td>			        
                            <td>
								<?php 
									echo date("d-M-Y",strtotime($row['DOB'])); 
								?>
                            </td>
                            <td><?php echo $row['EMail']; ?></td>			        
                            <td><a href="#">Update</a></td>
                            <td><a href="#">Delete</a></td>
                        </tr>
                    <?php
                    }//end of "for" loop
                    ?>
			</table>
                                
        </div>
    </div>
    <?php include_once("footer.php"); ?>
    
</body>
    
</html>

