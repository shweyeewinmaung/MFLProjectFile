<?php
	if (empty($itemID))
		die("No Record");
?>
<table class="sub-display">
    <tr>
        <td><div>Item ID :</div></td>
        <td><?php echo $row['ItemID']; ?></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td><div>Item Name :</div></td>
        <td><?php echo $row['ItemName']; ?></td>
        <td><div>Item Type :</div></td>
        <td><?php echo $row['ItemTypeName']; ?></td>
    </tr>
    <tr>
        <td><div>Quantity :</div></td>
        <td><?php echo $row['Quantity']; ?></td>
        <td><div>Price :</div></td>
        <td>$<?php echo $row['Price']; ?></td>
    </tr>
    <tr>
        <td colspan="4" align="right">
        	<?php
			$objLog=new LogIn;
			
			if ($objLog->isAdminLogIn())
			{
			?>			
                <a href="#">Update</a>&nbsp;
                <a href="#">Delete</a>&nbsp;
            <?php
			}
			
			if ($objLog->isMemberLogIn())
			{
			?>
            	<a href="ShoppingCart.php?ItemID=
				<?php echo $row['ItemID'];?>&Action=Add">Add 2 Cart</a>
            <?php
			}
			?>
        </td>                                
    </tr>
</table>