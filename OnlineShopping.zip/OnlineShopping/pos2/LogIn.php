<?php
	session_start();

    require_once("includes/db.php");
	require_once("includes/function.php");
	require_once("includes/logInFunction.php");
	
	if (isset($_POST['submitted']))
	{		
		/***************************************************************/						
		//Filling Data
		$userName=$_POST['userName'];
		$password=$_POST['password'];
		/***************************************************************/						
		$objLogIn=new LogIn;
		$logInOK=$objLogIn->isLogInOK($userName,$password);
		
		if ($logInOK==false)
			$message="Invalid User Name and Password";				
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>My Online Store</title>
	<link href="CSS/StyleSheet.css" rel="stylesheet" type="text/css" />    
	<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"></script>
    <script type="text/javascript" src="JavaScript/jquery.js"></script>
	<script type="text/javascript" src="JavaScript/jquery.validate.js"></script>       
</head>
    
<body>

 
<script language="javascript">
function checkFocus(textValue)
{
	if(textValue=="[UserName]")
	{
		document.getElementById("userName").value="";
		document.getElementById("userName").style.color="#000000";
		document.getElementById("userName").style.fontStyle="normal";
	}  
	
	if(textValue=="[Password]")
	{
		document.getElementById("password").value="";
		document.getElementById("password").type="password";
		document.getElementById("password").style.color="#000000";
		document.getElementById("password").style.fontStyle="normal";
	}
}
 
function doBlur(textValue)
{
	if(document.getElementById("userName").value== "")
	{
		document.getElementById("userName").value= "[UserName]";
		document.getElementById("userName").style.color="#999999";
		document.getElementById("userName").style.fontStyle="italic";
	}
	
	if(document.getElementById("password").value== "")
	{
		document.getElementById("password").type= "text";
		document.getElementById("password").value= "[Password]";
		document.getElementById("password").style.color="#999999";
		document.getElementById("password").style.fontStyle="italic";
	}
}
</script>

<script type="text/javascript">
	
	$(function() 
	{
		// validate contact form on keyup and submit
		$("#logIn").validate(
		{
		//set the rules for the field names
			rules: {
				userName: 
				{
					required: true
				},
				password: 
				{
					required: true,
				}
			},
			//set messages to appear inline
			messages: 
			{
				userName: "Please enter User Name.",
				password: "Please enter Password.",				
			}
		});
	});
</script>
    
    <?php include_once("header.php"); ?>
    <div id="content">
        <?php include_once("left.php"); ?>
        <div id="content-right">
        
        	<br/>
        	<form name="logIn" id="logIn" action="LogIn.php" method="post">
                <?php
				if (!empty($message))
				{
					if ($error)
						echo "<div class='error-Message'>$message</div>";
					else
						echo "<div class='success-Message'>$message</div>";
				}
				?>    
                <table class="default">
                    <tr>
                        <th colspan="2">Log In</th>
                    </tr>
                    <tr>
                        <td><div>User Name :</div></td>
                        <td>
                            <input name="userName" type="text" id="userName"
                            value="[UserName]" size="30" maxlength="20"
                            onblur="doBlur(this.value)" onfocus="checkFocus(this.value)"
                            style="color:#999999;font-style:italic;"/>
                        </td>
                    </tr>                        
                    <tr>
                        <td><div>Password :</div></td>
                        <td>
                            <input name="password" type="text" id="password"
                            value="[Password]" size="30" maxlength="20"  
                            onblur="doBlur(this.value)" onfocus="checkFocus(this.value)"
                            style="color:#999999;font-style:italic;"/>
                        </td>
                    </tr>                                           
                    <tr>
                        <td></td>
                        <td>
                            <input name="submitted" type="submit" value="Log In" />
                            <input name="reset" type="reset" value="Clear" />
                        </td>
                    </tr>                                                                                                                       
                </table>                
            </form>       
        </div>
    </div>
    <?php include_once("footer.php"); ?>
    
</body>
    
</html>

