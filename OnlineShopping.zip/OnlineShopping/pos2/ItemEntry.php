<?php
	session_start();

    require_once("includes/db.php");
	require_once("includes/function.php");
	
	if (isset($_POST['submitted']))
	{		
		$error=false;
		/***************************************************************/						
		//Filling Data
		$itemID=$_POST['itemID'];
		$itemName=$_POST['itemName'];
		$itemTypeID=$_POST['itemTypeID'];
		$quantity=$_POST['quantity'];
		$price=$_POST['price'];
		/***************************************************************/						
		//For "ItemImage"
		// get the original filename
		$image = $_FILES['itemImage']['name'];		
		// image storing folder, make sure you indicate the right path
		$folder = "ItemImage/"; 
		
		// image checking if exist or the input field is not empty
		if($image) 
		{ 
		  // creating a filename
		  $filename = $folder . $itemID . "_" . $image; 		  
		  // uploading image file to specified folder
		  $copied = copy($_FILES['itemImage']['tmp_name'], $filename); 
		  
		  // checking if upload succesfull
		  if (!$copied) 
		  { 			  
			exit("Problem occured. Cannot Upload Item Image.");
		  }
		}
		/***************************************************************/						
		//"Item" Table Insert
		$query="INSERT INTO " .
				"Item" . 
				"(ItemID,ItemName,ItemTypeID,Quantity,Price,ItemImage) ".
				"VALUES" .
				"('$itemID','$itemName','$itemTypeID'" .
				",$quantity,$price,'$filename')";
							
		mysql_query($query) or die(mysql_error());
		/***************************************************************/						
		$message="Item is successfully saved with ItemID : " . $itemID;
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>My Online Store</title>
	<link href="CSS/StyleSheet.css" rel="stylesheet" type="text/css" />    
	<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"></script>
    <script type="text/javascript" src="JavaScript/jquery.js"></script>
	<script type="text/javascript" src="JavaScript/jquery.validate.js"></script>   
</head>
    
<body>

<script type="text/javascript">
	
	$(function() 
	{
		// validate contact form on keyup and submit
		$("#itemEntry").validate(
		{
		//set the rules for the field names
			rules: {
				itemName: 
				{
					required: true
				},
				quantity: 
				{
					required: true,
					digits:true,
					min:0
				},
				price: 
				{
					required: true,
					number:true,
					min:0.01
				},	
				itemImage:
				{
					required:true
				}
			},
			//set messages to appear inline
			messages: 
			{
				itemName: "Please enter Item Name.",
				quantity: 
					{
						required: "Please enter a quantity.",
						digits: "Please enter a correct quantity.",
						min: "Please enter a correct quantity greater than -1."
					},
				price: 
					{
						required: "Please enter a price",
						number:"Please enter a correct price.",
						min: "Please enter a correct price greater than 0.01."		
					},
				itemImage: "Please select an Item Image."
			}
		});
	});
	</script>
    
    <?php include_once("header.php"); ?>
    <div id="content">
        <?php include_once("left.php"); ?>
        <div id="content-right">
        
        	<br/>
        	<form name="itemEntry" id="itemEntry" action="ItemEntry.php" 
            	method="post" enctype="multipart/form-data">
                <?php
				if (!empty($message))
				{
					if ($error)
						echo "<div class='error-Message'>$message</div>";
					else
						echo "<div class='success-Message'>$message</div>";
				}
				?>    
                <table class="default">
                    <tr>
                        <th colspan="2">Item Entry</th>
                    </tr>
                    <tr>
                        <td><div>Item ID :</div></td>
                        <td>
                            <input name="itemID" type="text" id="itemID"
                                size="30" maxlength="15" readonly="true"
                                value="<?php echo AutoID('Item','ItemID','ITM',6) ?>"/>
                        </td>
                    </tr>                        
                    <tr>
                        <td><div>Item Name :</div></td>
                        <td>
                            <input name="itemName" type="text" id="itemName"
                                size="50" maxlength="50" />
                        </td>
                    </tr>                        
                    <tr>
                        <td><div>Item Type :</div></td>
                        <td>
                            <select name="itemTypeID"> 
                            <?php
								$sql="SELECT * FROM " .
									"ItemType " . 
									"ORDER BY ItemTypeName";
								$result=mysql_query($sql) or die(mysql_error());
							                                    
                            while ($row=mysql_fetch_array($result))
							{         
							?>       
                            	<option value="<?php echo $row['ItemTypeID']; ?>" >
                            		<?php echo $row['ItemTypeName'] ?>
                                </option>
                            <?php
							}//end of "while" loop
							?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><div>Quantity :</div></td>
                        <td>
                        	<input name="quantity" type="text" id="quantity" size="30" />
						</td>
                    </tr>            
                    <tr>
                        <td><div>Price :</div></td>
                        <td>
                        	<input name="price" type="text" id="price" size="30" />
						</td>
                    </tr>   
                    <tr>
                        <td><div>Item Image :</div></td>
                        <td>
                        	<input name="itemImage" type="file" id="itemImage" size="40"/>
						</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input name="submitted" type="submit" value="Save" />
                            <input name="reset" type="reset" value="Clear" />
                        </td>
                    </tr>                                                                                                                       
                </table>                
            </form>       
        </div>
    </div>
    <?php include_once("footer.php"); ?>
    
</body>
    
</html>

