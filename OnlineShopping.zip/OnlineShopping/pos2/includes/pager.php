<?php
class pager
{
	public $pageSize,$currentPageIndex;
	public $searchBy,$searchKey;
	public $offset,$maxPage;
	public $totalRecordCount;
	
	//Constructor
	function __construct($pageSize,$currentPageIndex,$searchBy,$searchKey)
	{	
		//Page Size
		$this->pageSize=$pageSize;	
		//by default we show first page
		$this->currentPageIndex=$currentPageIndex;		
		//counting the offset
		$this->offset=($currentPageIndex-1)*$pageSize;
		
		$this->searchBy=$searchBy;
		$this->searchKey=$searchKey;
	}	
	
	function Get_Data($tableName,$orderByFieldName)
	{
		//If no search key is defined
		if (!empty($this->searchKey))		
			$sql="SELECT * FROM $tableName " .								
				"WHERE $this->searchBy='$this->searchKey' " .
				"ORDER BY $orderByFieldName " .
				"LIMIT $this->offset,$this->pageSize";				
		else		
			$sql="SELECT * FROM $tableName " .
				"ORDER BY $orderByFieldName " .
				"LIMIT $this->offset,$this->pageSize";		

		//Calcuate "TotalRecordCount"								
		$this->totalRecordCount=
			$this->Get_TotalRecordCount($tableName,$orderByFieldName);
		//how many pages
		$this->maxPage=ceil($this->totalRecordCount/$this->pageSize);	

		$result=mysql_query($sql) or die(mysql_error());
		return $result;
	}
	/********************************************************************/	
	function Get_TotalRecordCount($tableName,$fieldName)
	{
		//If no search key is defined
		if (empty($this->searchKey))	
			$sql="SELECT COUNT($fieldName) AS TotalRecordCount " .				
					"FROM $tableName";												
		else
			$sql="SELECT COUNT($fieldName) AS TotalRecordCount " .
					"FROM $tableName " . 
					"WHERE $this->searchBy='$this->searchKey'";	
						
		$result=mysql_query($sql) or die(mysql_error);
		$row=mysql_fetch_array($result);
		$totalRecordCount=$row['TotalRecordCount'];	
		
		return $totalRecordCount;					
	}
	/********************************************************************/
	function Generate_Pager()
	{
		/********************************************************************/
		// creating previous and next link
		// plus the link to go straight to
		// the first and last page
		/********************************************************************/				
		//the name of the current page	
		$self = $_SERVER['PHP_SELF'];
		/********************************************************************/
		// "Previous" and "First" page link
		if ($this->currentPageIndex>1)
		{
			$pageIndex=$this->currentPageIndex-1;					
			echo "<a href='$self?page=1'>[First]</a>&nbsp;";
			echo "<a href='$self?page=$pageIndex'>[Prev]</a>&nbsp;";							
		}
		else
		{}								
		/********************************************************************/
		// print the link to access each page
		for($i=1;$i<=$this->maxPage;$i++)
		{
			if ($i==$this->currentPageIndex)
			{
				echo $i . "&nbsp;";
			}
			else
			{
				echo "<a href='$self?page=$i'>$i</a>&nbsp;";
			}
		}
		/********************************************************************/
		// "Next" and "Last" page link
		if ($this->currentPageIndex<$this->maxPage)
		{
			$pageIndex=$this->currentPageIndex+1;
			echo "<a href='$self?page=$pageIndex'>[Next]</a>&nbsp;";
			echo "<a href='$self?page=$this->maxPage'>[Last]</a>&nbsp;";
		}
		else
		{}
		/********************************************************************/
	}
	/********************************************************************/
}	
?>