<?php	
class ShoppingCart
{
	//Constructor
	public function _construct()
	{
		if (!isset($_SESSION['ShoppingCart']))
		{
			//Creating Session "Array"
			$_SESSION['ShoppingCart']=array();	
		}
	}
	
	function Insert($itemID)
	{												
		//Function Call to check
		//If the "Item" already existed in "Session"
		$index=$this->IndexOf($itemID);
		
		//index=1 means "Item" is not existed in "Session"
		if ($index==-1)
		{
			//Get "ShoppingCart" session array size
			$size=count($_SESSION['ShoppingCart']);
			
			$_SESSION['ShoppingCart'][$size]['ItemID']=$itemID;
			$_SESSION['ShoppingCart'][$size]['Quantity']=1;
		}
		else
		{
			//"Item" already existed in "Session"
			//So we update "Quantity"
			$_SESSION['ShoppingCart'][$index]['Quantity']++;
		}								
	}	
	
	function Remove($itemID)
	{
		$index=$this->IndexOf($itemID);
		
		if ($index>-1)
		{
			unset($_SESSION['ShoppingCart'][$index]);
		}
		
		$_SESSION['ShoppingCart']=array_values($_SESSION['ShoppingCart']);
	}
	
	function Clear()
	{
		unset($_SESSION['ShoppingCart']);
	}
	
	//function to find the index of an item in the shopping cart
	//if "Item" is found, return "Item" Index in the shopping cart
	//if "Item" is not found, return "-1"
	function IndexOf($itemID)
	{
		if (!isset($_SESSION['ShoppingCart']))
			return -1;
			
		$size=count($_SESSION['ShoppingCart']);
		
		if ($size==0)
			return -1;
			
		for ($i=0;$i<$size;$i++)
		{
			if ($itemID==$_SESSION['ShoppingCart'][$i]['ItemID'])
				return $i;
		}
		
		return -1;
	}				
}
?>