<?php
class LogIn
{
	function isLogInOK($userName,$password)
	{
		$sql="SELECT * FROM User " .
				"WHERE UserName='$userName' " .
				"AND Password='$password'";
				
		$result=mysql_query($sql) or die(mysql_error());		
		$numOfRows=mysql_num_rows($result);

		if ($numOfRows==0)
			return false;
		else
		{
			$row=mysql_fetch_array($result); 
			$userID=$row['UserID'];
			$role=$row['Role'];			
			
			$_SESSION['user']['UserID']=$userID;
			$_SESSION['user']['UserName']=$userName;
			$_SESSION['user']['Password']=$password;
			$_SESSION['user']['Role']=$role;

			header("Location:ItemDisplay.php");
			return true;
		}
	}

	function isAdminLogIn()
	{
		return $this->isLoggedIn("admin");
	}
	
	function isMemberLogIn()
	{
		return $this->isLoggedIn("member");
	}
	
	function isLoggedIn($role)
	{
		if (!isset($_SESSION['user']))
			return false;

		if (!isset($_SESSION['user']['Role']))
			return false;			
			
		//Checking "role"
		//such as "member" or "admin"			
		if ($role!==$_SESSION['user']['Role'])
			return false;
			
		return true;
	}
}
?>