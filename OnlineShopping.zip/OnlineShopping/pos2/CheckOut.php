<?php
session_start();

require_once("includes/db.php");
require_once("includes/function.php");	
require_once("includes/logInFunction.php");		
/*********************************************************************/
//Security Checking
$objLogIn=new LogIn();

if ($objLogIn->isMemberLogIn()==false)
	header("Location:LogIn.php");
/*********************************************************************/
//Calculating "Total Amount"
$size=count($_SESSION['ShoppingCart']);					
$totalAmount=0;

for($i=0;$i<$size;$i++)
{			
	$itemID=$_SESSION['ShoppingCart'][$i]['ItemID'];
	$quantity=$_SESSION['ShoppingCart'][$i]['Quantity'];
	
	$sql="SELECT * FROM Item_View WHERE ItemID='$itemID'";	
	$result=mysql_query($sql) or die(mysql_error());
	$row=mysql_fetch_array($result);
	
	$amount=$quantity*$row['Price'];
	$totalAmount+=$amount;
}
/*********************************************************************/
	
if (isset($_POST['submitted']))
{	
	/*********************************************************************/					
	$memberID=$_SESSION['user']['UserID'];
	$checkOutDate_String=$_POST['checkOutDate'];
	$checkOutDate=date("Y-m-d",strtotime($checkOutDate_String));

	$month=date("m",$checkOutDate);
	//$year=date("y",$checkOutDate);
		$year=substr($checkOutDate,0,4);
	/*******************************************************************/
	$checkOutID=AutoID_ByDate("CheckOut","CheckOutID","CheckOutDate",$month,$year,6);
	/*********************************************************************/
	//"CheckOut" Table "Insert"
	$checkOutInsert_sql="INSERT INTO CheckOut " .
		"VALUES('$checkOutID','$checkOutDate','$memberID',$totalAmount)";

	mysql_query($checkOutInsert_sql) or die(mysql_error());	
	/*******************************************************************/
	$size=count($_SESSION['ShoppingCart']);
	
	for ($i=0;$i<$size;$i++)
	{
		$itemID=$_SESSION['ShoppingCart'][$i]['ItemID'];
		$quantity=$_SESSION['ShoppingCart'][$i]['Quantity'];
		
		$sql="SELECT * FROM Item_View WHERE ItemID='$itemID'";
		$result=mysql_query($sql) or die(mysql_error());
		$row=mysql_fetch_array($result);		
			
		$price=$row['Price'];
		/*******************************************************************/
		//"CheckOutDetail" Table "Insert"
		$checkOutDetailInsert_sql="INSERT INTO CheckOutDetail " .
		"VALUES ('$checkOutID','$itemID',$quantity,$price)";
		
		mysql_query($checkOutDetailInsert_sql) or die(mysql_error());
		/*******************************************************************/
		//"Item" Table "Update"		
		$itemUpdate_sql="UPDATE Item SET Quantity=Quantity-$quantity " .
			  "WHERE ItemID='$itemID'";	
		
		mysql_query($itemUpdate_sql) or die(mysql_error());
	  /*******************************************************************/
	}
	
	$message="Shopping cart is successfully Check Out";
	//Clear "Shopping Cart";
	unset($_SESSION['ShoppingCart']);
					  
}//end of "if"	     
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>My Online Store</title>
    <link href="CSS/StyleSheet.css" rel="stylesheet" type="text/css" />    
	<link href="JavaScript/DatePicker/datepicker.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="JavaScript/DatePicker/datepicker.js"></script>
    <script type="text/javascript" src="JavaScript/jquery.js"></script>
	<script type="text/javascript" src="JavaScript/jquery.validate.js"></script>   
</head>
    
<body>

    <script type="text/javascript">
	
	$(function() 
	{
		// validate contact form on keyup and submit
		$("#checkOut").validate(
		{
		//set the rules for the field names
			rules: {
				cardNo: 
				{
					required: true
				}
			},
			//set messages to appear inline
			messages: 
			{
				cardNo: "Please enter Card No.",				
			}
		});
	});
	</script>


    <?php include_once("header.php"); ?>
    <div id="content">
        <?php include_once("left.php"); ?>
        <div id="content-right">
            <br/>
			<form name="checkOut" id="checkOut" action="CheckOut.php" method="post">
                <?php
				if (!empty($message))
				{
					if ($error)
						echo "<div class='error-Message'>$message</div>";
					else
						echo "<div class='success-Message'>$message</div>";
				}
				?>    
                <table class="default">
                	<tr>
                        <th colspan="2">Check Out</th>
                    </tr>  
					<tr>
                        <td><div>User Name :</div></td>
                        <td>
                            <?php echo $_SESSION['user']['UserName']; ?>
                        </td>
                    </tr>  
					<tr>
                        <td><div>Total Amount :</div></td>
                        <td>
                            <?php echo $totalAmount; ?>
                        </td>
                    </tr>   
                    <tr>
                        <td><div>Card No :</div></td>
                        <td>
                            <input name="cardNo" type="text" id="cardNo"
                                size="50" maxlength="50" />
                        </td>
                    </tr>                                     
                    <tr>
                        <td><div>Card Type :</div></td>
                        <td>                                
                            <p>
	                        	<label>
                                    <input type="radio" name="cardType" 
                                        value="Master" id="cardType_0" checked="true"/>Master
								</label>
							  	<label>
                                	<input type="radio" name="cardType" 
                                    	value="Visa" id="cardType_1" />Visa
								</label>       
							  	<label>
                                	<input type="radio" name="cardType" 
                                    	value="American Express" id="cardType_2" />American Express
								</label>                                                             
                            </p>
                        </td>                        
                    </tr>    
                    <tr>
                        <td><div>Check Out Date :</div></td>
                        <td>
                            <input name="checkOutDate" type="text" size="30" id="checkOutDate"
                                maxlength="11" value="<?php echo date("d-M-Y")?>" 
                                    onfocus="showCalender(calender,this)"/>
                        </td>
                    </tr>                   
                    <tr>
                        <td></td>
                        <td>
                            <input name="submitted" type="submit" value="Save" />
                            <input name="reset" type="reset" value="Clear" />
                        </td>
                    </tr>   
                </table>                           
			</form>        
        </div>
    </div>
    <?php include_once("footer.php"); ?>
    
</body>
    
</html>

